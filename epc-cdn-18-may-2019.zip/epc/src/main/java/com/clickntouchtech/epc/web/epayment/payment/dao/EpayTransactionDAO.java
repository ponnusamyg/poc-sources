package com.clickntouchtech.epc.web.epayment.payment.dao;

import com.clickntouchtech.epc.web.epayment.payment.model.EpayModelParams;
import com.clickntouchtech.epc.web.epayment.payment.model.Transaction;
import com.clickntouchtech.epc.web.framework.exception.EpayDaoException;


public interface EpayTransactionDAO {
	public String getEpayTransaction( Transaction transaction, EpayModelParams epayModelParams) throws EpayDaoException ;
	public void updateEpayTransData( String refNo, EpayModelParams epayModelParams) throws EpayDaoException;
	public void updateEpayTransStatus(String refNo, String MerchantRefNo, String Status, String RRN,String statusDescripton) throws EpayDaoException;

}
