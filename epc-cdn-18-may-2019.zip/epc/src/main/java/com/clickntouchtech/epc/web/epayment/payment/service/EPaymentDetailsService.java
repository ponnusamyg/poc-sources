package com.clickntouchtech.epc.web.epayment.payment.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.clickntouchtech.epc.web.epayment.payment.dao.EpayOrgDao;
import com.clickntouchtech.epc.web.epayment.payment.model.EpayModelValidClassificationParams;
import com.clickntouchtech.epc.web.framework.exception.EpayApplicationException;
import com.clickntouchtech.epc.web.framework.exception.EpayBaseResponse;
import com.clickntouchtech.epc.web.framework.exception.EpayDaoException;
import com.clickntouchtech.epc.web.framework.service.EpayBaseAbsService;
import com.clickntouchtech.epc.web.framework.service.ServiceErrorConstants;
import com.clickntouchtech.epc.web.framework.util.LoggingConstants;

@Service
public class EPaymentDetailsService extends EpayBaseAbsService{

	private static final Logger logger = LoggerFactory.getLogger(EPaymentDetailsService.class);
	
	@Autowired
	private EpayOrgDao epayOrgDao;
	
	public ModelMap epayServiceBase(ModelMap inputParams) {
		
		logger.info("EPaymentDetailsService execute method begins");
		
		if (logger.isDebugEnabled())
			logger.debug("inputparams Map:: {}", inputParams);
		
		EpayBaseResponse response = new EpayBaseResponse();
		response.setErrorStatus(ServiceErrorConstants.FAILURE);

		ModelMap outParams = new ModelMap();
		
        String classificationid = (String) inputParams.get("classificationid");       
        String registerNo = (String) inputParams.get("registerNumber");
        //String duplicatePayment = (String) inputParams.get("dupPayment");
        String todayDate = (String) inputParams.get("todayDate");
        
        
        List paramList = null;
        List penaltyList = null;
        
        if(classificationid != null && !classificationid.equalsIgnoreCase(""))
    	{
            try {  
	            	 
	            	//Map cutOfftime = epayOrgDao.getClassficationEndDate(classificationid,todayDate);
	            	 System.out.println("classificationid======================"+classificationid);
	            	Map descDetails = epayOrgDao.getDescriptionData(classificationid);
	            	/*To display start date alert message for future date categories- changes*/
	            	String startDate = new SimpleDateFormat("dd-MM-yyyy").format(descDetails.get("livedate"));
	            	logger.info("today's date:::{},startDate:::{}",todayDate, startDate);
	            	SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
	            	Date date1 = sdf.parse(todayDate);
	            	Date date2 = sdf.parse(startDate);
	            	logger.info("today's date:::{},startDate:::{}",date1, date2);
	            	String classificationname=(String)descDetails.get("classificationname");
	            	if(date1.compareTo(date2)<0)
	            	{
	            		outParams.put("START_DATE", startDate);
	            		outParams.put("classificationname", classificationname);
	            		outParams.put("customizederror", "required");
	            		response.setErrorCode("SUV015");
	            		throw new EpayApplicationException("SUV015");
	            	}
	            
					outParams.put("classificationname", classificationname);
							
					
					
					
		        
						paramList = epayOrgDao.getClassificationParams(classificationid);
						if ((paramList != null && paramList.size() > 0 ) ) {
							outParams.put("paramList", paramList);
							response.setErrorStatus(ServiceErrorConstants.SUCCESS);
						} else {
							logger.info("fieldkey values list for the selected category is null or empty");
							response.setErrorStatus(ServiceErrorConstants.FAILURE);
							response.setErrorCode("SUV010");
						}
					
            }
            catch (EpayApplicationException epcexp) {
            	logger.error(LoggingConstants.EXCEPTION, epcexp);
            	logger.info("Exception at 115");
            	response.setErrorStatus(ServiceErrorConstants.FAILURE);
                response.setErrorCode(epcexp.getErrorCode());

            }
            catch(EpayDaoException dataAccessException) {
				logger.error("Exception occured :"+dataAccessException);
				response.setErrorStatus(ServiceErrorConstants.FAILURE);
				response.setErrorCode("SUV010");
			}
            
            catch (Exception exp) {
            	logger.info("Exception at 122");
            	logger.error(LoggingConstants.EXCEPTION, exp);
                response.setErrorStatus(ServiceErrorConstants.FAILURE);
                response.setErrorMessage(ServiceErrorConstants.UNDEFINED);
                response.setErrorCode("SUV010");
           }
    	}
        else
        {
        	logger.info("institution id is null");
        	 response.setErrorStatus(ServiceErrorConstants.FAILURE);
        	 response.setErrorCode("SUV002");
        }
        
        outParams.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
        if (logger.isDebugEnabled())
        {
        	logger.info("execute(Map inputParams) method end");
        }
        return outParams;
    }
    /*Added for security issue fix*/
    public Map validateSessionParams(List categoryValidParamList, String records)
    {
      Map hm = new HashMap();
      List ar = new ArrayList();

      List fixedDetails = new ArrayList();
      List AmountDetails = new ArrayList();

      for (int i = 0; i < categoryValidParamList.size(); i++) {
        EpayModelValidClassificationParams paramDetails = (EpayModelValidClassificationParams)categoryValidParamList.get(i);
        ar.add(paramDetails.getOutRef());
        fixedDetails.add(paramDetails.getParamType());
        AmountDetails.add(paramDetails.getAmount());
      }

      Iterator it = ar.iterator();
      Iterator fixedType = fixedDetails.iterator();
      Iterator AmountType = AmountDetails.iterator();

      StringTokenizer st = new StringTokenizer(records, "|");

      while (st.hasMoreTokens())
      {
        String fixedParam = null;
        String Amount = null;

        String sr = st.nextToken();
        logger.info("token string:::: {}",sr);

        if ((sr != null) && (!"ICM".equalsIgnoreCase(sr.trim())) && (fixedType.hasNext()) && (AmountType.hasNext()))
        {
          fixedParam = (String)fixedType.next();
          Amount = (String)AmountType.next();
        }

        if ((sr == null) || ("ICM".equalsIgnoreCase(sr.trim())))
          continue;
        if (((!"Fixed".equalsIgnoreCase(fixedParam)) || ((!sr.contains("N/A")) && (!sr.endsWith(" NA")) && (!sr.endsWith("-NA")) && (!"NA".equalsIgnoreCase(sr)))) && ((sr.contains("N/A")) || (sr.endsWith(" NA")) || (sr.endsWith("-NA")) || ("NA".equalsIgnoreCase(sr))))
          continue;
        if ("Fixed".equalsIgnoreCase(fixedParam))
        {
          sr = Amount;
        }

        String sit = (String)it.next();
        hm.put(sit, sr);
        this.logger.info("Key::: {}, value::: {} ",sit, sr);
      }

      return hm;
    }

  /*Added for security issue fix*/
	
}
