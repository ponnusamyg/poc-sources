package com.clickntouchtech.epc.web.epaysecurity.interceptor;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.clickntouchtech.epc.web.epaysecurity.service.EpayTokenService;

/**
 * EpayTokenInterceptor
 *
 * @author selvaraj palanisamy
 * @since 1.0
 */
public class EpayTokenInterceptor implements HandlerInterceptor {

	private static final Logger logger = LoggerFactory.getLogger(EpayTokenInterceptor.class);

	public final static List<String> ALLOWED_METHODS_POST = Collections.unmodifiableList(Arrays.asList("POST"));
	//public final static List<String> ALLOWED_METHODS_GET = Collections.unmodifiableList(Arrays.asList("GET"));

	@Autowired
	private EpayTokenService pagefTokenService;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)throws Exception {
		logger.info("preHandle--begin");
		boolean tkbooleanvalidate = true;
		final boolean validatetoken=pagefTokenService.validateTokenInterceptor(request);
		logger.info("preHandle--validation--token--{}",validatetoken);
		logger.info("StringUtils.defaultIfEmpty(request.getMethod()-{}",StringUtils.defaultIfEmpty(request.getMethod(), "").toUpperCase());
		
		if (ALLOWED_METHODS_POST.contains(StringUtils.defaultIfEmpty(request.getMethod(), "").toUpperCase()) && !validatetoken){
			logger.info("preHandle--------------------------validate method inside---");
			tkbooleanvalidate = false;
			response.addHeader("InvalidToken", Boolean.toString(true));
			logger.info("preHandle--------------------------forward to session timeout---");
			forwordURL("sessiontimeout", request, response);
		}
		logger.info("return values------{}",tkbooleanvalidate);
		logger.info("preHandle--end");
		return tkbooleanvalidate;
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
	}

	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
	}

	private static void forwordURL(String url, HttpServletRequest request, HttpServletResponse response) {
		logger.info("EpayTokenInterceptor:----forwordURL method inside---session time out page");
		try {
			request.getRequestDispatcher("/" + url).forward(request, response);
		} catch (Exception exception) {
			exception.getMessage();
		}
	}

}
