package com.clickntouchtech.epc.web.epayment.payment.dao;

import java.util.List;

import org.springframework.ui.ModelMap;

import com.clickntouchtech.epc.web.epaysecurity.bean.EpayUsersProfile;

public interface EpayUserDashBoardDao {
	
	public int getEpayUserLoginHistoryCount(String userID);

	public int getEpayUserOverAllSuccessTxnCounts(String userID);

	public int getEpayUserOverAllTxnCounts(String userID);
	
	public List getTopTransactions(String userId);
	
	public EpayUsersProfile getEpayUserProfileDetails(ModelMap inParams);
	
	public  List getEpayUserLoginDetails(String userId);
	
	public List getFailureTransactions(String userId);
	
	public List getSuccessTransactions(String userId);

}