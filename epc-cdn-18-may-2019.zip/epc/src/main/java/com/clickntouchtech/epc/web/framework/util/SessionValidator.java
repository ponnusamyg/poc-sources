package com.clickntouchtech.epc.web.framework.util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class SessionValidator {
	
	public static boolean isValidSession(HttpServletRequest request,HttpServletResponse response,String type){
    	HttpSession session=request.getSession(false);
        if (session == null) {
        	request.setAttribute("sessionError","Your session expired.Please re-login.");
			forwordURL("sessiontimeout",request, response);
            return false;
		}
        return true;
    }
	
	
    private static void forwordURL(String url,HttpServletRequest request, HttpServletResponse response) {
    	System.out.println(":::::::GOT forwordURL::: START::::::::::::");
    	System.out.println(":::::::URL::::::::::::"+url);

    	try{
    		
    		request.getRequestDispatcher("/"+url).forward(request, response);
    		
        }catch(Exception exception){
        	System.out.println(":::::::GOT EXCEPTION:::::::::::::::");
        	exception.getMessage();
        }
    	System.out.println(":::::::GOT forwordURL::: END::::::::::::");

    }
    
    public static boolean isValidReferer(HttpServletRequest request,HttpServletResponse response,HttpSession session) {
		String refervalue = (String) request.getAttribute("referer");
		boolean flag = true;
		if (refervalue == null) {
			if (session != null)
				session.invalidate();
			flag = false;
			System.out.println(":::::::GOT forwordURL::: END::::::::::::");
			forwordURL("errorpage",request,response);
		}
		return flag;
	}

}
