package com.clickntouchtech.epc.web.epayment.payment.util;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.clickntouchtech.epc.web.epayment.payment.model.EpayModelParams;
import com.clickntouchtech.epc.web.epayment.payment.model.Transaction;


@Repository
public class EpaymentUtils {
	
	protected final Logger logger = LoggerFactory.getLogger(EpaymentUtils.class);
	
	public EpayModelParams getPreloginParams(Map input, Transaction transaction ){
		
		EpayModelParams params = new EpayModelParams();
		//params.setCommissionAmount(transaction.getDebit().getRateOfInterest());   my comment 
		params.setEpayamount(transaction.getDebit().getAmount());
		String branchCode=transaction.getDebit().getBranchCode();
        String bankCode="";
        if(branchCode!=null){
        	bankCode=branchCode.substring(0,1);
        }
        //params.setBankCode(bankCode);
		params.setClassificationId((String)transaction.getDebit().getAdditionalParams().get("fieldkey6"));//Classification ID
        params.setOrganizationId((String)transaction.getDebit().getAdditionalParams().get("fieldkey4"));//Instittue Id
        //params.setDob((String) input.get("dateOfBirth"));
       // params.setMobile_no((String) input.get("mobileNo"));
		params.setModeofpayment((String) (input.get("payOption")));
		//params.setNarrative3((String) input.get("registerNumber"));
		logger.info("inputParams: {}",input);
		
		return params;
	}
}
