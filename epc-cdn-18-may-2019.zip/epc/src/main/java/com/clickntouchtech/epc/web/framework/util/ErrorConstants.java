package com.clickntouchtech.epc.web.framework.util;

import com.clickntouchtech.epc.web.framework.util.Constants;

public interface ErrorConstants extends Constants
{

    String FATAL_EXCEPTION_ERRORCODE = "F001";
    }
