package com.clickntouchtech.epc.web.epaysecurity.service;

import javax.servlet.http.HttpServletRequest;


/**
 * EpayTokenService
 *
 * @author selvaraj palanisamy
 * @since 1.0
 */
public interface EpayTokenService {
	
    /**
     * 
     */
	public final static String TOKEN_PARAM_NAME = "RANDOM_PARM_NAME";
	
	  /**
	  * 
	  */
	public final static String TOKEN_ABUTE_NAME = "EPCToken"; 
   /**
    * 
    * @return string
    */
	public String generatePageToken();
   /**
    * 
    * @param request
    * @return string 
    */
	public String getPageTokenSession(HttpServletRequest request);
   /**
    * 
    * @param request
    * @return boolean
    */
	public boolean validateTokenInterceptor(HttpServletRequest request);
	
	
	  /**
	    * 
	    * @return string
	    */
	
    public String generateParmName(final HttpServletRequest request);
    
    /**
     * 
     * @return string
     */
 	public String generateParmName();
}
