package com.clickntouchtech.epc.web.epayment.payment.model;

public class EpayModelClassificationData implements EpayBaseModel {

	private String organizationId;
	private String classificationId;
	private String classificationName;
	private String orgstate;
	private String classificationkey;
	private String classificationmode;
	private String classificKeyValue;
	
	private String orgName;



	/**
	 * @return the classificationkey
	 */
	public String getClassificationkey() {
		return classificationkey;
	}

	/**
	 * @param classificationkey
	 *            the classificationkey to set
	 */
	public void setClassificationkey(String classificationkey) {
		this.classificationkey = classificationkey;
	}

	/**
	 * @return the classificationmode
	 */
	public String getClassificationmode() {
		return classificationmode;
	}

	/**
	 * @param classificationmode
	 *            the classificationmode to set
	 */
	public void setClassificationmode(String classificationmode) {
		this.classificationmode = classificationmode;
	}

	/**
	 * @return the organizationId
	 */
	public String getOrganizationId() {
		return organizationId;
	}

	/**
	 * @param organizationId
	 *            the organizationId to set
	 */
	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}

	/**
	 * @return the classificationId
	 */
	public String getClassificationId() {
		return classificationId;
	}

	/**
	 * @param classificationId
	 *            the classificationId to set
	 */
	public void setClassificationId(String classificationId) {
		this.classificationId = classificationId;
	}

	/**
	 * @return the classificationName
	 */
	public String getClassificationName() {
		return classificationName;
	}

	/**
	 * @param classificationName
	 *            the classificationName to set
	 */
	public void setClassificationName(String classificationName) {
		this.classificationName = classificationName;
	}

	/**
	 * @return the orgstate
	 */
	public String getOrgstate() {
		return orgstate;
	}

	/**
	 * @param orgstate
	 *            the orgstate to set
	 */
	public void setOrgstate(String orgstate) {
		this.orgstate = orgstate;
	}

	/**
	 * @return the classificKeyValue
	 */
	public String getClassificKeyValue() {
		return classificKeyValue;
	}

	/**
	 * @param classificKeyValue the classificKeyValue to set
	 */
	public void setClassificKeyValue(String classificKeyValue) {
		this.classificKeyValue = classificKeyValue;
	}

	/**
	 * @return the orgName
	 */
	public String getOrgName() {
		return orgName;
	}

	/**
	 * @param orgName the orgName to set
	 */
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

}
