package com.clickntouchtech.epc.web.framework.service;

public class ServiceErrorConstants {

	public static final String APPLICATION_RESPONSE = "applicationResponse";

	public static final String SUCCESS = "success";

	public static final String FAILURE = "failure";

	public static final String UNDEFINED = "Unable to process the request";

	public static final String EPCERR002 = "EPCERR002";
	public static final String TRANSACTION = "transaction";
	
	public static final String CREDIT_AMOUNT_TRANSFER = "transaction";
	
	public static final String CREDIT_BRANCH_CODE = "transaction";
	 public static final String TRANSACTION_NAME = "transactionName";
	

	
}
