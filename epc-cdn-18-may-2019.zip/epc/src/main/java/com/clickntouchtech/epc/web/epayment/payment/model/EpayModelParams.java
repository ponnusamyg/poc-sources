package com.clickntouchtech.epc.web.epayment.payment.model;

import java.io.Serializable;

public class EpayModelParams implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Double epayrefno;
	private Double totalamount;
	private Double epayamount;
	private Double serviceamount;
	private String gatewayrefno;
	private String classificationId;
	private String organizationId;
	private String convenienceamount;
	private String modeofpayment;
	private String paymentstatus;
	private String serviceamounttype;
	
	
	/**
	 * @return the epayamount
	 */
	public Double getEpayamount() {
		return epayamount;
	}
	/**
	 * @param epayamount the epayamount to set
	 */
	public void setEpayamount(Double epayamount) {
		this.epayamount = epayamount;
	}
	/**
	 * @return the epayrefno
	 */
	public Double getEpayrefno() {
		return epayrefno;
	}
	/**
	 * @param epayrefno the epayrefno to set
	 */
	public void setEpayrefno(Double epayrefno) {
		this.epayrefno = epayrefno;
	}
	
	/**
	 * @return the totalamount
	 */
	public Double getTotalamount() {
		return totalamount;
	}
	/**
	 * @param totalamount the totalamount to set
	 */
	public void setTotalamount(Double totalamount) {
		this.totalamount = totalamount;
	}
	/**
	 * @return the serviceamount
	 */
	public Double getServiceamount() {
		return serviceamount;
	}
	/**
	 * @param serviceamount the serviceamount to set
	 */
	public void setServiceamount(Double serviceamount) {
		this.serviceamount = serviceamount;
	}
	/**
	 * @return the gatewayrefno
	 */
	public String getGatewayrefno() {
		return gatewayrefno;
	}
	/**
	 * @param gatewayrefno the gatewayrefno to set
	 */
	public void setGatewayrefno(String gatewayrefno) {
		this.gatewayrefno = gatewayrefno;
	}
	/**
	 * @return the classificationId
	 */
	public String getClassificationId() {
		return classificationId;
	}
	/**
	 * @param classificationId the classificationId to set
	 */
	public void setClassificationId(String classificationId) {
		this.classificationId = classificationId;
	}
	/**
	 * @return the organizationId
	 */
	public String getOrganizationId() {
		return organizationId;
	}
	/**
	 * @param organizationId the organizationId to set
	 */
	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}
	/**
	 * @return the convenienceamount
	 */
	public String getConvenienceamount() {
		return convenienceamount;
	}
	/**
	 * @param convenienceamount the convenienceamount to set
	 */
	public void setConvenienceamount(String convenienceamount) {
		this.convenienceamount = convenienceamount;
	}
	/**
	 * @return the modeofpayment
	 */
	public String getModeofpayment() {
		return modeofpayment;
	}
	/**
	 * @param modeofpayment the modeofpayment to set
	 */
	public void setModeofpayment(String modeofpayment) {
		this.modeofpayment = modeofpayment;
	}
	/**
	 * @return the paymentstatus
	 */
	public String getPaymentstatus() {
		return paymentstatus;
	}
	/**
	 * @param paymentstatus the paymentstatus to set
	 */
	public void setPaymentstatus(String paymentstatus) {
		this.paymentstatus = paymentstatus;
	}
	/**
	 * @return the serviceamounttype
	 */
	public String getServiceamounttype() {
		return serviceamounttype;
	}
	/**
	 * @param serviceamounttype the serviceamounttype to set
	 */
	public void setServiceamounttype(String serviceamounttype) {
		this.serviceamounttype = serviceamounttype;
	}
	
	
	

	}
