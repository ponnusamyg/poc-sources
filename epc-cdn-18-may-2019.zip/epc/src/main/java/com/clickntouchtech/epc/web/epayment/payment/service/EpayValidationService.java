
package com.clickntouchtech.epc.web.epayment.payment.service;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.clickntouchtech.epc.web.epayment.payment.dao.EpayOrgDao;
import com.clickntouchtech.epc.web.epayment.payment.model.EpayFormValues;
import com.clickntouchtech.epc.web.epayment.payment.util.EpayUtilValidation;
import com.clickntouchtech.epc.web.framework.exception.EpayBaseResponse;
import com.clickntouchtech.epc.web.framework.service.EpayBaseAbsService;
import com.clickntouchtech.epc.web.framework.service.ServiceErrorConstants;

@Service
public class EpayValidationService extends EpayBaseAbsService {

	private static final Logger logger = LoggerFactory.getLogger(EpayValidationService.class);

	@Autowired
	private EpayOrgDao epayOrgDao;

	@SuppressWarnings("unchecked")
	public ModelMap epayServiceBase(ModelMap inputParams) {

		logger.info("EpayValidationService - Start");

		EpayBaseResponse response = new EpayBaseResponse();
		response.setErrorStatus(ServiceErrorConstants.SUCCESS);

		ModelMap outParams = new ModelMap();
		Map errParams = new ModelMap();

		String classificationid = (String) inputParams.get("classificationid");

		try {
			List<EpayFormValues> list = epayOrgDao.getEpayClassificationParams(classificationid);

			for (EpayFormValues formControl : list) {

				if (formControl.getMandatory() != null && !formControl.getMandatory().isEmpty()) {
					if ("0".equals(formControl.getMandatory())) {
						if (inputParams.get(formControl.getRequestVarname()).toString().isEmpty()) {
							logger.info("validate the Mandatoryfields {}", formControl.getRequestVarname());
							response.setErrorStatus(ServiceErrorConstants.FAILURE);
							response.setErrorCode("EPAYORG002");
							break;
						}
					}
				}

				if (formControl.getControlType().equals("Text") || formControl.getControlType().equals("Options")) {

					if (formControl.getFormat() != null) {
						logger.info("validate the Text fileds and option fields {}", formControl.getControlType());
						if (!EpayUtilValidation.getValidateDynamicField(
								inputParams.get(formControl.getRequestVarname()).toString(),
								formControl.getFormat().toString())) {
							response.setErrorStatus(ServiceErrorConstants.FAILURE);
							response.setErrorCode("EPAYORG002");
							break;
						}
					}

				} else if (formControl.getControlType().equals("Date")) {

					if (formControl.getFormat() != null) {
						logger.info("validate the Date fields {}", formControl.getRequestVarname());
						if (!EpayUtilValidation.getValidateDynamicField(
								inputParams.get(formControl.getRequestVarname()).toString(),
								formControl.getFormat().toString())) {
							response.setErrorStatus(ServiceErrorConstants.FAILURE);
							response.setErrorCode("EPAYORG002");
							break;
						}
					}

				} else if (formControl.getControlType().equals("Variable")
						|| formControl.getControlType().equals("Option")) {

					if (formControl.getFormat() != null) {
						logger.info("validate the Variable fields {}", formControl.getControlType());
						if (!EpayUtilValidation.getValidateDynamicField(
								inputParams.get(formControl.getRequestVarname()).toString(),
								formControl.getFormat().toString())) {
							response.setErrorStatus(ServiceErrorConstants.FAILURE);
							response.setErrorCode("EPAYORG002");
							break;
						}
					}

				} else if (formControl.getControlType().equals("Fixed")) {

					if (!inputParams.get(formControl.getRequestVarname()).toString().isEmpty()) {
						logger.info("validate the Fixed fields {}", formControl.getRequestVarname());
						if ("0".equals(formControl.getMandatory()) && !inputParams.get(formControl.getRequestVarname())
								.toString().equals(formControl.getDefaultValue())) {
							response.setErrorStatus(ServiceErrorConstants.FAILURE);
							response.setErrorCode("EPAYORG002");
							break;
						}
					}
				}
			}

			logger.info("EpayValidationService - End");

		} catch (Exception exp) {
			response.setErrorStatus(ServiceErrorConstants.FAILURE);
			response.setErrorCode("EPCPAY0004");
		}
		/*errParams =  epayOrgDao.getEpayClassificationDetails((String)(inputParams.get("classificationid")));
		outParams.put("errParams", errParams);*/
		outParams.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);

		return outParams;

	}

}