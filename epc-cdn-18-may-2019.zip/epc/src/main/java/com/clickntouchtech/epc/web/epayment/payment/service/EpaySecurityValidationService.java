
package com.clickntouchtech.epc.web.epayment.payment.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.clickntouchtech.epc.web.framework.exception.EpayBaseResponse;
import com.clickntouchtech.epc.web.framework.service.EpayBaseAbsService;
import com.clickntouchtech.epc.web.framework.service.ServiceErrorConstants;


/**
 * @author Tech M
 * This class used for validate the dynamic fields(Text,Date,Options,Option,Fixed,Mandatory and Variable).
 * May-20-2016
 */

@Service
public class EpaySecurityValidationService extends EpayBaseAbsService	{
	
	private static final Logger logger = LoggerFactory.getLogger(EpaySecurityValidationService.class);
	
	@SuppressWarnings("unchecked")
	public ModelMap epayServiceBase(ModelMap inputParams)	{
		
		logger.info("EpayValidationService - Start");
		
		EpayBaseResponse response = new EpayBaseResponse();
		response.setErrorStatus(ServiceErrorConstants.FAILURE);		
		
		ModelMap outParams = new ModelMap();
		 
		 try{
				
			logger.info("EpayValidationService - End");
			response.setErrorStatus(ServiceErrorConstants.SUCCESS);		
				
		 }catch(Exception exp){
			 response.setErrorStatus(ServiceErrorConstants.FAILURE);
			 response.setErrorCode("EPCPAY0004");
		 }
		 
		 outParams.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
		 
		 return outParams;
		 
	}
	
}