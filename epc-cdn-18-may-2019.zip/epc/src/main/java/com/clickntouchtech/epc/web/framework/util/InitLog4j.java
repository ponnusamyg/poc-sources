package com.clickntouchtech.epc.web.framework.util;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.PropertyConfigurator;

public class InitLog4j extends HttpServlet
{
  private static final long serialVersionUID = 1L;

  public void init() throws ServletException
  {
    //String log4jpath = "/opt/commonlog4j/";
    //String context = getInitParameter("context");
   // String appServerName = "tomcat";
    //log4jpath = log4jpath + File.separator + appServerName + File.separator + context + File.separator + "log4j.properties";
	String log4jpath="/home/ec2-user/log4j.properties";
    System.out.println("Log4j Path : " + log4jpath);
    PropertyConfigurator.configure(log4jpath);
  }
}