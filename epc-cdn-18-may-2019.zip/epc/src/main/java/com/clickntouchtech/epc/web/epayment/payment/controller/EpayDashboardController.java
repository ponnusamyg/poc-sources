package com.clickntouchtech.epc.web.epayment.payment.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mobile.device.Device;
import org.springframework.mobile.device.DeviceUtils;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.clickntouchtech.epc.web.epayment.payment.model.EpayUser;
import com.clickntouchtech.epc.web.epayment.payment.service.EpayDisplayClassificationService;
import com.clickntouchtech.epc.web.epayment.payment.service.EpayOrgDisplayService;
import com.clickntouchtech.epc.web.epayment.payment.service.EpayUserDashBoardService;
import com.clickntouchtech.epc.web.epaysecurity.bean.EpayUsersProfile;
import com.clickntouchtech.epc.web.epaysecurity.service.EpayUserProfileService;
import com.clickntouchtech.epc.web.framework.exception.EpayBaseResponse;
import com.clickntouchtech.epc.web.framework.service.ServiceErrorConstants;
import com.clickntouchtech.epc.web.framework.util.EpayPageConstants;
import com.clickntouchtech.epc.web.framework.util.RandomString;


@Controller
public class EpayDashboardController{
	
	private static final Logger logger = LoggerFactory.getLogger(EpayDashboardController.class);
	
	public static int javaMsgId = 0;
	
	public static final String HOME = "home";
	public static final String SUCCESS = "success";
	public static final String ERROR = "error";
	
	@Autowired
	protected EpayDisplayClassificationService epayDisplayClassificationService;	
	
	@Autowired
	protected EpayOrgDisplayService epayOrgDisplayService;
	
	@Autowired
	protected EpayUserProfileService epayUserProfileService;	
	
	@Autowired
	protected EpayUserDashBoardService epayUserDashBoardService;
	
	
	
	
	
	

	
	@RequestMapping(value = "/epaylogin",method = RequestMethod.GET)
	public String displayEpayHomePage(@RequestHeader(value="User-Agent",required = false) String userAgent,
			HttpServletRequest request,ModelMap modelMap) {
		logger.info("displayEpayHomePage method begins");
		String view = "welcomepage";
    	modelMap.addAttribute("paymentfrom", "ownsite");
    	logger.info("displayHomePage userAgent :::::::::::::::::: {}",userAgent);
    	epayDeviceInfo(userAgent, request);
		logger.info("displayEpayHomePage method ends");
		return view;
	}

	
	@RequestMapping(value = "/epayUserloginsucess",method = RequestMethod.GET)
	public String epayDashBoardSucessPage(HttpServletRequest request,ModelMap modelMap) {
		logger.info("epayDashBoardSucessPage method begins");
		
    	String view = "hidpage";

		logger.info("epayDashBoardSucessPage method ends");
		return view;
	}


	/**
	 * @param userAgent
	 * @param request
	 */
	private void epayDeviceInfo(String userAgent, HttpServletRequest request) {
		Device device = DeviceUtils.getCurrentDevice(request);
    	if(device!=null){
    		// to check Device Type .....
       	 String deviceType = EpayPageConstants.EPAY_DEVICETYPE_UNKNOWN;
            if (device.isNormal()) {
                deviceType = EpayPageConstants.EPAY_DEVICETYPE_DESKTOP;
            } else if (device.isMobile()) {
            	Pattern pattern = Pattern.compile("(wv)");
                Matcher matcher = pattern.matcher(userAgent);
                if (matcher.find())
                deviceType = EpayPageConstants.EPAY_DEVICETYPE_MOBILE+"-"+matcher.group(1);
                else
                deviceType = EpayPageConstants.EPAY_DEVICETYPE_MOBILE;

            } else if (device.isTablet()) {
                deviceType = EpayPageConstants.EPAY_DEVICETYPE_TABLET;
            }
            logger.info("Device Type ::::::{}",deviceType);
            //session.setAttribute("deviceType",deviceType);
    	}
	}
	
	
 	
    @RequestMapping(value="logout",method = RequestMethod.POST)
    public String logoutInfo(HttpServletRequest request) {
    	logger.info("logoutPage method begins");
    	HttpSession session = request.getSession(false);
    	 SecurityContextHolder.clearContext();
    	if(session != null){
       	 session.invalidate();
      	}
		logger.info("logoutPage method end");
        return "logout";
    }
    
    @RequestMapping(value="sessiontimeout",method = {RequestMethod.POST})
    public String sessionValidate(HttpServletRequest request) {
    	logger.info("sessiontimeoutv method begins");
    	HttpSession session = request.getSession(false);
    	 SecurityContextHolder.clearContext();
    	if(session != null){
    		logger.info("session invalidate inside");
    	 session.invalidate();
    	}
		logger.info("sessiontimeout method end");
        return "sessiontimeout";
    }
    
    @RequestMapping(value="errorpage",method = {RequestMethod.POST})
    public String epayError(HttpServletRequest request) {
    	logger.info("errorPage method begins");
    	HttpSession session = request.getSession(false);
    	 SecurityContextHolder.clearContext();
    	if(session != null){
    	 session.invalidate();
    	}
		logger.info("errorPage method end");
        return "duetotecherror";
    }
    
    @RequestMapping(value = "/epcu/epayudashboard",method = RequestMethod.GET)
 	public String epayusrdashboard(@RequestHeader(value="User-Agent",required = false) String userAgent,
			HttpServletRequest request,ModelMap modelMap) {
 		logger.info("epayusrdashboard method begins");
 		ModelMap inParams = new ModelMap();             
     	ModelMap outParams = new ModelMap();
     	ModelMap outParams2 = new ModelMap();
     	HttpSession sessionext = request.getSession(false);
     	sessionext.setAttribute("reqtUserid", getEpayLoggedUser());
    	inParams.put("userId", getEpayLoggedUser());
    	outParams=epayUserProfileService.epayServiceBase(inParams);
    	outParams2=epayUserDashBoardService.execute(inParams);
    	logger.info("outParams2 outParams2 :::::::::::::::::: {}",outParams2.get("loginCount"));
    	EpayUsersProfile epayUsersProfile=(EpayUsersProfile)outParams.get("usersProfile");
    	if(sessionext != null){
    		sessionext.setAttribute("usersProfile",epayUsersProfile);   
    	}
    	logger.info("epayusrdashboard  result :::::::::{}",epayUsersProfile.getName());
     	String view = EpayPageConstants.EPAY_USER_DASHBOARD;
    	modelMap.addAttribute("logoinCount", outParams2.get("loginCount"));
    	modelMap.addAttribute("txnSuccessCount", outParams2.get("txnSuccessCount"));
    	modelMap.addAttribute("txnCount", outParams2.get("txnCount"));
    	modelMap.addAttribute("topTransactions", outParams2.get("topTransactions"));
    	modelMap.addAttribute("successTxn", outParams2.get("successTxn"));
    	modelMap.addAttribute("failureTxn", outParams2.get("failureTxn"));
    	modelMap.addAttribute("usersLoginDetail", outParams2.get("usersLoginDetail"));
    	
    	logger.info("topTransactions :::::::::::::::::: {}",outParams2.get("topTransactions"));
     	logger.info("userAgent :::::::::::::::::: {}",userAgent);
     	logger.info("displayHomePage userAgent :::::::::::::::::: {}",userAgent);
     	epayDeviceInfo(userAgent, request);
 		logger.info("epayusrdashboard method ends");
 		return view;
 	}
         
     @RequestMapping(value = "/epca/epayadashboard",method = RequestMethod.GET)
 	public String epayadashboard(@RequestHeader(value="User-Agent",required = false) String userAgent,
			HttpServletRequest request,ModelMap modelMap) {
 		logger.info("epayadashboard method begins");
 		ModelMap inParams = new ModelMap();             
     	ModelMap outParams = new ModelMap();
     	HttpSession sessionext = request.getSession(false);
     	inParams.put("userId", getEpayLoggedUser());
    	outParams=epayUserProfileService.epayServiceBase(inParams);
    	EpayUsersProfile epayUsersProfile=(EpayUsersProfile)outParams.get("usersProfile");
    	if(sessionext != null){
    		sessionext.setAttribute("usersProfile",epayUsersProfile);   
    	}
    	logger.info("epayadashboard  result :::::::::{}",epayUsersProfile.getName());
     	     	
     	String view = "admindashboard";
     	modelMap.addAttribute("paymentfrom", "ownsite");
     	logger.info("displayHomePage userAgent :::::::::::::::::: {}",userAgent);
     	epayDeviceInfo(userAgent, request);
 		logger.info("epayadashboard method ends");
 		return view;
 	}
     
     
     @RequestMapping(value = "/profile",method = RequestMethod.GET)
 	public String displayProfile(@RequestHeader(value="User-Agent",required = false) String userAgent,
			HttpServletRequest request,ModelMap modelMap) {
		logger.info("displayHomePage method begins");
		String view = "epayuserprofile";
		logger.info("displayHomePage userAgent :::::::::::::::::: {}", userAgent);
		epayDeviceInfo(userAgent, request);
		logger.info("displayHomePage method ends");
		return view;
	}
     /**
      * 
      * @return
      */
     @RequestMapping(value = "/epcu/organization", method = {RequestMethod.POST,RequestMethod.GET})
     public String showEpayOrganisation(HttpServletRequest request,ModelMap modelMap,@RequestHeader(value="ClientIP",required = false) String clientIp,@RequestHeader(value="User-Agent",required = false) String userAgent) {
     	logger.info("showEpayOrganisation method begin");
     	
       	ModelMap inParams = new ModelMap();  
     	ModelMap outParams = new ModelMap();
     	
     	HttpSession session = request.getSession(false);
     	
     	String deviceType = (String)session.getAttribute("deviceType");   
     	session.setAttribute("epayUser", this.getEpayUser("0", clientIp, deviceType));
     	EpayUser user = (EpayUser) session.getAttribute("epayUser");
     	HashMap<String,Object> cacheMap = (HashMap) user.getUserCache();
 		logger.info("sesion map size:{}",cacheMap.size());
     	
     	outParams = epayOrgDisplayService.epayServiceBase(inParams);
     	modelMap.addAllAttributes(outParams);
         
     	if(logger.isDebugEnabled())
     		logger.info("showEpayOrganisation method end {}",modelMap);
     	
         logger.info("showEpayOrganisation method size {}",modelMap.size());
     	logger.info("showEpayOrganisation method end");
         return "listinstitute";
         
     }

     /**
      * 
      * @return
      */
     @RequestMapping(value = "/epcu/classicication", method = RequestMethod.POST)
     public String showEpayClassification(@RequestParam("organizationId") String organizationId,@RequestParam("orgstate") String orgstate,HttpServletRequest request,ModelMap modelMap) {
     	logger.info("showEpayClassification method begin");
       	ModelMap inParams = new ModelMap();  
     	ModelMap outParams = new ModelMap();
     	HttpSession session =request.getSession(false);
     	inParams.addAttribute("organizationId", organizationId);
     	inParams.addAttribute("orgstate", orgstate);
     	outParams = epayDisplayClassificationService.epayServiceBase(inParams);
     	EpayBaseResponse appResponse = (EpayBaseResponse)outParams.get(ServiceErrorConstants.APPLICATION_RESPONSE);        
     	if("success".equals(appResponse.getErrorStatus()))
     	{
     		List classificationOrgList = (List) outParams.get("classificationOrgList");
     		EpayUser user = (EpayUser) session.getAttribute("epayUser");
     		HashMap<String,Object> cacheMap = (HashMap) user.getUserCache();
     		logger.info("sesion map size:{}",cacheMap.size());
     		cacheMap.put("classificationOrgList", classificationOrgList);
     		String encKey = this.getEpayKey();
     		logger.info("encKey: {}",encKey);
     		cacheMap.put("encKey", encKey);
     		user.setUserCache(cacheMap);
     		modelMap.addAttribute("encKey", encKey);
     	}
     	modelMap.addAllAttributes(outParams);
         
     	if(logger.isDebugEnabled())
     		logger.info("showEpayClassification method end {}",modelMap);
     	
         logger.info("showEpayClassification method size {}",modelMap.size());
     	logger.info("showEpayClassification method end");
         return "classification";
     }
     
     
     public String getEpayLoggedUser() {
         Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
         return (!(authentication instanceof AnonymousAuthenticationToken)) ? authentication.getName() : null;
     }
     
     /**
      * 
      * @return UserObject
      */
 	private EpayUser getEpayUser(String bankCode,String userIP, String deviceType) {
 		EpayUser user = new EpayUser();
 		List  arrayList = new ArrayList();
 		arrayList.add("1");
 		Map<String,Object> hashMap = new HashMap<String,Object>();
 		user.setBankCode(bankCode);
 		user.setKioskID(getEpayUserID());
 		user.setUserAlias(getEpayLoggedUser());
 		user.setCorporateId("card");
 		user.setUserIPaddress(userIP);
 		user.setUserState("0");
 		user.setUserType(new Integer(0));
 		user.setUserRole(arrayList);
 		user.setUserCache(hashMap);
 		user.setChannelType(deviceType);
 		return user;
 	}
     
 	public synchronized String getEpayUserID() {
 		
 		try{
 			synchronized(this){
 				if(javaMsgId == 999999)
 				{
 					javaMsgId = 0;
 				}
 				else
 					javaMsgId++;
 			}
 		}catch (Exception ex) {
 			logger.error("Exception :",ex);
 		}
 		return new Integer(javaMsgId).toString();		
 	}

 	
 	private String getEpayKey() {
 		return RandomString.getRandomString();
 	}
    
}

