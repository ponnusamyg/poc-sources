
package com.clickntouchtech.epc.web.framework.tags;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;

import com.clickntouchtech.epc.web.framework.util.NumberToWords;
import com.clickntouchtech.epc.web.framework.util.RupeeAmountInWords;

public class NumberToWordsTag  extends BodyTagSupport{
        public int doAfterBody() throws JspException {
        String number=bodyContent.getString().trim();
        BodyContent body = getBodyContent();
        JspWriter out = body.getEnclosingWriter();
        try {
            RupeeAmountInWords numberToWords = new RupeeAmountInWords();
            String words = numberToWords.getWordsFormat(number);
            out.println(words);
        } catch (IOException ioException) {
            throw new JspException("NUMBER TO WORD CONVERSION ERROR",ioException);
        }
        return EVAL_PAGE;
    }
}  