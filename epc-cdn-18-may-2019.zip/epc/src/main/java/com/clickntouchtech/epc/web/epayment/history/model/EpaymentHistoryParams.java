package com.clickntouchtech.epc.web.epayment.history.model;

import com.clickntouchtech.epc.web.epayment.payment.model.EpayBaseModel;

public class EpaymentHistoryParams implements EpayBaseModel{
	private Double totalAmount;
	private Double transactionAmount;
	private Double commissionAmount;
	private String thirdPartyref;
	private String beneficiary;
	private String dob;
	private String mobile_no;
	private String narrative1;
	private String narrative2;
	private String narrative3;
	private String paymentMode;
	private String bankCode;
	private String refenceNo;
	private String onlineDebitStatus;
	private String commFrom;
	private String trnFrom;
	private String classification;
	private String organizationName;
	private String organizationType;
	/**
	 * @return the role
	 */
	public String getRole() {
		return role;
	}
	/**
	 * @param role the role to set
	 */
	public void setRole(String role) {
		this.role = role;
	}
	private String role;
	
	 private String status_description;
	public String getStatus_description() {
		return status_description;
	}
	public void setStatus_description(String status_description) {
		this.status_description = status_description;
	}
	public String getCommFrom() {
		return commFrom;
	}
	public void setCommFrom(String commFrom) {
		this.commFrom = commFrom;
	}
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public Double getTransactionAmount() {
		return transactionAmount;
	}
	public void setTransactionAmount(Double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}
	public Double getCommissionAmount() {
		return commissionAmount;
	}
	public void setCommissionAmount(Double commissionAmount) {
		this.commissionAmount = commissionAmount;
	}
	public String getThirdPartyref() {
		return thirdPartyref;
	}
	public void setThirdPartyref(String thirdPartyref) {
		this.thirdPartyref = thirdPartyref;
	}
	public String getBeneficiary() {
		return beneficiary;
	}
	public void setBeneficiary(String beneficiary) {
		this.beneficiary = beneficiary;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(String mobile_no) {
		this.mobile_no = mobile_no;
	}
	public String getNarrative1() {
		return narrative1;
	}
	public void setNarrative1(String narrative1) {
		this.narrative1 = narrative1;
	}
	
	public String getNarrative3() {
		return narrative3;
	}
	public void setNarrative3(String narrative3) {
		this.narrative3 = narrative3;
	}
	public String getTrnFrom() {
		return trnFrom;
	}
	public void setTrnFrom(String trnFrom) {
		this.trnFrom = trnFrom;
	}
	 
	public String toString()
    {
        StringBuffer tempStringBuf= new StringBuffer();
        tempStringBuf.append("totalAmount:");            
        tempStringBuf.append(totalAmount);
        tempStringBuf.append("|");
        tempStringBuf.append("transactionAmount:");            
        tempStringBuf.append(transactionAmount);
        tempStringBuf.append("|");
        tempStringBuf.append("commissionAmount:");            
        tempStringBuf.append(commissionAmount);
        tempStringBuf.append("|");
        tempStringBuf.append("onlineDebitStatus:");            
        tempStringBuf.append(onlineDebitStatus);
        tempStringBuf.append("|");
        tempStringBuf.append("thirdPartyref:");
        tempStringBuf.append(thirdPartyref);
        tempStringBuf.append("|");
        tempStringBuf.append("beneficiary:");
        tempStringBuf.append(beneficiary);           
        tempStringBuf.append("|");
        tempStringBuf.append("dob:");            
        tempStringBuf.append(dob);
        tempStringBuf.append("|");
        tempStringBuf.append("mobile_no:");
        tempStringBuf.append(mobile_no);
        tempStringBuf.append("|");
        tempStringBuf.append("narrative1:");
        tempStringBuf.append(narrative1);
        tempStringBuf.append("|");
        tempStringBuf.append("narrative2:");      
        tempStringBuf.append(narrative2);
        tempStringBuf.append("|");
        tempStringBuf.append("narrative3:");
        tempStringBuf.append(narrative3);
        tempStringBuf.append("|");
        tempStringBuf.append("commFrom:");
        tempStringBuf.append(commFrom);
        tempStringBuf.append("|");
        tempStringBuf.append("trnFrom:");
        tempStringBuf.append(trnFrom);
        tempStringBuf.append("|");
        tempStringBuf.append("organizationType:");
        tempStringBuf.append(organizationType);
        
        
        return tempStringBuf.toString();
                
    }
	public String getRefenceNo() {
		return refenceNo;
	}
	public void setRefenceNo(String refenceNo) {
		this.refenceNo = refenceNo;
	}
	public Double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getNarrative2() {
		return narrative2;
	}
	public void setNarrative2(String narrative2) {
		this.narrative2 = narrative2;
	}
	public String getOnlineDebitStatus() {
		return onlineDebitStatus;
	}
	public void setOnlineDebitStatus(String onlineDebitStatus) {
		this.onlineDebitStatus = onlineDebitStatus;
	}
	public void setEchequeAmount(String string) {
		// TODO Auto-generated method stub
		
	}
	/**
	 * @return the classification
	 */
	public String getClassification() {
		return classification;
	}
	/**
	 * @param classification the classification to set
	 */
	public void setClassification(String classification) {
		this.classification = classification;
	}
	/**
	 * @return the organizationName
	 */
	public String getOrganizationName() {
		return organizationName;
	}
	/**
	 * @param organizationName the organizationName to set
	 */
	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}
	/**
	 * @return the organizationType
	 */
	public String getOrganizationType() {
		return organizationType;
	}
	/**
	 * @param organizationType the organizationType to set
	 */
	public void setOrganizationType(String organizationType) {
		this.organizationType = organizationType;
	}
	
}
