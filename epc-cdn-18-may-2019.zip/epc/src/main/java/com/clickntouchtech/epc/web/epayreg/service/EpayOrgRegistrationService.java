package com.clickntouchtech.epc.web.epayreg.service;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.clickntouchtech.epc.web.epayreg.dao.EpayRegistrationDao;
import com.clickntouchtech.epc.web.framework.exception.EpayApplicationException;
import com.clickntouchtech.epc.web.framework.exception.EpayBaseResponse;
import com.clickntouchtech.epc.web.framework.exception.EpayDaoException;
import com.clickntouchtech.epc.web.framework.service.EpayBaseAbsService;
import com.clickntouchtech.epc.web.framework.service.ServiceErrorConstants;
import com.clickntouchtech.epc.web.framework.util.EmailUtils;

@Service
public class EpayOrgRegistrationService extends EpayBaseAbsService {

	private static final Logger logger = LoggerFactory.getLogger(EpayOrgRegistrationService.class);

	@Autowired
	private EpayRegistrationDao epayRegistrationDao;

	public ModelMap execute(Map inputParams) {

		logger.info("EpayOrgRegistrationService execute method begins");
		logger.debug("inputparams Map: {}", inputParams);

		ModelMap outParams = new ModelMap();
		Map responseParams = new HashMap();
		EpayBaseResponse response = new EpayBaseResponse();
		response.setErrorStatus(ServiceErrorConstants.FAILURE);
		if (inputParams != null) {
			try {
				Map mailParams = new HashMap();
				if (inputParams.get("serviceType").equals("generate_password")) {

					Map responseParam = new HashMap();
					responseParam = epayRegistrationDao.epayOrgAuthendication(inputParams);
					String registrationId = (String) responseParam.get("registrationId");
					String organizationname = (String) responseParam.get("organizationname");
					String emailId = (String) responseParam.get("emailId");
					String status = (String) responseParam.get("status");
					mailParams.put("name", organizationname);
					mailParams.put("emailid", emailId);
					mailParams.put("loginId", registrationId);
					if (status.equals("profile_created")) {
						String domainUrl=(String) inputParams.get("domainUrl");
						EmailUtils.sendPasswordRestConfirmMail(mailParams,domainUrl);
						response.setErrorStatus(ServiceErrorConstants.SUCCESS);
					} else {
						response.setErrorStatus(ServiceErrorConstants.FAILURE);
						response.setErrorMessage("New Organazation Registration Failed!");
					}

				}else if (inputParams.get("serviceType").equals("generate_user_password")) {

					Map responseParam = new HashMap();
					responseParam = epayRegistrationDao.epayUserAuthendication(inputParams);
					
					String registrationId = (String) responseParam.get("registrationId");
					String name = (String) responseParam.get("name");
					String emailId = (String) responseParam.get("emailId");
					String status = (String) responseParam.get("status");
					mailParams.put("name", name);
					mailParams.put("emailid", emailId);
					mailParams.put("loginId", registrationId);
					if (status.equals("profile_created")) {
						String domainUrl=(String) inputParams.get("domainUrl");
						EmailUtils.sendPasswordRestConfirmMail(mailParams,domainUrl);
						response.setErrorStatus(ServiceErrorConstants.SUCCESS);
					} else {
						response.setErrorStatus(ServiceErrorConstants.FAILURE);
						response.setErrorMessage("New Organazation Registration Failed!");
					}

				}  else {

					responseParams = epayRegistrationDao.epayOrgRegistration(inputParams);
					String status = (String) responseParams.get("status");
					if (status.equals("success")) {
						String domainUrl=(String) inputParams.get("domainUrl");
						EmailUtils.sendOrgRegMail(responseParams,domainUrl);
						response.setErrorStatus(ServiceErrorConstants.SUCCESS);

					} else {
						response.setErrorStatus(ServiceErrorConstants.FAILURE);
						response.setErrorMessage("New Organazation Registration Failed!");
					}

				}

			} catch (EpayApplicationException cmsexp) {
				cmsexp.printStackTrace();
				response.setErrorCode("V101");
			} catch (EpayDaoException daoexp) {
				daoexp.printStackTrace();
				response.setErrorCode("V101");
			}

		}

		outParams.addAttribute(ServiceErrorConstants.APPLICATION_RESPONSE, response);
		logger.debug("outParams Map contains: {}", outParams);
		logger.info("EpayOrgRegistrationService execute method end{}");
		return outParams;

	}
}