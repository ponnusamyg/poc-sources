package com.clickntouchtech.epc.web.epaysecurity.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;

public class EpayAuthenticationEntryPoint extends LoginUrlAuthenticationEntryPoint {
	private static final Logger logger = LoggerFactory.getLogger(EpayAuthenticationEntryPoint.class); 

    private final RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();

    public EpayAuthenticationEntryPoint(final String loginFormUrl) {
        super(loginFormUrl);
    	logger.info("EpayAuthenticationEntryPoint con--- {}",this.getLoginFormUrl());
    }

    /**
     * Performs the redirect (or forward) to the login form URL.
     */
    public void commence(HttpServletRequest request, HttpServletResponse response,
                         AuthenticationException authException) throws IOException, ServletException {

        // redirect to login page. Use https if forceHttps true
    	logger.info("EpayAuthenticationEntryPoint --- {}",this.getLoginFormUrl());
        String redirectUrl = buildRedirectUrlToLoginPage(request, response, authException);
        redirectStrategy.sendRedirect(request, response, redirectUrl);
    }

}