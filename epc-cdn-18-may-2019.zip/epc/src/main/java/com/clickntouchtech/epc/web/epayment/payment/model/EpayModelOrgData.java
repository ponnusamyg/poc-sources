package com.clickntouchtech.epc.web.epayment.payment.model;

import java.util.List;

public class EpayModelOrgData implements EpayBaseModel {

	private String orgstate;
	private String orgtype;
	private String organizationId;
	private String organizationrootname;
	private String orgrootId;
	private String organizationname;
	private String orgaddress;
	private String status;
	private List classificationList;


	/**
	 * @return the orgstate
	 */
	public String getOrgstate() {
		return orgstate;
	}

	/**
	 * @param orgstate
	 *            the orgstate to set
	 */
	public void setOrgstate(String orgstate) {
		this.orgstate = orgstate;
	}

	/**
	 * @return the orgtype
	 */
	public String getOrgtype() {
		return orgtype;
	}

	/**
	 * @param orgtype
	 *            the orgtype to set
	 */
	public void setOrgtype(String orgtype) {
		this.orgtype = orgtype;
	}

	/**
	 * @return the organizationId
	 */
	public String getOrganizationId() {
		return organizationId;
	}

	/**
	 * @param organizationId
	 *            the organizationId to set
	 */
	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}

	/**
	 * @return the organizationrootname
	 */
	public String getOrganizationrootname() {
		return organizationrootname;
	}

	/**
	 * @param organizationrootname
	 *            the organizationrootname to set
	 */
	public void setOrganizationrootname(String organizationrootname) {
		this.organizationrootname = organizationrootname;
	}

	/**
	 * @return the orgrootId
	 */
	public String getOrgrootId() {
		return orgrootId;
	}

	/**
	 * @param orgrootId
	 *            the orgrootId to set
	 */
	public void setOrgrootId(String orgrootId) {
		this.orgrootId = orgrootId;
	}

	/**
	 * @return the organizationname
	 */
	public String getOrganizationname() {
		return organizationname;
	}

	/**
	 * @param organizationname
	 *            the organizationname to set
	 */
	public void setOrganizationname(String organizationname) {
		this.organizationname = organizationname;
	}

	/**
	 * @return the orgaddress
	 */
	public String getOrgaddress() {
		return orgaddress;
	}

	/**
	 * @param orgaddress
	 *            the orgaddress to set
	 */
	public void setOrgaddress(String orgaddress) {
		this.orgaddress = orgaddress;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the classificationList
	 */
	public List getClassificationList() {
		return classificationList;
	}

	/**
	 * @param classificationList
	 *            the classificationList to set
	 */
	public void setClassificationList(List classificationList) {
		this.classificationList = classificationList;
	}


}
