package com.clickntouchtech.epc.web.epayment.history.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.clickntouchtech.epc.web.epayment.history.dao.EpaymentHistoryDao;
import com.clickntouchtech.epc.web.framework.exception.EpayApplicationException;
import com.clickntouchtech.epc.web.framework.exception.EpayBaseResponse;
import com.clickntouchtech.epc.web.framework.exception.EpayDaoException;
import com.clickntouchtech.epc.web.framework.service.EpayBaseAbsService;
import com.clickntouchtech.epc.web.framework.service.ServiceErrorConstants;


@Service
public class EpaymentHistoryService extends EpayBaseAbsService {
	
	private static final Logger logger = LoggerFactory.getLogger(EpaymentHistoryService.class);
	
	@Autowired
	private EpaymentHistoryDao epaymentHistoryDao;
	
	public ModelMap execute(ModelMap inputParams) {
		logger.info("EpayHomeService execute method begins");
		if (logger.isDebugEnabled())
			logger.debug("inputparams Map: {}",inputParams);
		
		ModelMap outParams = new ModelMap();
		EpayBaseResponse response = new EpayBaseResponse();
		response.setErrorStatus(ServiceErrorConstants.FAILURE);	
		
		try {		
		
			String userId = (String)inputParams.get("userId");
			 
		
			List overAllPaymentHistoryDetails = null;
			
			if(userId!=null && !userId.isEmpty()) {
				overAllPaymentHistoryDetails = epaymentHistoryDao.getOverAllPaymentHistory(userId);
				logger.info("overAllPaymentHistoryDetails size{}", overAllPaymentHistoryDetails.size());
//				outParams.addAttribute("overAllPaymentHistoryDetails", overAllPaymentHistoryDetails);
//				outParams.addAttribute("overAllPaymentHistoryDetailsSize", overAllPaymentHistoryDetails.size());
			}
			if( overAllPaymentHistoryDetails!=null && overAllPaymentHistoryDetails.size()>0 ) {
        		outParams.put("overAllPaymentHistoryDetails" ,overAllPaymentHistoryDetails);
            	response.setErrorStatus(ServiceErrorConstants.SUCCESS);
            } else {	        	
	        	logger.info("institution List for the selected state and type is null or empty");
	            response.setErrorStatus(ServiceErrorConstants.FAILURE);
	            response.setErrorCode("EPAYORG001");	
            }
	        
		
		response.setErrorStatus(ServiceErrorConstants.SUCCESS);
		
        }catch(EpayApplicationException cmsexp){
        	cmsexp.printStackTrace();
        	response.setErrorCode("V101");
		}catch (EpayDaoException daoexp) {
			response.setErrorCode(daoexp.getErrorCode());
		}
		
		outParams.addAttribute(ServiceErrorConstants.APPLICATION_RESPONSE, response);
		
		if (logger.isDebugEnabled())
			logger.debug("outParams Map contains: {}",outParams);
		
		logger.info("EpayHomeService execute method end");
		
		return outParams;
	}
}
