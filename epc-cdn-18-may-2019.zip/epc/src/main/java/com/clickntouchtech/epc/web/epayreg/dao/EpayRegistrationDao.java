package com.clickntouchtech.epc.web.epayreg.dao;

import java.util.List;
import java.util.Map;

import org.springframework.ui.ModelMap;

import com.clickntouchtech.epc.web.epaysecurity.bean.EpayUsersProfile;

public interface EpayRegistrationDao {

	public Map epayOrgRegistration(Map registerParams);

	public EpayUsersProfile getOrgRegistrationProfile(ModelMap inParams);

	public List getOrgRegistrationStatus(String orgId);

	public Map epayUserRegistration(Map registerParams);

	public int getAuthPendingList(Map inParams);

	public Map epayOrgAuthendication(Map inParams);

	public int getUserAuthPendingList(Map inParams);

	public EpayUsersProfile getUserRegistrationProfile(ModelMap inParams);

	public Map epayUserAuthendication(Map inParams);

	public int getUserRegistrationCheck(Map inputParams);

}
