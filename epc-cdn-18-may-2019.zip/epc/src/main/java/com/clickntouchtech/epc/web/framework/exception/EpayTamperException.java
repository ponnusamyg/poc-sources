package com.clickntouchtech.epc.web.framework.exception;

import org.apache.log4j.Logger;

public class EpayTamperException extends RuntimeException {
    
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected final static Logger logger = Logger.getLogger(EpayTamperException.class);   

    public String errorCode;

    public String errorDescription;
    
    private Exception exception;
    
    public EpayTamperException(String errorCode){
        this.errorCode = errorCode;
    }
    public EpayTamperException(Exception exception,String errorCode){
        this.errorCode = errorCode;
        this.exception = exception;
    }
    public String getErrorCode() {
        return errorCode;
    }
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }
    public String getErrorDescription() {
        return errorDescription;
    }
    public void setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
    }

}
