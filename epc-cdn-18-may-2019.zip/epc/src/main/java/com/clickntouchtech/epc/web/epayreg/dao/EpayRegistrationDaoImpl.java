package com.clickntouchtech.epc.web.epayreg.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.ui.ModelMap;

import com.clickntouchtech.epc.web.epayment.payment.dao.EpayTransactionDAOImpl;
import com.clickntouchtech.epc.web.epaysecurity.bean.EpayUsersProfile;
import com.clickntouchtech.epc.web.framework.exception.EpayDaoException;
import com.clickntouchtech.epc.web.framework.util.ErrorConstants;
import com.clickntouchtech.epc.web.framework.util.RandomString;

@Repository
public class EpayRegistrationDaoImpl implements EpayRegistrationDao {

	protected final Logger logger = LoggerFactory.getLogger(EpayTransactionDAOImpl.class);

	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.setJdbcTemplate(new JdbcTemplate(dataSource));
	}

	public Map epayOrgRegistration(Map registerParams) throws EpayDaoException {
		logger.info("epayOrgRegistration dao bagin: {}");
		logger.info("registerParams Map: {}", registerParams);
		Map responseMap = new HashMap();
		responseMap.put("STATUS", "FAILED");
		String registrationStatus = "FAILED";
		try {
			String registrationId = "EPCREG00" + getePayRegRefNo("epay_org_userid_sequence")
					+ RandomString.getRandomString();
			String organizationname = (String) registerParams.get("orgName");
			String orgtype = (String) registerParams.get("orgType");
			String orgsubtype = (String) registerParams.get("orgSubType");
			String address = (String) registerParams.get("orgaddress");
			String district = (String) registerParams.get("district");
			String state = (String) registerParams.get("state");
			String pincode = (String) registerParams.get("pincode");
			String phoneno = (String) registerParams.get("phoneNo");
			String emailid = (String) registerParams.get("email");
			String prooftype = (String) registerParams.get("typeOfProof");
			String proofvalue = (String) registerParams.get("proofValue");
			String proofdocument = (String) registerParams.get("proofdocument");
			String verificationstatus = (String) registerParams.get("verificationstatus");
			String verificationstatusdesc = (String) registerParams.get("verificationstatusdesc");

			Object[] parameters = new Object[] { registrationId, organizationname, orgtype, orgsubtype, address,
					district, state, pincode, phoneno, emailid, prooftype, proofvalue, proofdocument,
					verificationstatusdesc };

			int[] sqlTypes = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
					Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
					Types.VARCHAR, Types.VARCHAR };

			String qry = "insert into epayorgregistration (registrationid,organizationname,orgtype,orgsubtype,address,district,state,pincode,phoneno,emailid,prooftype,"
					+ " proofvalue,proofdocument,verificationstatus,verificationstatusdesc,creationtime)"
					+ " values ( ?,?,?,?,?,?,?,?,?,?,?,?,?,'pending',?,sysdate());";

			int updateCount = getJdbcTemplate().update(qry, parameters, sqlTypes);

			if (updateCount > 0) {
				responseMap.put("registrationId", registrationId);
				responseMap.put("registredMailId", emailid);
				responseMap.put("organizationname", organizationname);
				responseMap.put("orgType", orgtype);
				responseMap.put("orgSubType", orgsubtype);
				responseMap.put("organizationname", organizationname);
				responseMap.put("status", "success");

				/*
				 * String loginId = "EPCL" +
				 * getePayRegRefNo("epay_org_userid_sequence");
				 * 
				 * Object[] loginProfilePparameters = new Object[] {
				 * organizationname, loginId, loginId, organizationId, emailid,
				 * phoneno, address, state, district, pincode }; int[]
				 * sqlProfileTypes = { Types.VARCHAR, Types.VARCHAR,
				 * Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
				 * Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };
				 * 
				 * String loginProfileQry =
				 * "insert into epay_users_profile (name,loginid,password,instituteid,mailid,phoneno,countrycode,"
				 * + " address,state,district,pincode,userrole,userstatus) " +
				 * "values ( ?,?,?,?,?,?,'91',?,?,?,?,'8','1')";
				 * responseMap.put("organizationname", organizationname);
				 * responseMap.put("emailid", emailid);
				 * responseMap.put("organizationId", organizationId);
				 * 
				 * int createProfileCount =
				 * getJdbcTemplate().update(loginProfileQry,
				 * loginProfilePparameters,sqlProfileTypes);
				 * 
				 */
				logger.info("epayOrgRegistration Successful ::{}");
			}

			logger.info("Record inserted to epayUsersPayLoginHistory");
		} catch (DataAccessException daoExp) {
			logger.error("exception is ::{} ", daoExp);
			EpayDaoException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("epayOrgRegistration dao end: {}");

		return responseMap;
	}

	public String getePayRegRefNo(String sequence) {
		logger.info("getePayRegRefNo - begins{}");
		String refNo = "";
		String sqlQuery = null;
		try {
			if (sequence.equals("epay_orgreg_sequence")) {
				sqlQuery = "SELECT nextval('epay_orgreg_sequence') as next_sequence";
			} else if (sequence.equals("epay_org_userid_sequence")) {
				sqlQuery = "SELECT nextval('epay_org_userid_sequence') as next_sequence";
			} else if (sequence.equals("epay_userid_sequence")) {
				sqlQuery = "SELECT nextval('epay_userid_sequence') as next_sequence";
			} else if (sequence.equals("epay_org_sequence")) {
				sqlQuery = "SELECT nextval('epay_org_sequence') as next_sequence";
			} else if (sequence.equals("epay_user_reg_sequence")) {
				sqlQuery = "SELECT nextval('epay_user_reg_sequence') as next_sequence";
			}

			logger.info("sqlQuery :: {}", sqlQuery);
			refNo = (String) getJdbcTemplate().queryForObject(sqlQuery, String.class);
			logger.info("refNo :: {}", refNo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info("getePayRegRefNo - end{}");
		return refNo;
	}

	public EpayUsersProfile getOrgRegistrationProfile(ModelMap inParams) {
		EpayUsersProfile usersProfilethis = null;
		String registrationId = (String) inParams.get("registrationId");
		String organaizationName = (String) inParams.get("organaizationName");
		String emailId = (String) inParams.get("emailId");

		try {
			String sql = "select registrationid, organizationname, orgtype, orgsubtype, address, district, state, pincode,phoneno, emailid, prooftype, proofvalue,"
					+ " verificationstatus, verificationstatusdesc from epayorgregistration "
					+ " where registrationid=? and organizationname= ? and emailid= ?";
			usersProfilethis = (EpayUsersProfile) this.jdbcTemplate.queryForObject(sql,
					new Object[] { registrationId, organaizationName, emailId }, new OrgRegDetails());
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception occured :{}", dataAccessException);
			EpayDaoException.throwException("SUV001");
		} catch (EpayDaoException incorrectResultSizeDataAccessException) {
			logger.error("Exception occured :{}", incorrectResultSizeDataAccessException);
			EpayDaoException.throwException("SUV001");
		}

		// TODO Auto-generated method stub
		return usersProfilethis;
	}

	private class OrgRegDetails implements RowMapper {
		public Object mapRow(ResultSet rs, int arg1) throws SQLException {
			EpayUsersProfile regParams = new EpayUsersProfile();
			regParams.setOrganizationId(rs.getString("registrationid"));
			regParams.setOrganizationname((rs.getString("organizationname")));
			regParams.setOrgtype(rs.getString("orgtype"));
			regParams.setOrgsubtype((rs.getString("orgsubtype")));
			regParams.setAddress(rs.getString("address"));
			regParams.setDistrict((rs.getString("district")));
			regParams.setState(rs.getString("state"));
			regParams.setPincode((rs.getString("pincode")));
			regParams.setPhoneno(rs.getString("phoneno"));
			regParams.setEmailid((rs.getString("emailid")));
			regParams.setProoftype(rs.getString("prooftype"));
			regParams.setProofvalue((rs.getString("proofvalue")));
			regParams.setVerificationstatus(rs.getString("verificationstatus"));
			regParams.setVerificationstatusdesc((rs.getString("verificationstatusdesc")));
			return regParams;
		}
	}

	public List getOrgRegistrationStatus(String registrationid) {
		logger.debug("getOrgRegistrationStatus(String userId) begins");
		List orgRegistrationStatus = new ArrayList();
		Object[] queryParams = { registrationid };
		logger.info("Params:::{}", queryParams);
		try {
			orgRegistrationStatus = (List) getJdbcTemplate().query(
					"select registrationid,verificationtype,verificationstatus from epayorgverificationstatus where  registrationid=? ",
					queryParams, new OrgRegistrationStatus());
			logger.info("orgRegistrationStatus Size:{}", orgRegistrationStatus.size());
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception occured :{}", dataAccessException);
			EpayDaoException.throwException("SUV001");
		} catch (EpayDaoException incorrectResultSizeDataAccessException) {
			logger.error("Exception occured :{}", incorrectResultSizeDataAccessException);
			EpayDaoException.throwException("SUV001");
		}
		logger.debug("getOrgRegistrationStatus(String corpId) begins");
		return orgRegistrationStatus;
	}

	private class OrgRegistrationStatus implements RowMapper {
		public Object mapRow(ResultSet rs, int arg1) throws SQLException {
			EpayUsersProfile statusParam = new EpayUsersProfile();
			statusParam.setOrganizationId(rs.getString("registrationid"));
			statusParam.setProoftype(rs.getString("verificationtype"));
			statusParam.setVerificationstatus(rs.getString("verificationstatus"));
			return statusParam;
		}
	}

	public Map epayUserRegistration(Map registerParams) throws EpayDaoException {
		logger.info("epayUserRegistration dao bagin: {}");
		logger.info("registerParams Map: {}", registerParams);
		Map responseMap = new HashMap();
		responseMap.put("STATUS", "FAILED");
		String registrationStatus = "FAILED";
		try {
			String firstName = (String) registerParams.get("firstName");
			String lastname = (String) registerParams.get("lastName");
			String emailid = (String) registerParams.get("email");
			String mobileno = (String) registerParams.get("phoneNo");
			String gender = (String) registerParams.get("gender");
			String registrationid = "EPCUR" + getePayRegRefNo("epay_user_reg_sequence")
					+ RandomString.getRandomString();
			Object[] parameters = new Object[] { registrationid, firstName, lastname, emailid, mobileno, gender };
			int[] sqlTypes = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
					Types.VARCHAR };

			String qry = "insert into  epayuserregistration (registrationid,firstname,lastname,emailid,countrycode,mobileno,gender,status"
					+ ",statusdesc,creationtime,emailstatus,"
					+ " mobilenostatus) values ( ?,?,?,?,'91',?,?,'pending','newuser',sysdate(),'pending','pending')";

			int updateCount = getJdbcTemplate().update(qry, parameters, sqlTypes);
			if (updateCount > 0) {
				/*
				 * String loginId = "EPCUL" +
				 * getePayRegRefNo("epay_userid_sequence"); Object[]
				 * loginProfilePparameters = new Object[] { firstName + " " +
				 * firstName, loginId, emailid, emailid, mobileno }; int[]
				 * sqlProfileTypes = { Types.VARCHAR, Types.VARCHAR,
				 * Types.VARCHAR, Types.VARCHAR, Types.VARCHAR }; String
				 * loginProfileQry =
				 * "insert into epay_users_profile (name,loginid,password,instituteid,mailid,phoneno,countrycode,userrole,userstatus) "
				 * + "values ( ?,?,?,'0',?,?,'91',9,2)";
				 * responseMap.put("loginId", loginId); int createProfileCount =
				 * getJdbcTemplate().update(loginProfileQry,
				 * loginProfilePparameters,sqlProfileTypes);
				 */
				responseMap.put("name", firstName + " " + lastname);
				responseMap.put("emailid", emailid);
				responseMap.put("mobileno", mobileno);
				responseMap.put("status", "success");
				responseMap.put("registrationid", registrationid);
				logger.info("epayUserRegistration Successful ::{}");
			}
			logger.info("Record inserted to epayUsersPayLoginHistory");
		} catch (DataAccessException daoExp) {
			logger.error("exception is ::{} ", daoExp);
			EpayDaoException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
		logger.info("epayOrgRegistration dao end: {}");
		return responseMap;
	}

	public int getAuthPendingList(Map inParams) {
		logger.debug("getOrgRegistrationStatus(String userId) begins");
		int pendintCount = 0;
		String registrationId = (String) inParams.get("registrationId");
		String organaizationName = (String) inParams.get("organaizationName");
		String emailId = (String) inParams.get("emailId");

		List orgRegistrationStatus = new ArrayList();
		Object[] queryParams = { registrationId, organaizationName, emailId };
		logger.info("Params:::{}", queryParams);
		try {
			orgRegistrationStatus = (List) getJdbcTemplate().query(
					"select  registrationid, organizationname, orgtype, orgsubtype, address, district, state, pincode,phoneno, emailid, prooftype, proofvalue,"
							+ " verificationstatus, verificationstatusdesc from epayorgregistration where verificationstatus='pending' "
							+ " and registrationid=? and organizationname= ? and emailid= ?",
					queryParams, new OrgRegDetails());
			pendintCount = orgRegistrationStatus.size();
			logger.info("orgRegistrationStatus Size:{}", orgRegistrationStatus.size());
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception occured :{}", dataAccessException);
			EpayDaoException.throwException("SUV001");
		} catch (EpayDaoException incorrectResultSizeDataAccessException) {
			logger.error("Exception occured :{}", incorrectResultSizeDataAccessException);
			EpayDaoException.throwException("SUV001");
		}
		logger.debug("getOrgRegistrationStatus(String corpId) begins");
		return pendintCount;
	}

	public Map epayOrgAuthendication(Map inParams) {
		logger.debug("updateNewPassword  begins");
		String status = "failed";
		Map statusParams = new HashMap();
		String registrationId = (String) inParams.get("registrationId");
		String emailId = (String) inParams.get("emailId");
		String hashedPassword = (String) inParams.get("hashedPassword");
		String organizationname = (String) inParams.get("organizationname");
		int regStatusUpteCount = 0;
		int proofStatusUpdteCount = 0;
		int createProfile = 0;

		try {

			Object[] regStatusQryParam = { registrationId, organizationname, emailId };
			int[] epay_users_profileTypes = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };
			regStatusUpteCount = getJdbcTemplate().update(
					"update epayorgregistration set verificationstatus='approved',verificationstatusdesc='verified',"
							+ "updationtime=sysdate()"
							+ " where registrationid=? and organizationname=? and emailid=? ",
					regStatusQryParam, epay_users_profileTypes);

			logger.info("Registration Status Updated :::::{}" + regStatusUpteCount);

			Object[] verificationStatusQryParam = { registrationId };
			int[] verificationStatusTypes = { Types.VARCHAR };
			proofStatusUpdteCount = getJdbcTemplate().update(
					"update epayorgverificationstatus set verificationstatus='approved',"
							+ "remarks='verified',updationtime=sysdate(),usertype='ROLE_EPAY_SUPER_ADMIN' where registrationid=?",
					verificationStatusQryParam, verificationStatusTypes);
			logger.info("Proof Status Updated :::::{}" + proofStatusUpdteCount);

			Object[] loginProfilePparameters = new Object[] { registrationId, organizationname, emailId };
			int[] sqlProfileTypes = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR };
			String loginId = "EPCL" + getePayRegRefNo("epay_org_userid_sequence");
			String epay_org_sequence = "EPCORG" + getePayRegRefNo("epay_org_sequence");
			String loginProfileQry = "insert into epay_users_profile (name,mailid,phoneno,countrycode,address,state,district,pincode,userrole,userstatus,usertype,loginid,password,instituteid)"
					+ " select organizationname,emailid,phoneno,'91',address,state,district,pincode,1,1,'organization_user','"
					+ loginId + "','" + hashedPassword + "','" + epay_org_sequence + "' from  epayorgregistration "
					+ " where registrationid=? and organizationname=? and emailid=?";

			logger.info("Profile Created :::::{}" + proofStatusUpdteCount);
			int createProfileCount = getJdbcTemplate().update(loginProfileQry, loginProfilePparameters,
					sqlProfileTypes);
			if (createProfileCount > 0) {
				status = "profile_created";
				statusParams.put("status", status);
				statusParams.put("registrationId", registrationId);
				statusParams.put("organizationname", organizationname);
				statusParams.put("emailId", emailId);
			}

		} catch (DataAccessException dataAccessException) {
			logger.error("Exception occured :{}", dataAccessException);
			EpayDaoException.throwException("SUV001");
		} catch (EpayDaoException incorrectResultSizeDataAccessException) {
			logger.error("Exception occured :{}", incorrectResultSizeDataAccessException);
			EpayDaoException.throwException("SUV001");
		}
		logger.debug("updateNewPassword  begins");
		return statusParams;
	}

	public int getUserAuthPendingList(Map inParams) {
		logger.debug("getUserAuthPendingList(String userId) begins");
		int pendintCount = 0;
		String registrationId = (String) inParams.get("registrationId");
		String emailId = (String) inParams.get("emailId");
		String mobileNo = (String) inParams.get("mobileNo");

		List userRegistrationStatus = new ArrayList();
		Object[] queryParams = { registrationId, emailId, mobileNo };
		logger.info("Params:::{}", queryParams);
		try {
			userRegistrationStatus = (List) getJdbcTemplate().query(
					"select  registrationid,firstname,lastname,emailid,countrycode,mobileno,"
							+ "gender,status,statusdesc,creationtime,emailstatus, mobilenostatus"
							+ "  from epayuserregistration  where registrationid=? and emailid=? and mobileno=? and status='pending'",
					queryParams, new UserRegDetails());
			pendintCount = userRegistrationStatus.size();
			logger.info("orgRegistrationStatus Size:{}", userRegistrationStatus.size());
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception occured :{}", dataAccessException);
			EpayDaoException.throwException("SUV001");
		} catch (EpayDaoException incorrectResultSizeDataAccessException) {
			logger.error("Exception occured :{}", incorrectResultSizeDataAccessException);
			EpayDaoException.throwException("SUV001");
		}
		logger.debug("getUserAuthPendingList(String corpId) begins");
		return pendintCount;
	}

	private class UserRegDetails implements RowMapper {
		public Object mapRow(ResultSet rs, int arg1) throws SQLException {
			EpayUsersProfile regParams = new EpayUsersProfile();
			regParams.setOrganizationId(rs.getString("registrationid"));
			regParams.setOrganizationname((rs.getString("firstname")) + " " + (rs.getString("lastname")));
			regParams.setPhoneno(rs.getString("mobileno"));
			regParams.setEmailid((rs.getString("emailid")));
			regParams.setVerificationstatus((rs.getString("status")));
			regParams.setEmailStatus((rs.getString("emailstatus")));
			regParams.setMobilNoStatus(rs.getString("mobilenostatus"));

			return regParams;
		}
	}

	public EpayUsersProfile getUserRegistrationProfile(ModelMap inParams) {
		EpayUsersProfile usersProfilethis = null;
		String registrationId = (String) inParams.get("registrationId");
		String emailId = (String) inParams.get("emailId");
		String mobileNo = (String) inParams.get("mobileNo");
		try {
			String sql = "select  registrationid,firstname,lastname,emailid,countrycode,mobileno,"
					+ "gender,status,statusdesc,creationtime,emailstatus, mobilenostatus"
					+ "  from epayuserregistration  where registrationid=? and emailid=? and mobileno=? and status='pending'";
			usersProfilethis = (EpayUsersProfile) this.jdbcTemplate.queryForObject(sql,
					new Object[] { registrationId, emailId, mobileNo }, new UserRegDetails());
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception occured :{}", dataAccessException);
			EpayDaoException.throwException("SUV001");
		} catch (EpayDaoException incorrectResultSizeDataAccessException) {
			logger.error("Exception occured :{}", incorrectResultSizeDataAccessException);
			EpayDaoException.throwException("SUV001");
		}

		// TODO Auto-generated method stub
		return usersProfilethis;
	}

	public Map epayUserAuthendication(Map inParams) {
		logger.debug("epayUserAuthendication  begins");
		String status = "failed";
		Map statusParams = new HashMap();
		String registrationId = (String) inParams.get("registrationId");
		String emailId = (String) inParams.get("emailId");
		String hashedPassword = (String) inParams.get("hashedPassword");
		String name = (String) inParams.get("name");
		int regStatusUpteCount = 0;
		int proofStatusUpdteCount = 0;
		int createProfile = 0;
		try {

			Object[] regStatusQryParam = { registrationId, emailId };
			int[] epay_users_profileTypes = { Types.VARCHAR, Types.VARCHAR };
			regStatusUpteCount = getJdbcTemplate()
					.update("update epayuserregistration set status='approved',statusdesc='approved',emailstatus='verified',mobilenostatus='verified',updationtime=sysdate()"
							+ " where registrationid=? and emailid=?", regStatusQryParam, epay_users_profileTypes);
			logger.info("Registration Status Updated :::::{}" + regStatusUpteCount);

			Object[] loginProfilePparameters = new Object[] { registrationId, emailId };
			int[] sqlProfileTypes = { Types.VARCHAR, Types.VARCHAR };
			String loginId = "EPCL" + getePayRegRefNo("epay_userid_sequence");

			String loginProfileQry = "insert into epay_users_profile (name,mailid,countrycode,phoneno,userrole,userstatus,usertype,gender,loginid,password)"
					+ " Select '" + name + "',emailid,countrycode,mobileno,'7','1','user',gender,'" + loginId + "','"
					+ hashedPassword + "' from epayuserregistration" + " where registrationid=? and emailid=? ";

			logger.info("Profile Created :::::{}" + proofStatusUpdteCount);
			int createProfileCount = getJdbcTemplate().update(loginProfileQry, loginProfilePparameters,
					sqlProfileTypes);
			if (createProfileCount > 0) {
				status = "profile_created";
				statusParams.put("status", status);
				statusParams.put("registrationId", registrationId);
				statusParams.put("name", name);
				statusParams.put("emailId", emailId);
			}

		} catch (DataAccessException dataAccessException) {
			logger.error("Exception occured :{}", dataAccessException);
			EpayDaoException.throwException("SUV001");
		} catch (EpayDaoException incorrectResultSizeDataAccessException) {
			logger.error("Exception occured :{}", incorrectResultSizeDataAccessException);
			EpayDaoException.throwException("SUV001");
		}
		logger.debug("epayUserAuthendication  begins");
		return statusParams;
	}

	public int getUserRegistrationCheck(Map inParams) {
		logger.debug("getUserRegistrationCheck begins");
		int userregistRedCount = 0;
		String emailId = (String) inParams.get("emailId");
		String mobileNo = (String) inParams.get("mobileNo");

		List userRegistrationStatus = new ArrayList();
		Object[] queryParams = { emailId, mobileNo };
		logger.info("Params:::{}", queryParams);
		try {
			userRegistrationStatus = (List) getJdbcTemplate().query(
					"select registrationid,firstname,lastname,emailid,countrycode,mobileno,"
							+ "gender,status,statusdesc,creationtime,emailstatus, mobilenostatus from epayuserregistration where emailid=? or mobileno=?",
					queryParams, new UserRegDetails());
			userregistRedCount = userRegistrationStatus.size();
			logger.info("orgRegistrationStatus Size:{}", userRegistrationStatus.size());
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception occured :{}", dataAccessException);
			EpayDaoException.throwException("SUV001");
		} catch (EpayDaoException incorrectResultSizeDataAccessException) {
			logger.error("Exception occured :{}", incorrectResultSizeDataAccessException);
			EpayDaoException.throwException("SUV001");
		}
		logger.debug("getUserRegistrationCheck end");
		return userregistRedCount;
	}

}
