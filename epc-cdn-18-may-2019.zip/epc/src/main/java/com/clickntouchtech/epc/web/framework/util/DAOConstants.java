package com.clickntouchtech.epc.web.framework.util;

import com.clickntouchtech.epc.web.framework.util.Constants;

public interface DAOConstants extends Constants
{
	
} 
