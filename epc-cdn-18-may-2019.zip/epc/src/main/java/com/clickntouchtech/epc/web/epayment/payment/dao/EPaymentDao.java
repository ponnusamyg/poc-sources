package com.clickntouchtech.epc.web.epayment.payment.dao;

import java.util.Map;

public interface EPaymentDao {

	 public void insertLoginRequestTime(String echequeNo,String userName,String userIpAddress,String sessionId,String serverName, String deviceType);
	 public void updateLoginResponseTime(String echequeNo,String sessionId,String serverName,String txnStatus,String statusDescription,String resIpAddress);
	 public Map getEpaymentParams(String echequeNo);
	 public Map getEpayTransData(String echequeNo);

	 
}
