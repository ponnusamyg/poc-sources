package com.clickntouchtech.epc.web.framework.util;


public interface EpayPageConstants
 {
	//View NAmes To Be Map
    public static final String EPAY_OVER_ALL_PAYMENT_HISTORY_VIEW ="ePayUserPaymentHistory";
    public static final String EPAY_USER_DASHBOARD ="userdashboard";

    
//    Other Page Constants
    public static final String EPAY_DEVICETYPE_UNKNOWN ="UNKNOWN";
    public static final String EPAY_DEVICETYPE_DESKTOP ="DESKTOP";
    public static final String EPAY_DEVICETYPE_MOBILE ="MOBILE";
    public static final String EPAY_DEVICETYPE_TABLET ="TABLET";
	
}
