package com.clickntouchtech.epc.web.epayment.history.dao;

import java.util.List;

public interface EpaymentHistoryDao {
    public List getOverAllPaymentHistory(String userId);
}