package com.clickntouchtech.epc.web.epaysecurity.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.ui.ModelMap;

import com.clickntouchtech.epc.web.epayment.payment.dao.EpayDashboardDaoImpl;
import com.clickntouchtech.epc.web.framework.util.EpaySQLConstants;


public class EpayUserProfileDaoImpl implements EpayUserProfileDao {
    
	private static final Logger logger = LoggerFactory.getLogger(EpayDashboardDaoImpl.class);
	
	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void setDataSource(DataSource dataSource) {
		this.setJdbcTemplate(new JdbcTemplate(dataSource));
	}

	
	
	
	public String getUserByLogin(String userId){
		logger.info("(String username) { - begins");
		String refNo = "";
		String sqlQuery = null;
		Object[] inparam={ userId,userId,userId};
		try {
			sqlQuery = "select  password from epay_user where user_id= (select id from epay_users_profile where loginid=? or MailId=? or PhoneNo=?)";
			logger.info("sqlQuery :: {}", sqlQuery);
			logger.error("Exception occured :{}", jdbcTemplate);
			refNo =(String)jdbcTemplate.queryForObject(sqlQuery, inparam,String.class);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info("getMerchantId - end");
		return refNo;
	}

	
	public  List<String> getUserRoles(String username) {
		List<String> roles = new ArrayList<String>();
		Connection connection = null;
		CallableStatement callStmt = null;
		//String sql = "SELECT ur.authority from users u, user_roles ur where u.user_id=ur.user_id and u.user_name=?";
		String sql = "select ud.user_id, ur.role from epay_user ud, epay_user_roles ur,epay_user_role_map urm "
				+ " where ud.user_id = urm.user_id and urm.role_id = ur.role_id and ud.user_id = (select id from epay_users_profile where loginid=? "
				+ " or MailId=? or PhoneNo=?)";
		try {
			// get jdbc connection
			connection = getJdbcTemplate().getDataSource().getConnection();
			// create CallableStatement
			callStmt = connection.prepareCall(sql);
			callStmt.setString(1, username);
			callStmt.setString(2, username);
			callStmt.setString(3, username);
			// execute select SQL stetement
			callStmt.execute();
			// get data
			ResultSet rs = callStmt.getResultSet();
			while (rs.next()) {
				String role = rs.getString("role");
				roles.add(role);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (callStmt != null) {
					callStmt.close();
				}
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return roles;
	}
	/*@SuppressWarnings("unchecked")
	public List<String> getUserRoles(String userId) {

		List<String> roles = new ArrayList<String>();
		String sqlQuery = null;
		try {
			Object[] inparam={ userId,userId,userId};
			sqlQuery = "select ur.role from epay_user ud, epay_user_roles ur,epay_user_role_map urm "
			+ " where ud.user_id = urm.user_id and urm.role_id = ur.role_id and ud.user_id = (select id from epay_users_profile where loginid='777' "
			+ " or MailId='777' or PhoneNo='777')";

			roles = (List) jdbcTemplate.queryForList(sqlQuery);
			logger.info("roles::::::::::::::: {}", roles.size());
			if (logger.isDebugEnabled())
				logger.debug("roles: {}", roles);

		} catch (DataAccessException dataAccessException) {
			dataAccessException.printStackTrace();
			logger.error("Exception occured :{}", dataAccessException);
			EpayDaoException.throwException("SUV001", dataAccessException);
		}
		logger.debug("orglist ends");
		return roles;

	}*/

	@Override
	public String getUserHistoryInfo(ModelMap userObj) {
		// TODO Auto-generated method stub
		System.out.println("userObj:===="+userObj);
		int insertCount=0;
		try{
            Object[] parameters = new Object[] {userObj.get("userid"),userObj.get("ip"),"MAC",userObj.get("sessionid"),userObj.get("engineid"),userObj.get("devicetype"),userObj.get("useragent")};
            int[] sqlTypes = {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
            insertCount=getJdbcTemplate().update(EpaySQLConstants.EPAY_USER_INSERT_DATA, parameters,sqlTypes);
            logger.info("Record inserted to epayUserPaymentsRefKey");
            }catch(DataAccessException daoExp){
                logger.error("exception is ::{} ", daoExp);
                //EpayDaoException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE); 
            }
		
		
		return String.valueOf(insertCount);
	}
	

/*private class RoleExtractor implements RowMapper {
		public Object mapRow(ResultSet rs, int arg1) throws SQLException {
			EpaymentHistoryParams histParams = new EpaymentHistoryParams();
			histParams.setRole(rs.getString("role"));
			return histParams; 
		}
	}*/
	 
	/*public List getUserRoles(String userId) {
    	logger.debug("getTopTransactions(String userId) begins");
    	
    	List<String> roles = new ArrayList<String>();
		Object[] queryParams={userId,userId,userId};
    	logger.info("Params:::{}",queryParams);
			try {	
				String txnQry ="select ur.role,ur.role_id from epay_user ud, epay_user_roles ur,epay_user_role_map urm "
						+ " where ud.user_id = urm.user_id and urm.role_id = ur.role_id and ud.user_id = (select id from epay_users_profile where loginid=? "
						+ " or MailId=? or PhoneNo=?)";
				roles = (List)getJdbcTemplate().query(txnQry,queryParams, new TopTransactionsRowMapper());
				logger.info("Size#########:{}",roles.size());	
			}
			catch(DataAccessException dataAccessException) {
				logger.error("Exception occured :{}",dataAccessException);
				EpayDaoException.throwException("SUV001");
			}catch(EpayDaoException incorrectResultSizeDataAccessException) {
				logger.error("Exception occured :{}",incorrectResultSizeDataAccessException);
				EpayDaoException.throwException("SUV001");
			}
			logger.debug("topTransactions(String corpId) begins");
		return roles;
    }
	
	 
 

private class TopTransactionsRowMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int arg1) throws SQLException {
//			List topTransactions = new ArrayList();
			List<String> roles = new ArrayList<String>();
			EpayUserAuthModel histParams = new EpayUserAuthModel();
			histParams.setRole(rs.getString("role"));
			String role = rs.getString("role");
			roles.add(role);
			return roles; 
		}
	}*/

}