package com.clickntouchtech.epc.web.epaysecurity.service;

import java.security.SecureRandom;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * EpayTokenServiceImpl
 *
 * @author selvaraj palanisamy
 * @since 1.0
 */
@Service("pagefTokenService")
public class EpayTokenServiceImpl implements EpayTokenService {

	private static final Logger logger = LoggerFactory.getLogger(EpayTokenServiceImpl.class);
	private final SecureRandom random = new SecureRandom();

	/**
	 * 
	 */
	@Override
	public String generatePageToken() {
		final byte[] bytes = new byte[64];
		random.nextBytes(bytes);
		return Base64.encodeBase64URLSafeString(bytes);
	}

	/**
	 * 
	 */
	@Override
	public String getPageTokenSession(final HttpServletRequest request) {
		return this.getPageTokenImpl(request.getSession(false));
	}

	/**
	 * 
	 * @param session
	 * @return string
	 */
	private String getPageTokenImpl(final HttpSession session) {
		String token = null;
		if (session != null) {
			token = (String) session.getAttribute(TOKEN_ABUTE_NAME);
			if (StringUtils.isBlank(token))
				session.setAttribute(TOKEN_ABUTE_NAME, (token = generatePageToken()));
		}
		return token;
	}

	@Override
	public boolean validateTokenInterceptor(HttpServletRequest request) {
		logger.info("validateTokenInterceptor----------- begin");
		boolean tkbooleanvalidate = false;
		String tokenfromform = null;
		final HttpSession session = request.getSession(false);
		String tokenfromsession = this.getPageTokenImpl(session);
		if (session != null) {
			tokenfromform = request.getParameter((String) session.getAttribute(TOKEN_PARAM_NAME));
		}
		logger.info("validateTokenInterceptor from session::::::: {}", tokenfromsession);
		logger.info("validateTokenInterceptor from jsp page:::::: {}", tokenfromform);		
		logger.info("validateTokenInterceptor Final verifiaction start.....");		
		tkbooleanvalidate = session != null && tokenfromsession.equals(tokenfromform);
		if (session != null) {
			logger.info("validateTokenInterceptor remove values from session....");		
			session.removeAttribute(TOKEN_ABUTE_NAME);
			session.removeAttribute(TOKEN_PARAM_NAME);
		}
		logger.info("validateTokenInterceptor Final verifiaction...end....return value:{}",tkbooleanvalidate);
		logger.info("validateTokenInterceptor----------- end");
		return tkbooleanvalidate;
	}

	@Override
	public String generateParmName(final HttpServletRequest request) {
		return this.getPageParmImpl(request.getSession(false));
	}

	/**
	 * 
	 * @param session
	 * @return string
	 */
	private String getPageParmImpl(final HttpSession session) {
		String pageParm = null;
		if (session != null) {
			pageParm = (String) session.getAttribute(TOKEN_PARAM_NAME);
			if (StringUtils.isBlank(pageParm))
				session.setAttribute(TOKEN_PARAM_NAME, (pageParm = "epaysec"+generateParmName()));
		}
		return pageParm;
	}

	@Override
	public String generateParmName() {
		return RandomStringUtils.random(4, 0, 20, true, true, "qw32rfHIJk9iQ8Ud7h0X".toCharArray());
	}

}
