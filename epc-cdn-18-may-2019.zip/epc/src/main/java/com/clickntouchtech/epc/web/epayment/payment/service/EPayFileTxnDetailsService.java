package com.clickntouchtech.epc.web.epayment.payment.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.clickntouchtech.epc.web.epayment.payment.dao.EpayOrgDao;
import com.clickntouchtech.epc.web.epayment.payment.model.EpayFormValues;
import com.clickntouchtech.epc.web.epayment.payment.model.EpayModelValidClassificationParams;
import com.clickntouchtech.epc.web.framework.exception.EpayApplicationException;
import com.clickntouchtech.epc.web.framework.exception.EpayBaseResponse;
import com.clickntouchtech.epc.web.framework.exception.EpayDaoException;
import com.clickntouchtech.epc.web.framework.service.EpayBaseAbsService;
import com.clickntouchtech.epc.web.framework.service.ServiceErrorConstants;
import com.clickntouchtech.epc.web.framework.util.LoggingConstants;

@Service
public class EPayFileTxnDetailsService extends EpayBaseAbsService {

	private static final Logger logger = LoggerFactory.getLogger(EPayFileTxnDetailsService.class);

	@Autowired
	private EpayOrgDao epayOrgDao;
	public ModelMap epayServiceBase(ModelMap inputParams) {
		logger.info("EPayFileTxnDetailsService execute method begins");
		logger.debug("inputparams Map:: {}", inputParams);
		EpayBaseResponse response = new EpayBaseResponse();
		response.setErrorStatus(ServiceErrorConstants.FAILURE);
		ModelMap outParams = new ModelMap();
		String classificationid = (String) inputParams.get("classificationid");
		String uniqueRefNo = (String) inputParams.get("uniqueRefNo");
		List epayFields = null;
		List penaltyList = null;
		if (classificationid != null && !classificationid.equalsIgnoreCase("")) {
			try {

				Map paymentMadeList = new HashMap();
				String paymentStatus = "";
				Date transDate = null;
				List paramValueList = null;
					if (uniqueRefNo != null) {
						Map fileModeCategoryList = epayOrgDao.fileTxnClassificationFields(classificationid, uniqueRefNo);
						List categoryValidParamList = null;
						epayFields = epayOrgDao.fileTxnClassifications(classificationid);
						String classificationFields = (String) fileModeCategoryList.get("fieldData");
						if (classificationFields != null && !classificationFields.equals("")) {
							StringTokenizer str1 = new StringTokenizer(classificationFields, "|");
							str1.nextToken();
							// ssss
							logger.info("Number of Tokens :: {},Size of paramList :: {}", str1.countTokens(),
									epayFields.size());
							int i = 0;
							while (str1.hasMoreTokens()) {
								String paramString = str1.nextToken();
								EpayFormValues frmCtrl = (EpayFormValues) epayFields.get(i);
	
								if (!("fixed".equalsIgnoreCase(frmCtrl.getControlType()))
										&& !("natext".equalsIgnoreCase(frmCtrl.getControlType()))
										&& !("naoptions".equalsIgnoreCase(frmCtrl.getControlType()))
										&& !("naFixed".equalsIgnoreCase(frmCtrl.getControlType()))) {
	
									if ("Variable".endsWith(frmCtrl.getControlType()))
										frmCtrl.setFormat("");
	
									frmCtrl.setDefaultValue(paramString);
									frmCtrl.setControlType("suvidhalabel");
	
								}
								if ("999".equalsIgnoreCase(frmCtrl.getExceptionCode())) {
									frmCtrl.setDefaultValue("N/A");
									frmCtrl.setValue("N/A");
									frmCtrl.setControlType("suvidhalabel");
								}
								if (paramValueList == null) {
									paramValueList = new ArrayList();
								}
								paramValueList.add(frmCtrl);
								i++;
							}
							if ((paramValueList != null && paramValueList.size() > 0)) {
								outParams.put("paramValueList", paramValueList);
								response.setErrorStatus(ServiceErrorConstants.SUCCESS);
							}
	
							if (epayFields != null && epayFields.size() > 0) {
								outParams.put("paramList", epayFields);
								response.setErrorStatus(ServiceErrorConstants.SUCCESS);
							}
	
						} else {
							response.setErrorStatus(ServiceErrorConstants.FAILURE);
							response.setErrorMessage("Record Not Found for Entered " + uniqueRefNo);
							logger.error("Record Not Found for Entered ::::{}" + uniqueRefNo);
						}
	
					}

			} catch (EpayApplicationException epcexp) {
				logger.error(LoggingConstants.EXCEPTION, epcexp);
				logger.info("Exception at 115{}");
				response.setErrorStatus(ServiceErrorConstants.FAILURE);
				response.setErrorCode(epcexp.getErrorCode());

			} catch (EpayDaoException dataAccessException) {
				logger.error("Exception occured {}:" + dataAccessException);
				logger.info("Exception at 122");
				response.setErrorStatus(ServiceErrorConstants.FAILURE);
				response.setErrorMessage(ServiceErrorConstants.UNDEFINED);
				response.setErrorCode("SUV010");
			}

			catch (Exception exp) {
				logger.info("Exception at 122");
				logger.error(LoggingConstants.EXCEPTION, exp);
				response.setErrorStatus(ServiceErrorConstants.FAILURE);
				response.setErrorMessage(ServiceErrorConstants.UNDEFINED);
				response.setErrorCode("SUV010");
			}

		}
		outParams.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
		logger.info("EPayFileTxnDetailsService execute method Ends");
		return outParams;

	}

	public Map validateSessionParams(List categoryValidParamList, String classificationFields) {
		Map hm = new HashMap();
		List ar = new ArrayList();

		List fixedDetails = new ArrayList();
		List AmountDetails = new ArrayList();

		for (int i = 0; i < categoryValidParamList.size(); i++) {
			EpayModelValidClassificationParams paramDetails = (EpayModelValidClassificationParams) categoryValidParamList
					.get(i);
			ar.add(paramDetails.getOutRef());
			fixedDetails.add(paramDetails.getParamType());
			AmountDetails.add(paramDetails.getAmount());
		}

		Iterator it = ar.iterator();
		Iterator fixedType = fixedDetails.iterator();
		Iterator AmountType = AmountDetails.iterator();

		StringTokenizer st = new StringTokenizer(classificationFields, "|");

		while (st.hasMoreTokens()) {
			String fixedParam = null;
			String Amount = null;

			String sr = st.nextToken();
			logger.info("token string:::: {}", sr);

			if ((sr != null) && (!"ICM".equalsIgnoreCase(sr.trim())) && (fixedType.hasNext())
					&& (AmountType.hasNext())) {
				fixedParam = (String) fixedType.next();
				Amount = (String) AmountType.next();
			}

			if ((sr == null) || ("EPC".equalsIgnoreCase(sr.trim())))
				continue;
			if (((!"Fixed".equalsIgnoreCase(fixedParam)) || ((!sr.contains("N/A")) && (!sr.endsWith(" NA"))
					&& (!sr.endsWith("-NA")) && (!"NA".equalsIgnoreCase(sr))))
					&& ((sr.contains("N/A")) || (sr.endsWith(" NA")) || (sr.endsWith("-NA"))
							|| ("NA".equalsIgnoreCase(sr))))
				continue;
			if ("Fixed".equalsIgnoreCase(fixedParam)) {
				sr = Amount;
			}

			String sit = (String) it.next();
			hm.put(sit, sr);
			this.logger.info("Key::: {}, value::: {} ", sit, sr);
		}

		return hm;
	}

}