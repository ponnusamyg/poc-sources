package com.clickntouchtech.epc.web.framework.util;

import org.apache.log4j.Logger;

/**
 * This class contains the functions to convert the amount given in number to
 * words for display in the eCheque.
 * 
 * @author Easwar Prasad
 * @version 1.0
 */
public class NumberToWords {

	private Logger log = Logger.getLogger(getClass());

	public  String numberToWords(String number) {

		String returnValue;
		String numberInString = number;
		int indexOfDecimalPoint = numberInString.indexOf(".");
		String wholeNumberPart = null;
		String decimalPart = null;
		//log.info("entering" + numberInString);
		returnValue = new String("");

		if (indexOfDecimalPoint != -1) {
			//log.info("index" + indexOfDecimalPoint);
			wholeNumberPart = numberInString.substring(0, indexOfDecimalPoint);
			decimalPart = numberInString.substring(indexOfDecimalPoint + 1);
			if (decimalPart.length() > 2)
				decimalPart = decimalPart.substring(0, 2);
			else
				decimalPart += "0";
		} else {
			wholeNumberPart = numberInString;
			decimalPart = "00";
		}
		//log.info(wholeNumberPart.length() + "length");

		if (wholeNumberPart.length() == 1) {
			//.info("in here");
			returnValue = getUnits(wholeNumberPart.charAt(0));
		} else if (wholeNumberPart.length() == 2) {
			if (wholeNumberPart.charAt(1) != '0') {
				String value = appendZero(wholeNumberPart.charAt(0));
				returnValue += getTens(value);
				returnValue += getUnits(wholeNumberPart.charAt(1));
			} else {
				returnValue += getTens(wholeNumberPart);
			}
		} else if (wholeNumberPart.length() == 3)
			returnValue = getResultForLengthThree(wholeNumberPart);
		else if (wholeNumberPart.length() == 4)
			returnValue = getResultForLengthFour(wholeNumberPart);
		else if (wholeNumberPart.length() == 5)
			returnValue = getResultForLengthFive(wholeNumberPart);
		else if (wholeNumberPart.length() == 6)
			returnValue = getResultForLengthSix(wholeNumberPart);
		else if (wholeNumberPart.length() == 7)
			returnValue = getResultForLengthSeven(wholeNumberPart);
		else if (wholeNumberPart.length() == 8)
			returnValue = getResultForLengthEight(wholeNumberPart);
		else if (wholeNumberPart.length() == 9)
			returnValue = getResultForLengthNine(wholeNumberPart);
		else if (wholeNumberPart.length() == 10)
			returnValue = getResultForLengthTen(wholeNumberPart);
		else if (wholeNumberPart.length() == 11)
			returnValue = getResultForLengthEleven(wholeNumberPart);
		else if (wholeNumberPart.length() == 12)
			returnValue = getResultForLengthTwelve(wholeNumberPart);
		else if (wholeNumberPart.length() == 13)
			returnValue = getResultForLengthThirteen(wholeNumberPart);
		if (returnValue.equals(" ONE "))
			returnValue += "RUPEE";
		else
			returnValue += " RUPEES";

		///log.info("decinmal Part" + decimalPart);
 
		if (decimalPart.equals("00") != true) {

			if (decimalPart.charAt(0) != '0') {
				if (decimalPart.charAt(1) != '0') {
					String value = appendZero(decimalPart.charAt(0));
					returnValue += getTens(value);
					returnValue += getUnits(decimalPart.charAt(1));
					returnValue += " PAISE";
				} else {
					returnValue += getTens(decimalPart);
					returnValue += " PAISE";
				}
			} else {
				if (decimalPart.charAt(1) != '0') {
					returnValue += getUnits(decimalPart.charAt(1));
					if (decimalPart.charAt(1) == '1')
						returnValue += " PAISA";
					else
						returnValue += " PAISE";
				}
			}
		}
		return returnValue;
	}

	private String getResultForLengthThree(String number) {

		String returnValue = new String("");
		char hundredPlace = number.charAt(0);
		log.info(returnValue);
		returnValue += getUnits(hundredPlace);
		log.info(returnValue);
		returnValue += appendHundred();
		log.info(returnValue);

		String lastTwoDigits = number.substring(1);
		returnValue += getLastTwoDigitsInWords(lastTwoDigits);
		log.info(returnValue);
		return returnValue;
	}

	private String getResultForLengthFour(String number) {
		String returnValue = new String("");
		char thousandPlace = number.charAt(0);
		char hundredPlace = number.charAt(1);
		returnValue += getUnits(thousandPlace);
		returnValue += appendThousand();

		returnValue += appendHundredPlaceIfExists(hundredPlace);

		String lastTwoDigits = number.substring(2);
		returnValue += getLastTwoDigitsInWords(lastTwoDigits);
		return returnValue;
	}

	private String getResultForLengthFive(String number) {
		String returnValue = new String("");
		String value = new String();

		String thousandPlace = number.substring(0, 2);
		value = getLastTwoDigitsInWords(thousandPlace);
		if (value.equals("") == false) {
			returnValue += value;
			returnValue += appendThousand();
		}

		char hundredPlace = number.charAt(2);
		returnValue += appendHundredPlaceIfExists(hundredPlace);

		String lastTwoDigits = number.substring(3);
		returnValue += getLastTwoDigitsInWords(lastTwoDigits);
		return returnValue;
	}

	private String getResultForLengthSix(String number) {
		String returnValue = new String("");
		String value = new String();
		char lakhPlace = number.charAt(0);
		returnValue += getUnits(lakhPlace);
		returnValue += appendLakh();

		String thousandPlace = number.substring(1, 3);
		value = getLastTwoDigitsInWords(thousandPlace);
		if (value.equals("") == false) {
			returnValue += value;
			returnValue += appendThousand();
		}

		char hundredPlace = number.charAt(3);
		returnValue += appendHundredPlaceIfExists(hundredPlace);

		String lastTwoDigits = number.substring(4);
		returnValue += getLastTwoDigitsInWords(lastTwoDigits);
		return returnValue;
	}

	private String getResultForLengthSeven(String number) {
		String returnValue = new String("");
		String value = new String();

		String lakhPlace = number.substring(0, 2);
		value = getLastTwoDigitsInWords(lakhPlace);
		if (value.equals("") == false) {
			returnValue += value;
			returnValue += appendLakh();
		}

		String thousandPlace = number.substring(2, 4);
		value = getLastTwoDigitsInWords(thousandPlace);
		if (value.equals("") == false) {
			returnValue += value;
			returnValue += appendThousand();
		}

		char hundredPlace = number.charAt(4);
		returnValue += appendHundredPlaceIfExists(hundredPlace);

		String lastTwoDigits = number.substring(5);
		returnValue += getLastTwoDigitsInWords(lastTwoDigits);
		return returnValue;
	}

	private String getResultForLengthEight(String number) {
		String returnValue = new String("");
		String value = new String();

		char crorePlace = number.charAt(0);
		returnValue += getUnits(crorePlace);
		returnValue += appendCrore();

		String lakhPlace = number.substring(1, 3);
		value = getLastTwoDigitsInWords(lakhPlace);
		if (value.equals("") == false) {
			returnValue += value;
			returnValue += appendLakh();
		}

		String thousandPlace = number.substring(3, 5);
		value = getLastTwoDigitsInWords(thousandPlace);
		if (value.equals("") == false) {
			returnValue += value;
			returnValue += appendThousand();
		}

		char hundredPlace = number.charAt(5);
		returnValue += appendHundredPlaceIfExists(hundredPlace);

		String lastTwoDigits = number.substring(6);
		returnValue += getLastTwoDigitsInWords(lastTwoDigits);
		return returnValue;
	}

	private String getResultForLengthNine(String number) {
		String value = null;
		String returnValue = new String("");

		String crorePlace = number.substring(0, 2);
		value = getLastTwoDigitsInWords(crorePlace);

		if (value.equals("") == false) {
			returnValue += value;
			returnValue += appendCrore();
		}

		String lakhPlace = number.substring(2, 4);
		value = getLastTwoDigitsInWords(lakhPlace);
		if (value.equals("") == false) {
			returnValue += value;
			returnValue += appendLakh();
		}

		String thousandPlace = number.substring(4, 6);
		value = getLastTwoDigitsInWords(thousandPlace);
		if (value.equals("") == false) {
			returnValue += value;
			returnValue += appendThousand();
		}

		char hundredPlace = number.charAt(6);
		returnValue += appendHundredPlaceIfExists(hundredPlace);

		String lastTwoDigits = number.substring(7);
		returnValue += getLastTwoDigitsInWords(lastTwoDigits);
		return returnValue;
	}

	private String getResultForLengthTen(String number) {
		String value = null;
		String returnValue = new String("");

		String crorePlace = number.substring(0, 3);
		returnValue += appendHundredPlaceIfExists(crorePlace.charAt(0));

		value = crorePlace.substring(1, 3);
		value = getLastTwoDigitsInWords(value);

		if (value.equals("") == false) {
			returnValue += value;
			returnValue += appendCrore();
		}

		String lakhPlace = number.substring(3, 5);
		value = getLastTwoDigitsInWords(lakhPlace);
		if (value.equals("") == false) {
			returnValue += value;
			returnValue += appendLakh();
		}

		String thousandPlace = number.substring(5, 7);
		value = getLastTwoDigitsInWords(thousandPlace);
		if (value.equals("") == false) {
			returnValue += value;
			returnValue += appendThousand();
		}

		char hundredPlace = number.charAt(7);
		returnValue += appendHundredPlaceIfExists(hundredPlace);

		String lastTwoDigits = number.substring(8);
		returnValue += getLastTwoDigitsInWords(lastTwoDigits);
		return returnValue;
	}

	private String getResultForLengthEleven(String number) {
		String value = null;
		String returnValue = new String("");

		String crorePlace = number.substring(0, 4);

		returnValue += getUnits(crorePlace.charAt(0));
		returnValue += appendThousand();
		returnValue += appendHundredPlaceIfExists(crorePlace.charAt(1));

		value = crorePlace.substring(2, 4);
		value = getLastTwoDigitsInWords(value);

		if (value.equals("") == false) {
			returnValue += value;
			returnValue += appendCrore();
		}
		String lakhPlace = number.substring(4, 6);
		value = getLastTwoDigitsInWords(lakhPlace);
		if (value.equals("") == false) {
			returnValue += value;
			returnValue += appendLakh();
		}

		String thousandPlace = number.substring(6, 8);
		value = getLastTwoDigitsInWords(thousandPlace);
		if (value.equals("") == false) {
			returnValue += value;
			returnValue += appendThousand();
		}

		char hundredPlace = number.charAt(8);
		returnValue += appendHundredPlaceIfExists(hundredPlace);

		String lastTwoDigits = number.substring(9);
		returnValue += getLastTwoDigitsInWords(lastTwoDigits);
		return returnValue;
	}

	private String getResultForLengthTwelve(String number) {
		String value = null;
		String returnValue = new String("");

		String crorePlace = number.substring(0, 5);

		String thousandCrores = crorePlace.substring(0, 2);
		value = getLastTwoDigitsInWords(thousandCrores);
		if (value.equals("") == false) {
			returnValue += value;
			returnValue += appendThousand();
		}
		returnValue += appendHundredPlaceIfExists(crorePlace.charAt(2));

		value = crorePlace.substring(3, 5);
		value = getLastTwoDigitsInWords(value);

		if (value.equals("") == false) {
			returnValue += value;
			returnValue += appendCrore();
		}

		String lakhPlace = number.substring(5, 7);
		value = getLastTwoDigitsInWords(lakhPlace);
		if (value.equals("") == false) {
			returnValue += value;
			returnValue += appendLakh();
		}

		String thousandPlace = number.substring(7, 9);
		value = getLastTwoDigitsInWords(thousandPlace);
		if (value.equals("") == false) {
			returnValue += value;
			returnValue += appendThousand();
		}

		char hundredPlace = number.charAt(9);
		returnValue += appendHundredPlaceIfExists(hundredPlace);

		String lastTwoDigits = number.substring(10);
		returnValue += getLastTwoDigitsInWords(lastTwoDigits);
		return returnValue;
	}

	private String getResultForLengthThirteen(String number) {
		String value = null;
		String returnValue = new String("");

		String crorePlace = number.substring(0, 6);

		returnValue += getUnits(crorePlace.charAt(0));
		returnValue += appendLakh();

		String thousandCrores = crorePlace.substring(1, 3);
		value = getLastTwoDigitsInWords(thousandCrores);
		if (value.equals("") == false) {
			returnValue += value;
			returnValue += appendThousand();
		}
		returnValue += appendHundredPlaceIfExists(crorePlace.charAt(3));

		value = crorePlace.substring(4, 6);
		value = getLastTwoDigitsInWords(value);

		if (value.equals("") == false) {
			returnValue += value;
			returnValue += appendCrore();
		}

		String lakhPlace = number.substring(6, 8);
		value = getLastTwoDigitsInWords(lakhPlace);
		if (value.equals("") == false) {
			returnValue += value;
			returnValue += appendLakh();
		}

		String thousandPlace = number.substring(8, 10);
		value = getLastTwoDigitsInWords(thousandPlace);
		if (value.equals("") == false) {
			returnValue += value;
			returnValue += appendThousand();
		}

		char hundredPlace = number.charAt(10);
		returnValue += appendHundredPlaceIfExists(hundredPlace);

		String lastTwoDigits = number.substring(11);
		returnValue += getLastTwoDigitsInWords(lastTwoDigits);
		return returnValue;
	}

	private String appendZero(char number) {
		return (new String(number + "0"));
	}

	private String appendHundred() {
		return (new String(" HUNDRED "));
	}

	private String appendThousand() {
		return (new String(" THOUSAND "));
	}

	private String appendLakh() {
		return (new String(" LAKH "));
	}

	private String appendCrore() {
		return (new String(" CRORE "));
	}

	private String appendHundredPlaceIfExists(char hundredPlace) {

		String returnValue = new String("");
		if (hundredPlace != '0') {
			returnValue += getUnits(hundredPlace);
			returnValue += appendHundred();
		}
		return returnValue;
	}

	private String getLastTwoDigitsInWords(String lastTwoDigits) {

		String returnValue = new String("");

		if (lastTwoDigits.charAt(0) != '0') {
			if (lastTwoDigits.charAt(1) != '0') {
				char tens = lastTwoDigits.charAt(0);
				String tensUnits = appendZero(tens);
				returnValue += getTens(tensUnits);
				returnValue += getUnits(lastTwoDigits.charAt(1));
			} else {
				String tensUnits = lastTwoDigits.substring(0);
				returnValue += getTens(tensUnits);
			}
		} else {
			if (lastTwoDigits.charAt(1) != '0')
				returnValue += getUnits(lastTwoDigits.charAt(1));
		}

		return returnValue;
	}

	private String getUnits(char number) {

		switch (number) {
		case '1':
			return " ONE";
		case '2':
			return " TWO";
		case '3':
			return " THREE";
		case '4':
			return " FOUR";
		case '5':
			return " FIVE";
		case '6':
			return " SIX";
		case '7':
			return " SEVEN";
		case '8':
			return " EIGHT";
		case '9':
			return " NINE";
		}
		return null;
	}

	private String getTens(String number) {

		if (number.equals("10"))
			return " TEN";
		if (number.equals("11"))
			return " ELEVEN";
		if (number.equals("12"))
			return " TWELWE";
		if (number.equals("13"))
			return " THIRTEEN";
		if (number.equals("14"))
			return " FOURTEEN";
		if (number.equals("15"))
			return " FIFTEEN";
		if (number.equals("16"))
			return " SIXTEEN";
		if (number.equals("17"))
			return " SEVENTEEN";
		if (number.equals("18"))
			return " EIGHTEEN";
		if (number.equals("19"))
			return " NINETEEN";
		if (number.equals("20"))
			return " TWENTY";
		if (number.equals("30"))
			return " THIRTY";
		if (number.equals("40"))
			return " FORTY";
		if (number.equals("50"))
			return " FIFTY";
		if (number.equals("60"))
			return " SIXTY";
		if (number.equals("70"))
			return " SEVENTY";
		if (number.equals("80"))
			return " EIGHTY";
		if (number.equals("90"))
			return " NINETY";
		return null;
	}
}
