package com.clickntouchtech.epc.web.framework.tags;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;

import com.clickntouchtech.epc.web.framework.util.StringUtils;


public class CurrencyFormatTag extends BodyTagSupport {
        public int doAfterBody() throws JspException {
        String absoluteAmount=bodyContent.getString().trim();
        String formattedAmount="";
        BodyContent body = getBodyContent();
        JspWriter out = body.getEnclosingWriter();
        try {
            formattedAmount=StringUtils.formatAmount(absoluteAmount);
            out.println(formattedAmount);
        } catch (Exception exception) {
            throw new JspException("FORMAT_NUMBER_CURRENCY_ERROR",exception);
        }
        return EVAL_PAGE;
    }
}   