package com.clickntouchtech.epc.web.framework.util;
import java.util.HashMap;
import java.util.Map;

public class RupeeAmountInWords {

    static Map<String,String> unitdoMap=new HashMap<String, String>();
    static Map<String,String> tensMap=new HashMap<String,String>();
    static Map<String,String> digitMap=new HashMap<String,String>();
    
    static{
  	unitdoMap.put("0","");
		unitdoMap.put("1"," One");
		unitdoMap.put("2"," Two");
		unitdoMap.put("3"," Three");
		unitdoMap.put("4"," Four");
		unitdoMap.put("5"," Five");
		unitdoMap.put("6"," Six");
		unitdoMap.put("7"," Seven");
		unitdoMap.put("8"," Eight");
		unitdoMap.put("9"," Nine");
		unitdoMap.put("10"," Ten");
		unitdoMap.put("11"," Eleven");
		unitdoMap.put("12"," Twelve");
		unitdoMap.put("13"," Thirteen");
		unitdoMap.put("14"," Fourteen");
		unitdoMap.put("15"," Fifteen");
		unitdoMap.put("16"," Sixteen");
		unitdoMap.put("17"," Seventeen");	  		
		unitdoMap.put("18"," Eighteen");
		unitdoMap.put("19"," Nineteen");
		
		tensMap.put("0","");
		tensMap.put("1"," Ten");
		tensMap.put("2"," Twenty");
		tensMap.put("3"," Thirty");
		tensMap.put("4"," Forty");
		tensMap.put("5"," Fifty");
		tensMap.put("6"," Sixty");
		tensMap.put("7"," Seventy");
		tensMap.put("8"," Eighty");
		tensMap.put("9"," Ninety");
		
		digitMap.put("0","");
		digitMap.put("1"," Hundred");
		digitMap.put("2"," Thousand");
		digitMap.put("3"," Lakh");
		digitMap.put("4"," Crore");
		digitMap.put("5"," Lakhs");
		digitMap.put("6"," Crores");
		digitMap.put("7"," Hundred");
		
	}
    
   int r;
   long s;


    
    int numberCount(long num)
    {
        int cnt=0;

        while (num>0)
        {
          s = num%10;
          cnt++;
          num = num / 10;
        }

          return cnt;
    }


    //Method for Conversion of two digit

    String twonum(long numq)
    {
         long numr, nq;
         String ltr="";

         nq = numq / 10;
         numr = numq % 10;

         if (numq>19)
           {
         ltr=ltr+tensMap.get(String.valueOf(nq))+unitdoMap.get(String.valueOf(numr));
           }
         else
           {	        	   
         ltr = ltr+unitdoMap.get(String.valueOf(numq));
           }

         return ltr;
    }

    //Method for Conversion of three digit

    String threenum(long numq)
    {
           long numr, nq;
           String ltr = "";

           nq = numq / 100;
           numr = numq % 100;

           if (numr == 0)
            {
            ltr = ltr + unitdoMap.get(String.valueOf(nq))+digitMap.get("1");
             }
           else
            {
            ltr = ltr +unitdoMap.get(String.valueOf(nq))+digitMap.get("1")+twonum(numr);
            }
           return ltr;

    }

public String convertRupeeAmountInWords(String amount){
int len,len1,len2, q=0, r=0;
long t=0,u=0;
String ltr = " ";
String rupees = "";
long num1=Long.parseLong(amount);
while (num1>0)
{
   len1=numberCount(num1);

 //Take the length of the number and do letter conversion

 switch (len1)

 {
 
 		case 11:
	   
			   t=num1/10000000000L;
			   u=num1%10000000000L;
			   len2=numberCount(u);
			   ltr = twonum(t);
		       System.out.println("t val in case 11:"+t);
		       if(t>0 && len2<8)
		            rupees = rupees+ltr+digitMap.get("2")+digitMap.get("6");
		       else 
		       	rupees = rupees+ltr+digitMap.get("2");
		       num1 = u;
		       break;
	   		
 		case 10:
 			
 			 t=num1/1000000000;
 			  u=num1%1000000000;
 			 len2=numberCount(u);
 			  ltr = twonum(t);
              System.out.println("t val in case 10:"+t);
              if(t>0 && len2<8)
                   rupees = rupees+ltr+digitMap.get("7")+digitMap.get("6");
              else 
              	rupees = rupees+ltr+digitMap.get("7");
              num1 = u;
              break;
  
 	  case 9:
      case 8:
              t=num1/10000000;
              u=num1%10000000;
              ltr = twonum(t);
              System.out.println("t val in case 8,9:"+t);
              if(t>1){
            	  
              rupees = rupees+ltr+digitMap.get("6");
             }
              else rupees = rupees+ltr+digitMap.get("4");
              num1 = u;
              break;

      case 7:
      case 6:
              t=num1/100000;
              u=num1%100000;
              ltr = twonum(t);
              System.out.println("t val in case 6,7:"+t);
              if(t>1)
              rupees = rupees+ltr+digitMap.get("5");
              else rupees = rupees+ltr+digitMap.get("3");
              num1 = u;
              break;

      case 5:
      case 4:

               t=num1/1000;
               u=num1%1000;
               ltr = twonum(t);
               rupees= rupees+ltr+digitMap.get("2");
               num1 = u;
               break;

      case 3:

                if (len1 == 3)
                    u = num1;
                ltr = threenum(u);
                rupees = rupees + ltr;
                num1 = 0;
                break;

      case 2:

               ltr = twonum(num1);
               rupees = rupees + ltr;
               num1=0;
               break;

      case 1:
    	  		if("One".equalsIgnoreCase(unitdoMap.get(String.valueOf(num1))))
    	  		rupees="Rupee" + unitdoMap.get(String.valueOf(num1));	
    	  		
    	  		else rupees = rupees + unitdoMap.get(String.valueOf(num1));
               num1=0;
               break;
      default:

              num1=0;
              System.out.println("Exceeding Crore....No conversion");
              //System.exit(1);


  }
             // if (num1==0)
             // System.out.println(rupees+" Only");
}


return rupees;
}


    /*public static void main(String[] args) throws Exception
    {

        String amount="1713357567.25";
        RupeeAmountInWords n = new RupeeAmountInWords();
        String rupeeAmountInWords=n.getWordsFormat(amount);
        System.out.println("amount in words.."+rupeeAmountInWords);
      
      
}*/
public String getWordsFormat(String currencyStr)
{
String rupees=currencyStr;
String word="";
String word2="";
String paise="";
if(currencyStr.contains(".")){
	rupees = currencyStr.substring(0,currencyStr.indexOf("."));
	paise = currencyStr.substring(currencyStr.indexOf(".")+1,currencyStr.length());
}
try{
 if(paise.equalsIgnoreCase("0")|| paise.equalsIgnoreCase("00")|| paise.equals("")){
 word=convertRupeeAmountInWords(rupees);
 word=word+" Only";
 }
 else{
	   word=convertRupeeAmountInWords(rupees);
     word2=convertRupeeAmountInWords(paise);
     word=word+" and Paise"+word2+" Only";
     }
}
catch(Exception e)
{
 e.printStackTrace();
}
return word;
}
public String getWordsFormatForMerchant(String currencyStr)
{
//added by nidhi for amountinwords may 2012
String rupees=currencyStr;
String word="";
String word2="";
String paise="";
String Rs="rs";
String ps="ps";

if((currencyStr!=null)&&(currencyStr!="")&&(!(currencyStr.equalsIgnoreCase("0"))))
{

	if(currencyStr.contains("."))
	{
	rupees = currencyStr.substring(0,currencyStr.indexOf("."));
	paise = currencyStr.substring(currencyStr.indexOf(".")+1,currencyStr.length());
	
	}
try{
	if((rupees.equalsIgnoreCase("0")|| rupees.equalsIgnoreCase("00")|| rupees.equals(""))
			&&!(paise.equalsIgnoreCase("0")|| paise.equalsIgnoreCase("00")|| paise.equals("")))	
			{
		
				if(paise.length()==1)
				{
					word=tensMap.get(paise);	
	   		   	}else
	   		   	{
	   		   		word=convertRupeeAmountInWords(paise);
	   		   	}
				
				word="Paise "+word+" Only";
	}
	
	else if(!(rupees.equalsIgnoreCase("0")|| rupees.equalsIgnoreCase("00")|| rupees.equals(""))
			&&(paise.equalsIgnoreCase("0")|| paise.equalsIgnoreCase("00")|| paise.equals("")))
 				{
	 				word=convertRupeeAmountInWords(rupees);
	 				word="Rupees "+word+" Only";
 				}
	else if((rupees.equalsIgnoreCase("0")|| rupees.equalsIgnoreCase("00")|| rupees.equals(""))
			&&(paise.equalsIgnoreCase("0")|| paise.equalsIgnoreCase("00")|| paise.equals("")))
	{
		word="--";
	}
	else
 		{
	   	word=convertRupeeAmountInWords(rupees);
	   	
	   	if(paise.length()==1)
	   	{
	   	word2=tensMap.get(paise);	
	   		
	   	}else{
	   	word2=convertRupeeAmountInWords(paise);
	   	}
	   	word=word+" and Paise"+word2+" Only";
 		}
}
catch(Exception e)
{
 e.printStackTrace();
}
return word;
}
else
{
 word="--";
 return word;
}

}
}