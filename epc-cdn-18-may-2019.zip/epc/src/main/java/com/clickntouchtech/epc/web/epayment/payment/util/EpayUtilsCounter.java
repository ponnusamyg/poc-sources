package com.clickntouchtech.epc.web.epayment.payment.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.clickntouchtech.epc.web.epayment.payment.dao.EpayOrgDao;
import com.clickntouchtech.epc.web.epayment.payment.model.EpayFormValues;
import com.clickntouchtech.epc.web.framework.exception.EpayApplicationException;

@Service
public class EpayUtilsCounter {

	protected final Logger logger = LoggerFactory.getLogger(EpayUtilsCounter.class);

	@Autowired
	private EpayOrgDao epayOrgDao;

	public Map getAdditionalParams(Map inParams) {

		if (logger.isDebugEnabled())
			logger.debug("getAdditionalParams(Map inParams) -- begin");

		Map outParams = new HashMap();
		Map amountValuesMap = new HashMap();
		Map dynamicFieldkeyValuesMap = new LinkedHashMap();
		EpayFormValues formControl;
		List categoryList = new ArrayList();
		String amountBuf = "";
		String paramBuf = "";

		try {
			categoryList = epayOrgDao.getClassificationParams((String) inParams.get("classificationid"));
		} catch (Exception e) {
			logger.error("Exception occurred", e);
			new EpayApplicationException(e, "SUV001");
		}
		for (int i = 0; i < categoryList.size(); i++) {
			formControl = (EpayFormValues) categoryList.get(i);
			// outParams.put(formControl.getRequestVarname(),formControl.getLabel()+"#SEP#"+inParams.get(formControl.getRequestVarname()));
			String FormValue = (String) inParams.get(formControl.getRequestVarname());
			if (formControl.getControlType().equalsIgnoreCase("Fixed")) {
				// Modified on 220708
				// To check whether its fixed and mandatory or its
				// fixed,Non-Mandatory but the user has entered some value
				if (formControl.getMandatory().equalsIgnoreCase("0")
						|| (!formControl.getMandatory().equalsIgnoreCase("0")
								&& !inParams.get(formControl.getRequestVarname()).toString().equalsIgnoreCase("0"))) {
					amountValuesMap.put(formControl.getRequestVarname(), formControl.getDefaultValue());// to
																										// avoid
																										// tampering,
																										// we
																										// get
																										// the
																										// amount
																										// value
																										// from
																										// DB
					dynamicFieldkeyValuesMap.put(formControl.getRequestVarname(),
							formControl.getLabel() + "|" + formControl.getDefaultValue());
				}
				// to check whether its not mandatory and so user hasn't entered
				// anything - add amount as 0
				else if (!formControl.getMandatory().equalsIgnoreCase("0"))// &&
																			// inParams.get(formControl.getRequestVarname()).toString().equalsIgnoreCase("0"))
				{
					amountValuesMap.put(formControl.getRequestVarname(), "0");// user
																				// has
																				// not
																				// entered
																				// any
																				// value
																				// for
																				// this
																				// label
					dynamicFieldkeyValuesMap.put(formControl.getRequestVarname(),
							formControl.getLabel() + "|" + inParams.get(formControl.getRequestVarname()));
				}
				// End - Modified on 220708
				amountBuf = amountBuf + "~" + formControl.getLabel() + "~"
						+ inParams.get(formControl.getRequestVarname());
			} else if (formControl.getControlType().equalsIgnoreCase("Variable")) {
				amountValuesMap.put(formControl.getRequestVarname(), inParams.get(formControl.getRequestVarname()));
				dynamicFieldkeyValuesMap.put(formControl.getRequestVarname(),
						formControl.getLabel() + "|" + inParams.get(formControl.getRequestVarname()));
				if (FormValue != null && !("".equalsIgnoreCase(FormValue)))
					amountBuf = amountBuf + "~" + formControl.getLabel() + "~" + FormValue;
				else
					amountBuf = amountBuf + "~" + formControl.getLabel() + "~" + null;
			} else if (formControl.getControlType().equalsIgnoreCase("Option")) {
				amountValuesMap.put(formControl.getRequestVarname(), inParams.get(formControl.getRequestVarname()));
				dynamicFieldkeyValuesMap.put(formControl.getRequestVarname(),
						formControl.getLabel() + "|" + inParams.get(formControl.getRequestVarname()));
				if (FormValue != null && !("".equalsIgnoreCase(FormValue)))
					amountBuf = amountBuf + "~" + formControl.getLabel() + "~" + FormValue;
				else
					amountBuf = amountBuf + "~" + formControl.getLabel() + "~" + null;
			} else if (formControl.getControlType().equalsIgnoreCase("natext")
					&& !formControl.getMandatory().equalsIgnoreCase("0")) {
				logger.info("inside non mandatory na text ");
				if (!inParams.get(formControl.getRequestVarname()).toString().equalsIgnoreCase("0")) {
					amountValuesMap.put(formControl.getRequestVarname(), inParams.get(formControl.getRequestVarname()));
					dynamicFieldkeyValuesMap.put(formControl.getRequestVarname(),
							formControl.getLabel() + "|" + inParams.get(formControl.getRequestVarname()));
					if (FormValue != null && !("".equalsIgnoreCase(FormValue)))
						amountBuf = amountBuf + "~" + formControl.getLabel() + "~" + FormValue;
					else
						amountBuf = amountBuf + "~" + formControl.getLabel() + "~" + null;
				} else {
					amountValuesMap.put(formControl.getRequestVarname(), "0");// user
																				// has
																				// not
																				// entered
																				// any
																				// value
																				// for
																				// this
																				// label
					dynamicFieldkeyValuesMap.put(formControl.getRequestVarname(),
							formControl.getLabel() + "|" + inParams.get(formControl.getRequestVarname()));

				}
			}

			else if ((formControl.getControlType().equalsIgnoreCase("natext")
					&& formControl.getMandatory().equalsIgnoreCase("0"))) {

				logger.info("inside  mandatory na text ");
				amountValuesMap.put(formControl.getRequestVarname(), inParams.get(formControl.getRequestVarname()));
				dynamicFieldkeyValuesMap.put(formControl.getRequestVarname(),
						formControl.getLabel() + "|" + inParams.get(formControl.getRequestVarname()));
				if (FormValue != null && !("".equalsIgnoreCase(FormValue)))
					amountBuf = amountBuf + "~" + formControl.getLabel() + "~" + FormValue;
				else
					amountBuf = amountBuf + "~" + formControl.getLabel() + "~" + null;
			} else {
				dynamicFieldkeyValuesMap.put(formControl.getRequestVarname(),
						formControl.getLabel() + "|" + inParams.get(formControl.getRequestVarname()));
				if (FormValue != null && !("".equalsIgnoreCase(FormValue)))
					paramBuf = paramBuf + "~" + formControl.getLabel() + "~" + FormValue;
				else
					paramBuf = paramBuf + "~" + formControl.getLabel() + "~" + null;
			}
		}

		logger.info("dynamicFieldkeyValuesMap:{}", dynamicFieldkeyValuesMap);
		logger.info("instituteID *** : {}", inParams.get("organizationid"));
		logger.info("inParams ##########*** : {}", inParams);
		// Fixed ouref values - fieldkey1 to fieldkey10
		outParams.put("fieldkey1", inParams.get("organizationid"));
		outParams.put("fieldkey2", inParams.get("organizationname"));
		outParams.put("fieldkey3", inParams.get("orgaddress"));
		outParams.put("fieldkey4", inParams.get("organizationid"));
		outParams.put("fieldkey5", inParams.get("organizationname"));
		outParams.put("fieldkey6", inParams.get("classificationid"));
		outParams.put("fieldkey7", inParams.get("classificationname"));
		outParams.put("fieldkey9", paramBuf);
		outParams.put("fieldkey10", amountBuf);
		outParams.put("amountValuesMap", amountValuesMap);
		outParams.put("dynamicFieldkeyValuesMap", dynamicFieldkeyValuesMap);
		Map serviceChargeMap = epayOrgDao.getEpaymentServiceCharge((String) inParams.get("organizationid"));
		outParams.put("serviceChargeMap", serviceChargeMap);
		if (logger.isDebugEnabled()) {
			logger.debug("Additional Params Map::{}", outParams);
			logger.debug("getAdditionalParams(Map inParams) -- end");
		}
		return outParams;
	}

}
