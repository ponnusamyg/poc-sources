package com.clickntouchtech.epc.web.epayment.payment.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.clickntouchtech.epc.web.epayment.payment.dao.EpayOrgDao;
import com.clickntouchtech.epc.web.framework.exception.EpayApplicationException;
import com.clickntouchtech.epc.web.framework.exception.EpayBaseResponse;
import com.clickntouchtech.epc.web.framework.exception.EpayDaoException;
import com.clickntouchtech.epc.web.framework.service.EpayBaseAbsService;
import com.clickntouchtech.epc.web.framework.service.ServiceErrorConstants;

@Service
public class EpayOrgDisplayService extends EpayBaseAbsService {

	private static final Logger logger = LoggerFactory.getLogger(EpayOrgDisplayService.class);
	
	@Autowired
	private EpayOrgDao epayOrgDao;
	
	public ModelMap epayServiceBase(ModelMap inputParams) {
		
		logger.info("EpayOrgDisplayService execute method begins");
		
		if (logger.isDebugEnabled())
			logger.debug("inputparams Map:{}",inputParams);
		ModelMap outParams = new ModelMap();
		EpayBaseResponse response = new EpayBaseResponse();
		response.setErrorStatus(ServiceErrorConstants.FAILURE);
		List orglist = null;
		try {
			orglist = epayOrgDao.getEpayOrgList();
			
        	if( orglist!=null && orglist.size()>0 ) {
        		outParams.put("orglist" ,orglist);
            	response.setErrorStatus(ServiceErrorConstants.SUCCESS);
            } else {	        	
	        	logger.info("institution List for the selected state and type is null or empty");
	            response.setErrorStatus(ServiceErrorConstants.FAILURE);
	            response.setErrorCode("EPAYORG001");	
            }
	        
	    }catch(EpayApplicationException cmsexp) {
	    	response.setErrorStatus(ServiceErrorConstants.FAILURE);
            response.setErrorCode("EPCERR002");
	    }catch (EpayDaoException daoexp) {
			daoexp.printStackTrace();
			response.setErrorStatus(ServiceErrorConstants.FAILURE);
            response.setErrorCode("EPCERR002");	
		}
	    
		outParams.addAttribute(ServiceErrorConstants.APPLICATION_RESPONSE, response);
		
		logger.info("EpayOrgDisplayService execute method end");
		
		return outParams;
	}
	
	
}
