package com.clickntouchtech.epc.web.epaysecurity.bean;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.clickntouchtech.epc.web.epaysecurity.dao.EpayUserProfileDao;

public class EpayUserDetailsServiceImpl implements UserDetailsService {

	/**
	 * @param epayUserProfileDao
	 *            the epayUserProfileDao to set
	 */
	public void setEpayUserProfileDao(EpayUserProfileDao epayUserProfileDao) {
		this.epayUserProfileDao = epayUserProfileDao;
	}

	private EpayUserProfileDao epayUserProfileDao;

	// EpayUserProfileDaoImpl epayUserProfileDaoImpl = new
	// EpayUserProfileDaoImpl();

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// get user by username
		String password = epayUserProfileDao.getUserByLogin(username);
		if (null == password) {
			throw new UsernameNotFoundException("User " + username + " not exists");
		}

		// EpayUsersProfile usersProfile=EpayUserDAO.getUserProfile(username);
		// get user roles and build user authorities
		List<String> roles = epayUserProfileDao.getUserRoles(username);
		Set<GrantedAuthority> authorities = new HashSet<GrantedAuthority>();
		for (String role : roles) {
			authorities.add(new EpayGrantedAuthorityImpl(role));
		}
		// instanciate Spring Security class User
		return new EpayUserDetailsImpl(username, password, authorities);
	}

}
