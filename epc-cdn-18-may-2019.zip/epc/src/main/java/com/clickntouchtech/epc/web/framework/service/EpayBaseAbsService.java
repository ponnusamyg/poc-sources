package com.clickntouchtech.epc.web.framework.service;

import org.springframework.ui.ModelMap;

public abstract class EpayBaseAbsService {
     
    public ModelMap epayServiceBase(ModelMap inputParams){
        return null;
    }

    
}

