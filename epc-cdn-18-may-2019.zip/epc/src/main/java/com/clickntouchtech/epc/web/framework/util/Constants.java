package com.clickntouchtech.epc.web.framework.util;

public interface Constants {

	public static final String EMPTY = "";
	public static final String TRANSACTION_REMARKS = "transactionRemarks";
	public static final String USER_NAME = "userName";
	public static final String TRANSACTION_NAME = "transactionName";
	public static final String ERROR_VIEW = "error_view";

}
