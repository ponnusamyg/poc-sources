package com.clickntouchtech.epc.web.epaysecurity.security;

import java.io.IOException;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mobile.device.Device;
import org.springframework.mobile.device.DeviceUtils;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;
import org.springframework.ui.ModelMap;

import com.clickntouchtech.epc.web.epaysecurity.dao.EpayUserProfileDao;
import com.clickntouchtech.epc.web.framework.util.EpayPageConstants;

@Component
public class EpayCustomAuthSuccessHandler implements	AuthenticationSuccessHandler {
	
	private static final Logger logger = LoggerFactory.getLogger(EpayCustomAuthSuccessHandler.class); 
 
	private RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();
	
	/**
	 * @param epayUserProfileDao
	 *            the epayUserProfileDao to set
	 */
	public void setEpayUserProfileDao(EpayUserProfileDao epayUserProfileDao) {
		this.epayUserProfileDao = epayUserProfileDao;
	}

	private EpayUserProfileDao epayUserProfileDao;
	
	@Override
	public void onAuthenticationSuccess(HttpServletRequest request,
			HttpServletResponse response, Authentication authentication) throws IOException,
			ServletException {
			/*Set some session variables*/
		HttpSession sessionext = request.getSession(false);
    	if(sessionext != null){
    		logger.info("EpayCustomAuthSuccessHandler --- Existing session ---{}",sessionext.getId());
    		sessionext.invalidate();
       	}
    	HttpSession session = request.getSession(true);   
    	logger.info("EpayCustomAuthSuccessHandler --- New session ---{}",session.getId());
		UserDetails authUser = (UserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();  
        session.setAttribute("uname", authUser.getUsername());  
        session.setAttribute("authorities", authentication.getAuthorities()); 
        
        String clientIp=getClientIP(request);
        
        System.out.println("userid:===="+authUser.getUsername());
        System.out.println("ip:===="+clientIp);
        System.out.println("session id:===="+session.getId());
        System.out.println("engine id:===="+request.getServerName());
      
        Device device = DeviceUtils.getCurrentDevice(request);
        String userAgent = request.getHeader("User-Agent");
        System.out.println("device :===="+device);
        ModelMap inParams = new ModelMap();     
    	if(device!=null){
    		// to check Device Type .....
       	 String deviceType = EpayPageConstants.EPAY_DEVICETYPE_UNKNOWN;
            if (device.isNormal()) {
                deviceType = EpayPageConstants.EPAY_DEVICETYPE_DESKTOP;
            } else if (device.isMobile()) {
            	Pattern pattern = Pattern.compile("(wv)");
                Matcher matcher = pattern.matcher(userAgent);
                if (matcher.find())
                deviceType = EpayPageConstants.EPAY_DEVICETYPE_MOBILE+"-"+matcher.group(1);
                else
                deviceType = EpayPageConstants.EPAY_DEVICETYPE_MOBILE;

            } else if (device.isTablet()) {
                deviceType = EpayPageConstants.EPAY_DEVICETYPE_TABLET;
            }
            logger.info("Device Type ::::::{}",deviceType);
            System.out.println("Device Type :===="+deviceType);
            inParams.put("devicetype", deviceType);
    	}
    	 
    	  System.out.println("userAgent:===="+userAgent);
    	  
    	
    	  inParams.put("userid", authUser.getUsername());
    	  inParams.put("ip", clientIp);
    	  inParams.put("sessionid", session.getId());   
    	  inParams.put("engineid", request.getServerName());   	 
    	  inParams.put("useragent", userAgent);
    	  String insertCount=epayUserProfileDao.getUserHistoryInfo(inParams);
    	  System.out.println("insertCount:===="+insertCount);
        
        
        /*Set target URL to redirect*/
		String targetUrl = determineTargetUrl(authentication); 
		redirectStrategy.sendRedirect(request, response, targetUrl);
	}
 
	protected String determineTargetUrl(Authentication authentication) {
        Set<String> authorities = AuthorityUtils.authorityListToSet(authentication.getAuthorities());
        System.out.println("authorities==============="+authorities);
        if (authorities.contains("ROLE_EPAY_SUPER_ADMIN")) {
        	return "/epca/epayadashboard";
          } else if (authorities.contains("ROLE_EPAY_USER")) {
        	return "/epcu/epayudashboard";
        	//return "/epayUserloginsucess";
        } else if (authorities.contains("ROLE_EPAY_REG_USER")) { //Registration 
        	return "/epayOrgReg/emailauth";
        	//return "/epayUserloginsucess";
        }  else if (authorities.contains("ROLE_EPAY_REG_ENDUSER")) { //User Registration 
        	return "/epayUserReg/emailauth";
        	
        } else {
            throw new IllegalStateException();
        }
    }
 
	public RedirectStrategy getRedirectStrategy() {
		return redirectStrategy;
	}
 
	public void setRedirectStrategy(RedirectStrategy redirectStrategy) {
		this.redirectStrategy = redirectStrategy;
	}
	
	private String getClientIP(HttpServletRequest request) {
        String xfHeader = request.getHeader("X-Forwarded-For");
        if (xfHeader == null) {
            return request.getRemoteAddr();
        }
        return xfHeader.split(",")[0];
    }
}