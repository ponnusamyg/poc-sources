
package com.clickntouchtech.epc.web.framework.util;

import java.util.Random;
import java.util.UUID;

public class RandomString
{
    static int ssize =4; 
    static char[] chars = new char[] {
          '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'
        };
    
    public static String getRandomString(){
      Random ran = new java.util.Random();
      String randomString = "";
        for (int j = 0; j < ssize; j++){
          int r = ran.nextInt(chars.length);
          randomString += chars[r];
        }
        return randomString;
     
    }

	public static String getRefreshRandomString() {	
		return UUID.randomUUID().toString();
	}
    
	public static void main (String args[]){
		
		String randomNo=getRandomString();
		System.out.println("###randomNo##"+randomNo);
		
	}
}
