package com.clickntouchtech.epc.web.epaysecurity.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.clickntouchtech.epc.web.epayment.payment.dao.EpayUserDashBoardDao;
import com.clickntouchtech.epc.web.epaysecurity.bean.EpayUsersProfile;
import com.clickntouchtech.epc.web.epaysecurity.dao.EpayUserProfileDao;
import com.clickntouchtech.epc.web.framework.exception.EpayApplicationException;
import com.clickntouchtech.epc.web.framework.exception.EpayBaseResponse;
import com.clickntouchtech.epc.web.framework.exception.EpayDaoException;
import com.clickntouchtech.epc.web.framework.service.EpayBaseAbsService;
import com.clickntouchtech.epc.web.framework.service.ServiceErrorConstants;


@Service
public class EpayUserProfileService extends EpayBaseAbsService {
	
	private static final Logger logger = LoggerFactory.getLogger(EpayUserProfileService.class);
	
//	@Autowired
//	private EpayUserProfileDao epayUserProfile;
	
	@Autowired
	private EpayUserDashBoardDao epayUserDashBoardDao;
	
	public ModelMap epayServiceBase(ModelMap inputParams) {
		logger.info("EpayUserProfileService execute method begins");
		if (logger.isDebugEnabled())
			logger.debug("inputparams Map: {}",inputParams);
		
		ModelMap outParams = new ModelMap();
		ModelMap inParams = new ModelMap();
		EpayBaseResponse response = new EpayBaseResponse();
		response.setErrorStatus(ServiceErrorConstants.FAILURE);	
		try {		
			String userId = (String)inputParams.get("userId");
			EpayUsersProfile epayUsersProfile = null;
			if(userId!=null && !userId.isEmpty()) {
				inParams.put("userId", userId);
				epayUsersProfile = epayUserDashBoardDao.getEpayUserProfileDetails(inParams);
					logger.info("usersProfile object{}",epayUsersProfile);
				}
				
				outParams.addAttribute("usersProfile", epayUsersProfile);
				//outParams.addAttribute("instituteDetailsCount",instituteDetails.size());

		response.setErrorStatus(ServiceErrorConstants.SUCCESS);
		
        }catch(EpayApplicationException cmsexp){
        	cmsexp.printStackTrace();
        	response.setErrorCode("V101");
		}catch (EpayDaoException daoexp) {
			response.setErrorCode(daoexp.getErrorCode());
		}
		
		outParams.addAttribute(ServiceErrorConstants.APPLICATION_RESPONSE, response);
		
		if (logger.isDebugEnabled())
			logger.debug("outParams Map contains: {}",outParams);
		
		logger.info("EpayUserProfileService execute method end");
		
		return outParams;
	}
}
