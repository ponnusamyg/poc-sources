package com.clickntouchtech.epc.web.epayreg.controller;

import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.mobile.device.Device;
import org.springframework.mobile.device.DeviceUtils;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.clickntouchtech.epc.web.epayreg.service.EpayOrgRegProfileService;
import com.clickntouchtech.epc.web.epayreg.service.EpayOrgRegistrationService;
import com.clickntouchtech.epc.web.epayreg.service.EpayUserRegProfileService;
import com.clickntouchtech.epc.web.epayreg.service.EpayUserRegistrationService;
import com.clickntouchtech.epc.web.framework.exception.EpayBaseResponse;
import com.clickntouchtech.epc.web.framework.service.ServiceErrorConstants;
import com.clickntouchtech.epc.web.framework.util.EncryptDecrypt;
import com.clickntouchtech.epc.web.framework.util.EpayPageConstants;

@Controller
@Scope("prototype")
public class EpayRegistartionController {

	@Autowired
	private EpayOrgRegistrationService epayOrgRegistrationService;

	@Autowired
	private EpayOrgRegProfileService epayOrgRegProfileService;

	@Autowired
	private EpayUserRegistrationService epayUserRegistrationService;
	@Autowired
	private EpayUserRegProfileService epayUserRegProfileService;

	private static final Logger logger = LoggerFactory.getLogger(EpayRegistartionController.class);

	@RequestMapping(value = "/epayreg", method = RequestMethod.GET)
	public String epayUserRegistration(@RequestHeader(value = "User-Agent", required = false) String userAgent,
			HttpServletRequest request, ModelMap modelMap) {
		logger.info("epayUserRegistration method begins");
		ModelMap inParams = new ModelMap();
		ModelMap outParams = new ModelMap();
		HttpSession session = request.getSession(false);
		String view = "epayUserReg";
		logger.info("epayUserRegistration userAgent :::::::::::::::::: {}", userAgent);
		epayDeviceInfo(userAgent, request);
		logger.info("epayUserRegistration method ends");
		return view;
	}

	@RequestMapping(value = "/epayorgreg", method = RequestMethod.GET)
	public String epayOrgrRegistration(@RequestHeader(value = "User-Agent", required = false) String userAgent,
			HttpServletRequest request, ModelMap modelMap) {
		logger.info("epayOrgrRegistration method begins{}");
		ModelMap inParams = new ModelMap();
		ModelMap outParams = new ModelMap();
		HttpSession session = request.getSession(false);
		String view = "epayOrgReg";
		logger.info(" userAgent :::::::::::::::::: {}", userAgent);
		epayDeviceInfo(userAgent, request);
		logger.info("epayOrgrRegistration method ends{}");
		return view;
	}

	@RequestMapping(value = "/epayorgreg/registration", method = RequestMethod.POST)
	public String epayOrgrReg(@RequestParam Map<String, String> allRequestParams,HttpServletRequest request, HttpSession session,
			ModelMap modelMap) {
		boolean errorFlag = false;
		ModelMap inParams = new ModelMap();
		ModelMap outParams = new ModelMap();

		if (allRequestParams != null && allRequestParams.size() > 0) {

			for (Map.Entry<String, String> entry : allRequestParams.entrySet()) {
				String fieldName = entry.getKey();
				String value = entry.getValue();
				logger.info("fieldName : {}", fieldName);
				logger.info("value : {}", value);
				inParams.addAttribute(fieldName, value);
			}
			logger.info("inParams : {}", inParams);
			ModelMap catParams = new ModelMap();
			inParams.put("serviceType", "registration");
			
			getDomianUrl(request, inParams);			
			
			catParams = epayOrgRegistrationService.execute(inParams);

			logger.info("outParams : {}", outParams);
		}
		return "epayorgregsuccess";
	}

	/**
	 * @param request
	 * @param inParams
	 */
	private void getDomianUrl(HttpServletRequest request, ModelMap inParams) {
		String servername = request.getServerName();
		String context = request.getContextPath();							
		String scheme = request.getScheme();
		int portNumber = request.getServerPort();
		String servletPath = request.getServletPath();
		logger.info("servername -------------------->>> {}", servername);
		logger.info("context Name -------------------->>> {}", context);
		logger.info("scheme -------------------->>> {}", scheme);
		logger.info("portNumber  -------------------->>> {}", portNumber);
		logger.info("servletPath -------------------->>> {}", servletPath);						
		
		if ("localhost".equals(servername)) {//LOCAL 
			inParams.put("domainUrl", ""+scheme+"://"+servername+":"+portNumber+""+context+"");
		} else {//CLOUD 
			inParams.put("domainUrl", ""+scheme+"://"+servername+"");
		}
	}

	@RequestMapping(value = "/epayorgreg/emailauth", method = RequestMethod.GET)
	public String orgRegEmailAuthentication(@RequestParam String email, HttpSession session, ModelMap modelMap) {
		logger.info("orgRegEmailAuthentication start {}");
		try {
			session.setAttribute("emailauthparams", email);
			String decryptedString = new EncryptDecrypt().decrypt(email);
			String[] spilitedString = decryptedString.split("\\|");

			String registrationId = spilitedString[0];
			String organizationname = spilitedString[1];
			String emailId = spilitedString[2];
			logger.info("spilitedString : {}", spilitedString);
			ModelMap requestParams = new ModelMap();
			ModelMap resParams = new ModelMap();
			requestParams.put("registrationId", registrationId);
			requestParams.put("organaizationName", organizationname);
			requestParams.put("emailId", emailId);
			logger.info("requestParams : {}", requestParams);
			resParams = epayOrgRegProfileService.epayServiceBase(requestParams);
			logger.info("resParams : {}", resParams);
			EpayBaseResponse appResponse = (EpayBaseResponse) resParams.get(ServiceErrorConstants.APPLICATION_RESPONSE);
			if ("EPCERR002".equals(appResponse.getErrorStatus())) {
				return "redirect:/epaylogin";
			}
			if ("success".equals(appResponse.getErrorStatus())) {
				modelMap.addAttribute("epayOrgREgUsersProfile", resParams.get("epayOrgREgUsersProfile"));
				modelMap.addAttribute("orgRegStstus", resParams.get("orgRegStstus"));
			}
			if (!"success".equals(appResponse.getErrorStatus()) && !"login".equals(appResponse.getErrorStatus())) {
				return "redirect:sessiontimeout";
			}

		} catch (InvalidKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidAlgorithmParameterException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BadPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("orgRegEmailAuthentication method size {}", modelMap.size());
		logger.info("orgRegEmailAuthentication method end{}");
		return "epayOrgEmailAuth";
	}

	@RequestMapping(value = "/epayorgreg/emailauthpasswordgen", method = RequestMethod.POST)
	public String epayEmailAuthPwdGen(@RequestParam Map<String, String> allRequestParams,HttpServletRequest request, HttpSession session,
			ModelMap modelMap) {
		boolean errorFlag = false;
		ModelMap inParams = new ModelMap();
		ModelMap outParams = new ModelMap();

		String newPassword = allRequestParams.get("password");
		String newConfirmPassword = allRequestParams.get("password");

		if (newPassword == null || newPassword.equals("") || newConfirmPassword == null
				|| newConfirmPassword.equals("")) {
			return "errorpage";
		}
		if (!newPassword.equals(newConfirmPassword)) {
			return "errorpage";
		}

		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String hashedPassword = passwordEncoder.encode(newPassword);

		String emailauthparams = (String) session.getAttribute("emailauthparams");
		String decryptedString;
		ModelMap requestParams = new ModelMap();
		ModelMap resParams = new ModelMap();
		try {
			decryptedString = new EncryptDecrypt().decrypt(emailauthparams);
			String[] spilitedString = decryptedString.split("\\|");
			String registrationId = spilitedString[0];
			String organizationname = spilitedString[1];
			String emailId = spilitedString[2];
			logger.info("spilitedString : {}", spilitedString);
			requestParams.put("registrationId", registrationId);
			requestParams.put("organizationname", organizationname);
			requestParams.put("emailId", emailId);
			requestParams.put("hashedPassword", hashedPassword);
			logger.info("requestParams : {}", requestParams);
			requestParams.put("serviceType", "generate_password");
			getDomianUrl(request, inParams);		
			resParams = epayOrgRegistrationService.execute(requestParams);

			// resParams =
			// epayPasswordGenService.epayServiceBase(requestParams);
			logger.info("resParams : {}", resParams);
		} catch (InvalidKeyException | InvalidAlgorithmParameterException | BadPaddingException
				| IllegalBlockSizeException | UnsupportedEncodingException | NoSuchPaddingException
				| NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("outParams : {}", resParams);

		return "epayorgregsuccess";
	}

	@RequestMapping(value = "/epayureg/registration", method = RequestMethod.POST)
	public String userEpayReg(@RequestParam Map<String, String> allRequestParams,HttpServletRequest request, HttpSession session,
			ModelMap modelMap) {
		boolean errorFlag = false;
		ModelMap inParams = new ModelMap();
		ModelMap outParams = new ModelMap();

		if (allRequestParams != null && allRequestParams.size() > 0) {

			for (Map.Entry<String, String> entry : allRequestParams.entrySet()) {
				String fieldName = entry.getKey();
				String value = entry.getValue();
				logger.info("fieldName : {}", fieldName);
				logger.info("value : {}", value);
				inParams.addAttribute(fieldName, value);
			}
			logger.info("inParams : {}", inParams);
			ModelMap catParams = new ModelMap();
			inParams.put("actionType", "registration");
	        getDomianUrl(request, inParams);
			catParams = epayUserRegistrationService.execute(inParams);

			logger.info("outParams : {}", outParams);
		}
		return "epayorgregsuccess";
	}

	@RequestMapping(value = "/epayuserreg/emailauth", method = RequestMethod.GET)
	public String userRegEmailAuthentication(@RequestParam String email, HttpSession session, ModelMap modelMap) {
		logger.info("userRegEmailAuthentication start {}");
		try {
			session.setAttribute("userEmailauthparams", email);
			String decryptedString = new EncryptDecrypt().decrypt(email);
			String[] spilitedString = decryptedString.split("\\|");
			String registrationid = spilitedString[0];
			String mobileNo = spilitedString[1];
			String name = spilitedString[2];
			String emailId = spilitedString[3];

			logger.info("spilitedString : {}", spilitedString);
			ModelMap requestParams = new ModelMap();
			ModelMap resParams = new ModelMap();
			requestParams.put("registrationId", registrationid);
			requestParams.put("organaizationName", name);
			requestParams.put("emailId", emailId);
			requestParams.put("mobileNo", mobileNo);
			logger.info("requestParams : {}", requestParams);
			resParams = epayUserRegProfileService.epayServiceBase(requestParams);
			logger.info("resParams : {}", resParams);
			EpayBaseResponse appResponse = (EpayBaseResponse) resParams.get(ServiceErrorConstants.APPLICATION_RESPONSE);
			if ("EPCERR002".equals(appResponse.getErrorStatus())) {
				return "redirect:/epaylogin";
			}
			if ("success".equals(appResponse.getErrorStatus())) {
				modelMap.addAttribute("epayOrgREgUsersProfile", resParams.get("epayOrgREgUsersProfile"));
				modelMap.addAttribute("orgRegStstus", resParams.get("orgRegStstus"));
			}
			if (!"success".equals(appResponse.getErrorStatus()) && !"login".equals(appResponse.getErrorStatus())) {
				return "redirect:sessiontimeout";
			}

		} catch (InvalidKeyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidAlgorithmParameterException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BadPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalBlockSizeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("userRegEmailAuthentication method size {}", modelMap.size());
		logger.info("userRegEmailAuthentication method end{}");
		return "ePayUserRegEmailAuth";
	}

	/**
	 * @param userAgent
	 * @param request
	 */
	private void epayDeviceInfo(String userAgent, HttpServletRequest request) {
		Device device = DeviceUtils.getCurrentDevice(request);
		if (device != null) {
			// to check Device Type .....
			String deviceType = EpayPageConstants.EPAY_DEVICETYPE_UNKNOWN;
			if (device.isNormal()) {
				deviceType = EpayPageConstants.EPAY_DEVICETYPE_DESKTOP;
			} else if (device.isMobile()) {
				Pattern pattern = Pattern.compile("(wv)");
				Matcher matcher = pattern.matcher(userAgent);
				if (matcher.find())
					deviceType = EpayPageConstants.EPAY_DEVICETYPE_MOBILE + "-" + matcher.group(1);
				else
					deviceType = EpayPageConstants.EPAY_DEVICETYPE_MOBILE;

			} else if (device.isTablet()) {
				deviceType = EpayPageConstants.EPAY_DEVICETYPE_TABLET;
			}
			logger.info("Device Type ::::::{}", deviceType);
			// session.setAttribute("deviceType",deviceType);
		}
	}

	@RequestMapping(value = "/epayuserreg/emailauthpasswordgen", method = RequestMethod.POST)
	public String epayUserEmailAuthPwdGen(@RequestParam Map<String, String> allRequestParams,HttpServletRequest request, HttpSession session,
			ModelMap modelMap) {
		boolean errorFlag = false;
		ModelMap inParams = new ModelMap();
		ModelMap outParams = new ModelMap();

		String newPassword = allRequestParams.get("password");
		String newConfirmPassword = allRequestParams.get("password");

		if (newPassword == null || newPassword.equals("") || newConfirmPassword == null
				|| newConfirmPassword.equals("")) {
			return "errorpage";
		}
		if (!newPassword.equals(newConfirmPassword)) {
			return "errorpage";
		}

		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String hashedPassword = passwordEncoder.encode(newPassword);

		String emailauthparams = (String) session.getAttribute("userEmailauthparams");
		String decryptedString;
		ModelMap requestParams = new ModelMap();
		ModelMap resParams = new ModelMap();
		try {
			decryptedString = new EncryptDecrypt().decrypt(emailauthparams);
			String[] spilitedString = decryptedString.split("\\|");
			String registrationid = spilitedString[0];
			String mobileNo = spilitedString[1];
			String name = spilitedString[2];
			String emailId = spilitedString[3];
			logger.info("spilitedString : {}", spilitedString);

			requestParams.put("registrationId", registrationid);
			requestParams.put("name", name);
			requestParams.put("emailId", emailId);
			requestParams.put("mobileNo", mobileNo);
			requestParams.put("hashedPassword", hashedPassword);
			logger.info("requestParams : {}", requestParams);

			requestParams.put("serviceType", "generate_user_password");
        	getDomianUrl(request, requestParams);
			resParams = epayOrgRegistrationService.execute(requestParams);

			// resParams =
			// epayPasswordGenService.epayServiceBase(requestParams);
			logger.info("resParams : {}", resParams);
		} catch (InvalidKeyException | InvalidAlgorithmParameterException | BadPaddingException
				| IllegalBlockSizeException | UnsupportedEncodingException | NoSuchPaddingException
				| NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("outParams : {}", resParams);

		return "epayorgregsuccess";
	}

	@RequestMapping(value = "/epayureg/registrationCheck", method = { RequestMethod.GET })
	public void checkFieldKeyValid(HttpServletRequest request, HttpServletResponse response,
			@RequestParam("sendField") String sendField) {
		logger.debug("checkFieldKeyValid method begin ");
		String result = "success";
		Map outParams = new HashMap();
		ModelMap inParams = new ModelMap();

		try {
			String[] delimitField = sendField.split("\\~");
			String mailId = delimitField[1];
			String mobilNo = delimitField[0];
			if (sendField != null && !sendField.equals("")) {

				inParams.put("emailId", mailId);
				inParams.put("mobileNo", mobilNo);
				inParams.put("actionType", "registrationCheck");

				outParams = epayUserRegistrationService.execute(inParams);

				EpayBaseResponse validationResponse = (EpayBaseResponse) outParams
						.get(ServiceErrorConstants.APPLICATION_RESPONSE);

				if (validationResponse.getErrorCode() == "200"
						|| validationResponse.getErrorStatus().equalsIgnoreCase("VALID")) {
					result = "success";
				} else if (validationResponse.getErrorCode() != "200"
						&& !validationResponse.getErrorStatus().equalsIgnoreCase("VALID")) {
					result = "failure";
				} else {
					result = "failure";
				}
			} else if (sendField == null || sendField.equals("")) {
				result = "failure";
			}

			PrintWriter out = null;
			try {
				out = response.getWriter();
				out.print(result);
			} catch (Exception e) {
				logger.error("Exception in :" + e.getMessage());
			} finally {
				out.close();
			}

		} catch (Exception e) {
			logger.error("Exception has occured in the checkFieldKeyValid method");
		}
		logger.debug("checkFieldKeyValid method ends ");
		// return null;
	}

}
