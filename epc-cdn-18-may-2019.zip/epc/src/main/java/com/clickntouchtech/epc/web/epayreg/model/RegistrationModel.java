package com.clickntouchtech.epc.web.epayreg.model;

import com.clickntouchtech.epc.web.epayment.payment.model.EpayBaseModel;

public class RegistrationModel implements EpayBaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private String orgName;
	private String orgType;
	private String orgSubType;
	private String email;
	private String phoneNo;
	private String orgaddress;
	private String district;
	private String state;
	private String pincode;
	private String proofType;
	private String proofValue;
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the orgName
	 */
	public String getOrgName() {
		return orgName;
	}
	/**
	 * @param orgName the orgName to set
	 */
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	/**
	 * @return the orgType
	 */
	public String getOrgType() {
		return orgType;
	}
	/**
	 * @param orgType the orgType to set
	 */
	public void setOrgType(String orgType) {
		this.orgType = orgType;
	}
	/**
	 * @return the orgSubType
	 */
	public String getOrgSubType() {
		return orgSubType;
	}
	/**
	 * @param orgSubType the orgSubType to set
	 */
	public void setOrgSubType(String orgSubType) {
		this.orgSubType = orgSubType;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the phoneNo
	 */
	public String getPhoneNo() {
		return phoneNo;
	}
	/**
	 * @param phoneNo the phoneNo to set
	 */
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	/**
	 * @return the orgaddress
	 */
	public String getOrgaddress() {
		return orgaddress;
	}
	/**
	 * @param orgaddress the orgaddress to set
	 */
	public void setOrgaddress(String orgaddress) {
		this.orgaddress = orgaddress;
	}
	/**
	 * @return the district
	 */
	public String getDistrict() {
		return district;
	}
	/**
	 * @param district the district to set
	 */
	public void setDistrict(String district) {
		this.district = district;
	}
	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * @return the pincode
	 */
	public String getPincode() {
		return pincode;
	}
	/**
	 * @param pincode the pincode to set
	 */
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	/**
	 * @return the proofType
	 */
	public String getProofType() {
		return proofType;
	}
	/**
	 * @param proofType the proofType to set
	 */
	public void setProofType(String proofType) {
		this.proofType = proofType;
	}
	/**
	 * @return the proofValue
	 */
	public String getProofValue() {
		return proofValue;
	}
	/**
	 * @param proofValue the proofValue to set
	 */
	public void setProofValue(String proofValue) {
		this.proofValue = proofValue;
	}

}
