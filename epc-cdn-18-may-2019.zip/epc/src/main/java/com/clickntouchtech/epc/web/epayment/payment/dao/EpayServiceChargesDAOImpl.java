package com.clickntouchtech.epc.web.epayment.payment.dao;

import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.clickntouchtech.epc.web.framework.exception.EpayDaoException;
import com.clickntouchtech.epc.web.framework.util.EpaySQLConstants;

@Repository
public class EpayServiceChargesDAOImpl implements EpayServiceChargesDAO{
	
	protected final Logger logger = LoggerFactory.getLogger(EpayServiceChargesDAOImpl.class);
	
    private JdbcTemplate jdbcTemplate;
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.setJdbcTemplate(new JdbcTemplate(dataSource));
	}

	public Map  getServiceChargeOrg(String bankCode, String merchantCode, String corpID,double debitAmount) {
		logger.info(" getCommissionAmountForCorporate(String bankCode, String merchantCode, String corpId, Double debitAmount) method begins");
		logger.info("merchantCode: {}", merchantCode  );
		Map commissionMap = null;
	 
		if (bankCode != null && merchantCode != null ) {
			Object params[] = {corpID,merchantCode,debitAmount,debitAmount};
			try {
				commissionMap = getJdbcTemplate().queryForMap(
						EpaySQLConstants.EPAY_TRANS_SERVICE_CHARGES, params);
			} catch (DataAccessException accessException) {
				logger.error("Exception occured :{}", accessException);
				EpayDaoException.throwException("RTGS023", accessException);
			}
		} else
			EpayDaoException.throwException("RTGS024");
		logger
				.info(" getCommissionAmountForCorporate(String bankCode, String merchantCode, String corpId, Double debitAmount) method ends");
		return commissionMap;
	}
}
