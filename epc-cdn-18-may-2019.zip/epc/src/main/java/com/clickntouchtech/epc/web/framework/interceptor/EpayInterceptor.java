package com.clickntouchtech.epc.web.framework.interceptor;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.clickntouchtech.epc.web.framework.exception.EpayBaseResponse;
import com.clickntouchtech.epc.web.framework.util.SessionValidator;

public class EpayInterceptor extends HandlerInterceptorAdapter {
	
	private static final Logger logger = LoggerFactory.getLogger(EpayInterceptor.class);
	
	public void postHandle(HttpServletRequest request,HttpServletResponse response, Object handler,ModelAndView modelAndView) throws Exception {
		logger.info("postHandle begin");
		
        Map model = new ModelMap();
        String errorView = "commonerror";
        if(modelAndView != null){
        model = modelAndView.getModel();
        
        if(model != null && !model.isEmpty() && model.size() > 0)	{
        	EpayBaseResponse errorResponse = (EpayBaseResponse) model.get("applicationResponse");
        	
	        if(errorResponse != null){            	
	           String status = errorResponse.getErrorStatus();
	            if(request.getAttribute("newErrorCode")!=null){
	                status = "failure";
	                errorResponse.setErrorCode(request.getAttribute("newErrorCode").toString());
	            }
	            String customizederror = (String) model.get("customizederror");
	            if (status.equalsIgnoreCase("failure")) {
	            	logger.info("call common error page");
	                modelAndView.setViewName(errorView);
	            }
	            if("required".equals(customizederror)) {
	            	logger.info("call customized error page");
	            	modelAndView.setViewName("customizederror");
	            }
	        }
	}
        }
         
    }

    public boolean preHandle(HttpServletRequest request,HttpServletResponse response, Object handler) {
    	logger.info("preHandle begin");
        HttpSession session = request.getSession(false);
        boolean sessionflag=false;
       try{
        	sessionflag=SessionValidator.isValidSession(request,response,"");
	        if(sessionflag){
	        	session.setAttribute("viewName","false");
	            session.setAttribute("currentURL",request.getServletPath().substring(1));
	        }
       }catch(Exception E){
    	   E.printStackTrace();
       }
       logger.info("preHandle end");
		return sessionflag;
	}
	
}
