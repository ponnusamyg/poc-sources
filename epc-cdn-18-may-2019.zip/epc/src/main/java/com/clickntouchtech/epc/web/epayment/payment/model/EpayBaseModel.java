package com.clickntouchtech.epc.web.epayment.payment.model;

import java.io.Serializable;

public interface EpayBaseModel extends Serializable
{
	
}