package com.clickntouchtech.epc.web.epayment.history.model;

import java.util.List;

import com.clickntouchtech.epc.web.epayment.payment.model.EpayBaseModel;

public class EpayUserAuthModel implements EpayBaseModel{
	
	private String roles;
	
	private List role;

	/**
	 * @return the roles
	 */
	public String getRoles() {
		return roles;
	}

	/**
	 * @param roles the roles to set
	 */
	public void setRoles(String roles) {
		this.roles = roles;
	}

	/**
	 * @return the role
	 */
	public List getRole() {
		return role;
	}

	/**
	 * @param role the role to set
	 */
	public void setRole(List role) {
		this.role = role;
	}

	 
	
	
}
