package com.clickntouchtech.epc.web.framework.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.clickntouchtech.epc.web.framework.util.SessionValidator;

public class EpaySessioninterceptor implements HandlerInterceptor  {
	
	private static final Logger logger = LoggerFactory.getLogger(EpaySessioninterceptor.class);
	
	@Override
	public boolean preHandle(HttpServletRequest request,HttpServletResponse response, Object handler) throws Exception {
		
		System.out.println("sessioninterceptor Pre-handle");
		
	  	logger.info("preHandle begin");
        HttpSession session = request.getSession(false);
        boolean sessionflag=false;
       try{
        if (SessionValidator.isValidReferer(request,response,session)) {
        	sessionflag=SessionValidator.isValidSession(request,response,"");
        	
	        if(sessionflag){
	        	session.setAttribute("viewName","false");
	            session.setAttribute("currentURL",request.getServletPath().substring(1));
	        }
		}
       }catch(Exception E){
    	   E.printStackTrace();
       }
       logger.info("preHandle end");
		return sessionflag;
	}
	
	
	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {		
	}
	
	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
	}
}