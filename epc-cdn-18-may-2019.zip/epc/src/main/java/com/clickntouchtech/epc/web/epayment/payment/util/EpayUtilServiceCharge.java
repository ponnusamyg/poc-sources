package com.clickntouchtech.epc.web.epayment.payment.util;

import java.math.BigDecimal;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.clickntouchtech.epc.web.epayment.payment.dao.EpayServiceChargesDAO;

@Service
public class EpayUtilServiceCharge {
	
	protected final Logger logger = LoggerFactory.getLogger(EpayUtilServiceCharge.class);
	
	@Autowired
	private EpayServiceChargesDAO epayServiceChargesDAOImpl;

	public double getEpayInstitutionGroupCharge(double debitAmount){
		return getEpayCharge(debitAmount);
	}

	public double getEpayCharge(double debitAmount){
		return getEpaymentCharge(debitAmount);
	}

	public double getEpaymentCharge(double debitAmount){
		return getEpayOrgChgrGroupCharge(debitAmount);
	}

	public double getEpayOrgChgrGroupCharge(double debitAmount){
		return getEpaymentOrgGroupCharge(debitAmount);
	}

	public double getEpaymentOrgGroupCharge(double debitAmount){
		return getEpayOrgGroupCharge(debitAmount);
	}

	public double getEpayOrgGroupCharge(double debitAmount){
		double commAmount = 0;
		try{
				double percentageValue;
				double minAmount=12.36;
				percentageValue=(debitAmount<=2000)?0.8425:1.1236;
				commAmount=(debitAmount)*(percentageValue/100);
				if(commAmount<minAmount)
				{
					commAmount=minAmount;
				}
			logger.info("Service Charge for the transaction : {}",commAmount);
			return new Double(commAmount);
		}catch(Exception e){
			return new Double(commAmount);
		}
	}

	public double getEpayServiceCharge(double debitAmount,String debitBranchCode,String corpId,String type){
		double commAmount = 0;
		try{
			String bankCode = debitBranchCode.substring(0,1);
			
			logger.info("Type before Calling :{}",type);
			commAmount = getEpayServiceAmount(bankCode, type, new Double(debitAmount),corpId);
			logger.info("Service Charge for the transaction :{} ",commAmount);
			return new Double(commAmount);
		}catch(Exception e){
			return new Double(commAmount);
		}
	}
	
	public double getSAmount(String bankCode,String type,Double debitAmount,String corpId)
	{
		return getServiceAmount(bankCode, type, debitAmount, corpId);
	}

	public double getServiceAmount(String bankCode,String type,Double debitAmount,String corpId)
	{
		return getEpayServiceAmount(bankCode, type, debitAmount, corpId);
	}

	public double getEpayServiceAmount(String bankCode,String type,Double debitAmount,String corpId)
	{
		//boolean isCommissionReq=isCommissionRequiredForCorporate(dproductCode);
		double commAmount=0;
		
		logger.info("corpId:: {}",corpId);
		logger.info("type::{}",type);
		
					logger.info("SME POWER CURRENT ACCOUNT - WAIVER OF NEFT & RTGS CHARGES :{} ",type);
					Map commissionMap = epayServiceChargesDAOImpl.getServiceChargeOrg(bankCode,type,corpId,debitAmount);				
				if(commissionMap!=null) {
					double minAmount=0;
					double maxAmount=0;
					BigDecimal percentageValue=(BigDecimal)commissionMap.get("percentage");
					BigDecimal minAmountVal=(BigDecimal)commissionMap.get("minamount");
					BigDecimal maxAmountVal=(BigDecimal)commissionMap.get("maxamount");
					BigDecimal baseValue=(BigDecimal) commissionMap.get("basevalue");
					logger.info("baseValue:::{}",baseValue);

					if (percentageValue==null )
						percentageValue=new BigDecimal(0);
					if(baseValue!=null&& baseValue.intValue()!=0)
					{
						logger.info("into the bae calculation");
						commAmount=(Math.ceil(debitAmount.doubleValue()/baseValue.doubleValue())*(percentageValue.doubleValue()));
						logger.info("calculated com: {}",commAmount);
					}else
						commAmount=(debitAmount.doubleValue())*(percentageValue.doubleValue()/100);
					if (minAmountVal==null )
						minAmountVal=new BigDecimal(0);
					if (maxAmountVal==null )
						maxAmountVal=new BigDecimal(0);
					minAmount=minAmountVal.doubleValue();
					maxAmount=maxAmountVal.doubleValue();
					
						if (commAmount<minAmount)
							commAmount=minAmount;
						else if (commAmount>maxAmount)
							commAmount=maxAmount;
					
					BigDecimal comAmount=new BigDecimal(commAmount);	
					comAmount=comAmount.setScale(2,BigDecimal.ROUND_HALF_EVEN);
					commAmount=comAmount.doubleValue();
				}
		return commAmount;

	}
	
}
