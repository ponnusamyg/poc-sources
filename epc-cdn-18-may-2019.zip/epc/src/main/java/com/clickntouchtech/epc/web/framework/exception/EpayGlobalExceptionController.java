package com.clickntouchtech.epc.web.framework.exception;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;


@ControllerAdvice
public class EpayGlobalExceptionController {
	
	private static final Logger logger = LoggerFactory.getLogger(EpayGlobalExceptionController.class);
	
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public String handleError405(HttpServletRequest request, Exception e)   {
    	    logger.info("-------handleError405-------method calling-----");
    	    
    	    HttpSession session = request.getSession(false);
    	    SecurityContextHolder.clearContext();
    	    if(session != null)
    	    	session.invalidate();
            return "sessiontimeout";
      }
    
    @ExceptionHandler(EpayTamperException.class)
    public String handleTamperingException(HttpServletRequest request, Exception e) {
    	
    	logger.info("------handleTamperingException--------method calling-------");
	    
	    HttpSession session = request.getSession(false);
	    SecurityContextHolder.clearContext();
	    if(session != null)
	    	session.invalidate();
	    
        return "tamperingerror";
    }
    
    
}