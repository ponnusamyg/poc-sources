package com.clickntouchtech.epc.web.epayment.payment.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.clickntouchtech.epc.web.epayment.payment.dao.EpayUserDashBoardDao;
import com.clickntouchtech.epc.web.epaysecurity.bean.EpayUsersProfile;
import com.clickntouchtech.epc.web.epaysecurity.dao.EpayUserProfileDao;
import com.clickntouchtech.epc.web.framework.exception.EpayApplicationException;
import com.clickntouchtech.epc.web.framework.exception.EpayBaseResponse;
import com.clickntouchtech.epc.web.framework.exception.EpayDaoException;
import com.clickntouchtech.epc.web.framework.service.EpayBaseAbsService;
import com.clickntouchtech.epc.web.framework.service.ServiceErrorConstants;

@Service
public class EpayUserDashBoardService extends EpayBaseAbsService {

	private static final Logger logger = LoggerFactory.getLogger(EpayUserDashBoardService.class);

	@Autowired
	private EpayUserProfileDao epayUserProfile;
	@Autowired
	private EpayUserDashBoardDao epayUserDashBoardDao;

	public ModelMap execute(ModelMap inputParams) {
		logger.info("EpayUserDashBoardService execute method begins");
		ModelMap outParams = new ModelMap();
		
		ModelMap inParams = new ModelMap();
		int loginCount = 0;
		int txnSuccessCount = 0;
		int txnCount = 0;
		List topTransactions = null;
		List successTxn =  null;
		List failureTxn = new ArrayList();
		EpayBaseResponse response = new EpayBaseResponse();
		response.setErrorStatus(ServiceErrorConstants.FAILURE);
		try {
			String userId = (String) inputParams.get("userId");
			EpayUsersProfile usersLoginDetail = null;
			if (userId != null && !userId.isEmpty()) {
				inParams.put("userId", userId);
				loginCount 			= 	epayUserDashBoardDao.getEpayUserLoginHistoryCount(userId);
				txnSuccessCount 	= 	epayUserDashBoardDao.getEpayUserOverAllSuccessTxnCounts(userId);
				txnCount 			= 	epayUserDashBoardDao.getEpayUserOverAllTxnCounts(userId);
				topTransactions		=	epayUserDashBoardDao.getTopTransactions(userId);
				usersLoginDetail 	= 	epayUserDashBoardDao.getEpayUserProfileDetails(inParams);
				successTxn		 	= 	epayUserDashBoardDao.getSuccessTransactions(userId);
				failureTxn 			= 	epayUserDashBoardDao.getFailureTransactions(userId);
				logger.info("loginCount::::::::::::{}", loginCount);
				logger.info("txnSuccessCount:::::::{}", txnSuccessCount);
				logger.info("txnCount::::::::::::::{}", txnCount);
				logger.info("usersLoginDetail::::::{}", usersLoginDetail);
				logger.info("successTxn::::::::::::{}", successTxn);
				logger.info("failureTxn::::::::::::{}", failureTxn);
			}
			outParams.addAttribute("successTxn", successTxn);
			outParams.addAttribute("failureTxn", failureTxn);
			outParams.addAttribute("loginCount", loginCount);
			outParams.addAttribute("txnSuccessCount", txnSuccessCount);
			outParams.addAttribute("txnCount", txnCount);
			outParams.addAttribute("topTransactions", topTransactions);
			outParams.addAttribute("usersLoginDetail", usersLoginDetail);
		
			response.setErrorStatus(ServiceErrorConstants.SUCCESS);
		} catch (EpayApplicationException cmsexp) {
			cmsexp.printStackTrace();
			response.setErrorCode("V101");
		} catch (EpayDaoException daoexp) {
			response.setErrorCode(daoexp.getErrorCode());
		}
		outParams.addAttribute(ServiceErrorConstants.APPLICATION_RESPONSE, response);
		logger.info("EpayUserProfileService execute method end");
		return outParams;
	}
}
