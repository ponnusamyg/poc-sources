package com.clickntouchtech.epc.web.epaysecurity.dao;

import java.util.List;

import org.springframework.ui.ModelMap;

public interface EpayUserProfileDao {

	public String getUserByLogin(String username);

	public List<String> getUserRoles(String username);
	
	public String getUserHistoryInfo(ModelMap userObj);
}