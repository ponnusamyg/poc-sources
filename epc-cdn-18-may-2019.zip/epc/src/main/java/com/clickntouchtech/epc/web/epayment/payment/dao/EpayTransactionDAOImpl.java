package com.clickntouchtech.epc.web.epayment.payment.dao;

import java.sql.Types;
import java.util.Iterator;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.nativejdbc.SimpleNativeJdbcExtractor;
import org.springframework.stereotype.Repository;

import com.clickntouchtech.epc.web.epayment.payment.model.EpayModelParams;
import com.clickntouchtech.epc.web.epayment.payment.model.Transaction;
import com.clickntouchtech.epc.web.framework.exception.EpayDaoException;
import com.clickntouchtech.epc.web.framework.util.EpaySQLConstants;
import com.clickntouchtech.epc.web.framework.util.ErrorConstants;

@Repository
public class EpayTransactionDAOImpl implements EpayTransactionDAO  {
	
	protected final Logger logger = LoggerFactory.getLogger(EpayTransactionDAOImpl.class);
	
    private JdbcTemplate jdbcTemplate;
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
		this.jdbcTemplate.setNativeJdbcExtractor(new SimpleNativeJdbcExtractor());
		//this.jdbcTemplate.setNativeJdbcExtractor(new WebSphereNativeJdbcExtractor());
	}

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.setJdbcTemplate(new JdbcTemplate(dataSource));
	}
	

	public String getEpayTransaction(Transaction transaction , EpayModelParams epayModelParams) {

        if (logger.isDebugEnabled()) {
            logger.debug("createTransaction(Transaction transaction) Begin->transaction :{}", transaction);
        }
        try {

            Object[] debit = null;
            if (transaction.getDebit() != null) {
                debit = transaction.getDebit().toObject();
                if (logger.isDebugEnabled()) {
                    logger.debug(" Debit leg : {}", debit);
                }

                for (int i = 0; i < debit.length; i++)
                    if (logger.isDebugEnabled()) {
                        logger.debug("Debit Leg value : {}", debit[i]);
                    }
            }

            logger.info("######getBankCode###########: {}",transaction.getBankCode());
            logger.info("######getAddParams###########: {}",transaction.getAddParams());
            logger.info("######getBenaddress###########: {}",transaction.getBenaddress());
            logger.info("######getCredit###########: {}",transaction.getCredit());
            logger.info("######getDebit###########: {}",transaction.getDebit());
            logger.info("######getDebit###########: {}",transaction.getDebit().getAdditionalParams());
            logger.info("######getFriendlyName###########: {}",transaction.getFriendlyName());
            logger.info("######getName###########: {}",transaction.getName());
            logger.info("######getPath###########: {}",transaction.getPath());
            logger.info("######getScheduledDate###########: {}",transaction.getScheduledDate());
            logger.info("######getSmallFlag###########: {}",transaction.getSmallFlag());
            
            	String referenceNo ="EPC0000"+getPayRefNo();
            	logger.info("######referenceNo###########: {}",referenceNo);
            	try{
             	   
                    Object[] parameters = new Object[] {referenceNo};
                    int[] sqlTypes = {Types.VARCHAR};
                     getJdbcTemplate().update(INSERT_PAYMENT_REF_NO, parameters,sqlTypes);
                    
                    logger.info("Record inserted to epaypaymentstransactions");
                }catch(DataAccessException daoExp){
                    logger.error("Unable to insert to :: {}", referenceNo);
                    logger.error("exception is ::{} ", daoExp);
                    EpayDaoException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE); 
                }
//              Map<Integer, Integer> map = new HashMap<Integer, Integer>();
            	if(referenceNo!=null){
            		Iterator<Map.Entry<Integer, Integer>> entries = transaction.getDebit().getAdditionalParams().entrySet().iterator();
                    while (entries.hasNext()) {
                        Map.Entry<Integer, Integer> entry = entries.next();
                        System.out.println("Key =##### " + entry.getKey() + ", Value######### = " + entry.getValue());
                        if(!"serviceChargeMap".equals(entry.getKey())){
                        	try{
                                Object[] parameters = new Object[] {referenceNo,entry.getKey(),entry.getValue(),referenceNo};
                                int[] sqlTypes = {Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
                                 getJdbcTemplate().update(EpaySQLConstants.EPAY_USER_PAYMENTS_REF_KEY, parameters,sqlTypes);
                                logger.info("Record inserted to epayUserPaymentsRefKey");
                                }catch(DataAccessException daoExp){
                                    logger.error("Unable to insert to :: {}", entry.getKey());
                                    logger.error("exception is ::{} ", daoExp);
                                    EpayDaoException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE); 
                                }
                        }
                        
                    }
                    updateEpayTransData(referenceNo, epayModelParams);
            	}
                
            	
            	
                return referenceNo;
            /*}
            else {
                EpayDaoException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
            }*/

        }

        catch (DataAccessException ex) {
            EpayDaoException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, ex);
        }
        catch (Exception ex) {
            
            EpayDaoException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE,ex);
        }
        return null;
    }
	
	 
	 public void updateEpayTransData( String refNo, EpayModelParams epayModelParams) throws EpayDaoException
		{
			logger.debug("updateEpayTransData( String refNo, Map inParams)  - begin");
			logger.info("Reference No.:{}",refNo);
			logger.info("epayModelParams No.:{}",epayModelParams);
			String UPDATE_PRELOGIN_ECHEQUE_MASTER="update epaypaymentstransactions set totalamount=?,epayamount = ?, serviceamount =?,paymentstatus=?,gatewayrefno=?, settlementstatus= 'N' , "+
			"classificationId=?, organizationId=?, convenienceamount=?, modeofpayment = ?,  serviceamounttype=? where epayrefno = ?";
			try{
					final int sqlTypes[]={java.sql.Types.DOUBLE,java.sql.Types.DOUBLE,java.sql.Types.DOUBLE,java.sql.Types.VARCHAR,java.sql.Types.VARCHAR,
										  java.sql.Types.VARCHAR,java.sql.Types.VARCHAR,java.sql.Types.VARCHAR,
										  java.sql.Types.VARCHAR,java.sql.Types.VARCHAR,
										  java.sql.Types.VARCHAR};
					Object[] params={epayModelParams.getTotalamount(),
									 epayModelParams.getEpayamount(),
									 epayModelParams.getServiceamount(),
									 epayModelParams.getPaymentstatus(),
									 epayModelParams.getGatewayrefno(),
									 epayModelParams.getClassificationId(),
									 epayModelParams.getOrganizationId(),
									 epayModelParams.getConvenienceamount(),
									 epayModelParams.getModeofpayment(),
									 epayModelParams.getServiceamounttype(),
									 refNo
									};
					int updateCount = getJdbcTemplate().update(UPDATE_PRELOGIN_ECHEQUE_MASTER,params,sqlTypes);
					logger.info("Number of rows updated: {}",updateCount);
			}catch(DataAccessException dataAccessException){
				dataAccessException.printStackTrace();
				logger.error("Error occured :",dataAccessException);
				EpayDaoException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}catch(Exception e){
				e.printStackTrace();
				EpayDaoException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
			logger.debug("update( String refNo, String responseString)  - end");
		}
	 
	 public void updateEpayTransStatus(String refNo, String MerchantRefNo, String status, String RRN,String statusDescription) throws EpayDaoException
		{
			logger.debug("updateTransactionStatus( String refNo, String MerchantRefNo, String Status, String RRN)  - begin");
			logger.info("Reference No.: {}",refNo);
			if("0".equalsIgnoreCase(status)||"s".equalsIgnoreCase(status)){
				status = "00";
			}
			String UPDATE_PRELOGIN_ECHEQUE_MASTER="update epaypaymentstransactions set gatewayrefno = ?, paymentstatus = ?, updationtime = sysdate(), txntime = sysdate(), txnrefno =?,paymentdesc = ?  where epayrefno = ?";
			try{
					final int sqlTypes[]={ java.sql.Types.VARCHAR,java.sql.Types.VARCHAR,java.sql.Types.VARCHAR,java.sql.Types.VARCHAR,java.sql.Types.VARCHAR};
					Object[] params={MerchantRefNo,status,RRN,statusDescription,refNo};
					int updateCount = getJdbcTemplate().update(UPDATE_PRELOGIN_ECHEQUE_MASTER,params,sqlTypes);
					logger.info("Number of rows updated: {}",updateCount);
					
			}catch(DataAccessException dataAccessException){
				logger.error("Error occured :",dataAccessException);
				EpayDaoException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}catch(Exception e){
				EpayDaoException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
			}
			logger.debug("update( String refNo, String MerchantRefNo, String status, String RRN)  - end");
		}
	
	 
	public String getPayRefNo() {
		logger.info("getPayRefNo - begins");
		String refNo = "";
		String sqlQuery = null;
		try {

			sqlQuery = "SELECT nextval('epay_payment_sequence') as next_sequence";
			logger.info("sqlQuery :: {}", sqlQuery);
			refNo = (String) getJdbcTemplate().queryForObject(sqlQuery, String.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info("getMerchantId - end");
		return refNo;
	}
	
	private String INSERT_PAYMENT_REF_NO = "insert into epaypaymentstransactions  (epayrefno,creationtime,updationtime) values (?,sysdate(),sysdate())"  ;
	
	

			 
}
