
package com.clickntouchtech.epc.web.framework.util;

import com.clickntouchtech.epc.web.framework.util.Constants;

public interface EpaySQLConstants extends Constants {

	public static final String EPAY_OVERALL_PAYMENT_HISTROY = "select a.epayrefno,a.totalamount,a.epayamount,a.serviceamount,a.paymentstatus,a.paymentdesc,a.txnrefno,a.txntime,b.userid,b.reqip,b.devicetype,b.creationtime,b.updationtime,b.resip"
			+ " from epaypaymentstransactions a, epayuserspayloginhistory b,epay_users_profile c "
			+ " where a.epayrefno=b.epayrefno and (b.userid=c.loginid  or b.userid=c.mailid or b.userid=c.phoneno) and b.userid=? order by a.epayrefno desc";

	public static final String EPAY_USER_LOGIN_HISTORY = "select * from epayuserspayloginhistory b,epay_users_profile c where b.userid=? and "
			+ "(b.userid=c.loginid  or b.userid=c.mailid or b.userid=c.phoneno)";

	public static final String EPAY_USER_LOGIN_COUNT = "select count(*) from epay_user_login_history b,epay_users_profile c where b.user_id=? and "
			+ "(b.user_id=c.loginid  or b.user_id=c.mailid or b.user_id=c.phoneno)";

	public static final String EPAY_USER_TRANSACTION_COUNT = "select count(*) from epaypaymentstransactions a, epayuserspayloginhistory b,epay_users_profile c "
			+ "  where a.epayrefno=b.epayrefno and (b.userid=c.loginid  or b.userid=c.mailid or b.userid=c.phoneno) and b.userid=? #tobereplaced#";

	public static final String EPAY_USER_TOP_TRANSACTIONS = "select a.epayrefno,totalamount,a.paymentstatus,a.paymentdesc,a.txnrefno"
			+ "	,d.classificationname,e.organizationname,e.orgtype "
			+ "	from epaypaymentstransactions a, epayuserspayloginhistory b,epay_users_profile c ,epayorgclassification d,epayorganizationmaster e"
			+ "	where a.epayrefno=b.epayrefno and (b.userid=c.loginid  or b.userid=c.mailid or b.userid=c.phoneno) "
			+ "	and a.classificationid=d.classificationid and a.organizationid=e.organizationid and b.userid=? "
			+ "	#tobereplaced# ";

	public static final String EPAYMENT_MODE = "select count(*) from epayorgclassification where #tobereplaced#=? and category_id=?";

	public String EPAY_USERS_PAY_LOGIN_HISTORY = "insert into epayuserspayloginhistory(epayrefno,userid,reqip,reqsession,reqjvm,devicetype,creationtime) "
			+ " values(?,?,?,?,?,?,sysdate())";

	public String EPAY_USERS_PAY_LOGIN_HISTORY_UPDATE = "update epayuserspayloginhistory set ressession = ?,resjvm = ?,resip = ?,status = ?,remarks = ?,updationtime= sysdate() where epayrefno = ?";

	public String EPAY_ORG_GROUP_DETAILS = "select institute_group from epayorganizationmaster where institute_id=? ";

	public String EPAY_ORG_PAY_MODE = "select #tobereplaced# from epayorgclassification where classificationid=?";

	public String EPAY_PAYMENT_PARAMS = "select userkey,uservalue from epayuserpaymentsrefkey where id=(select epayrefno from epaypaymentstransactions where epayrefno=?)";

	public String EPAY_TRANS_DATA = "select a.totalamount,a.txntime,a.creationtime,a.paymentstatus,a.serviceamounttype recovered_from,a.convenienceamount, "
			+ "a.remarks,a.serviceamount,a.modeofpayment,a.epayamount,a.userid, "
			+ "b.description1,b.description2,b.enddate,'epc','a1100',a.gatewayrefno from "
			+ "epaypaymentstransactions a, epayorgclassification b, epayorganizationmaster d "
			+ "where a.epayrefno =? and a.classificationid = b.classificationid and d.organizationid=a.organizationid";

	public String EPAY_TRANS_SERVICE_CHARGES = "select (case when orgrootid='default' then  9 when 'default' then 9 else 0 end) num, percentage, minamount, maxamount, basevalue from epaycounterservicecharges where lower(orgrootid) in (? ,'default')   and(upper(gatewaycode) = ?  or upper(gatewaycode)='both') and (slapamount >=? or maxlimit >=?)  limit 1";

	public String EPAY_USER_PAYMENTS_REF_KEY = "insert into epayuserpaymentsrefkey (id,userkey,uservalue,epayrefno) values (?,?,?,?)";

	public String ORGLIST = "select distinct a.organizationid,a.orgrootname, a.organizationname, concat(b.address1,',',b.address2)  address "
			+ ",a.orgtype,c.state,b.phno,b.mailid  from epayorganizationprofile b,epayorganizationmaster a , epayorgclassification c where b.orgrootid = a.orgrootid and "
			+ "c.organizationid=a.organizationid " + " and a.orgstatus = 'active' and a.approvedstatus = 'approved' "
			+ "and c.classificationstatus = 'active' and c.approvedstatus = 'approved' " + "order by organizationname";

	public String SELECT_FEE_PAYMENT_DETAILS = "select a.orgrootid,a.organizationname,b.organizationid,b.organizationname, "
			+ "concat(a.address1, ',',a.address2, ',',a.city, ',',a.district, ',',a.state, ',',a.pincode) address,b.approvedstatus "
			+ "from epayorganizationprofile a, epayorganizationmaster b "
			+ "where  b.organizationid=? and a.orgrootid = b.orgrootid and b.orgstatus = 'active' and approvedstatus = 'approved'";
	public static final String ORG_CLASSIFICATION = "select b.organizationname,a.organizationid,a.state, a.classificationid, a.classificationname,a.repayment,a.classificationmode, a.classificationkey,'' filekeyname ,'' option_value ,a.classifickeyvalue"
			+ " from epayorgclassification a ,epayorganizationmaster b where b.organizationid = a.organizationid and a.classificationid in(select a.classificationid from epayorgclassification a where  a.organizationid= ? #tobereplaced# and a.state= ?) and"
			+ " a.classificationstatus = 'active' ";

	public static final String GET_COMM_DETAILS = "select serviceamountreqq,sourceserviceamount,orgrootid from epayorganizationmaster where organizationid = ? and orgstatus = 'active' ";

	public String SELECT_EPC_CATEGORY_PARAMS = "select a.classificationid,a.fieldsequence,a.fieldkey, a.fieldid,a.filedname,(case when a.fieldsequence='999' then '999' else a.fieldsequence end ),"
			+ "(case when a.fieldtype='options' then 'naoptions' when a.fieldtype='option' then 'naoptions' when  a.fieldtype='fixed' then 'nafixed' else 'natext' end ),a.fieldtype,a.fiedldesc, a.option_value,a.amount,a.mandatory, "
			+ "a.fieldstatus,b.classificationmode from epayorgfielddetails a ,epayorgclassification b where a.classificationid=b.classificationid and  "
			+ "a.classificationid =? and a.fieldstatus = 'active' order by a.fieldsequence asc,a.filedname asc";

	public String SELECT_CATEGORY_PARAMS = " select a.classificationid,a.fieldkey, a.fieldid,a.filedname,a.fieldtype, a.option_value,a.amount,a.mandatory, a.fieldstatus,b.classificationmode, "
			+ "a.fiedldesc from epayorgfielddetails a, epayorgclassification b where a.classificationid=b.classificationid and "
			+ "a.classificationid = ? and a.fieldstatus = 'active' order by a.fiedldesc desc, fieldorder";

	public static final String GET_CLASSIFICATION_DETAILS = "select * from epayorgclassification where classificationid=?";

	public static final String GE_USER_ROLES = "select ud.user_id, ur.role from epay_user ud, epay_user_roles ur,epay_user_role_map urm "
			+ " where ud.user_id = urm.user_id and urm.role_id = ur.role_id and ud.user_id = (select id from epay_users_profile where loginid=? "
			+ " or mailid=? or phoneno=?)";

	public String EPAY_USER_INSERT_DATA = "insert into epay_user_login_history (user_id,ip_address,phycical_address,session_id,engine_id,channel_type,login_time,session_in_time,session_out_time,user_agent) values (?,?,?,?,?,?,sysdate(),sysdate(),sysdate(),?)";

	public static final String GET_FILETXN_CLASSIFICATIONS = "select A.classificationId,A.fieldsequence,A.fieldkey,A.fieldid,A.filedname,A.fieldtype,A.fiedldesc,A.option_value,A.amount,A.mandatory,A.fieldstatus,B.classificationmode"
			+ " from epayOrgFieldDetails A ,epayOrgClassification B where A.classificationId=B.classificationId and A.classificationId=? "
			+ " order by fieldsequence asc ,A.filedname";
	
	public static final String GET_REPORTS_HEADERS_LIST = "select id,tablename,columnname,columndescription,tabletype,columndatatype from epaytablemetadata where tabletype=?";

	public static final String GET_REPORTS_CLASSIFICATIONS=" select classificationid,classificationname from epayorgclassification where classificationstatus='active'"
			+ " and approvedstatus='approved' and organizationid=?";
	

}
