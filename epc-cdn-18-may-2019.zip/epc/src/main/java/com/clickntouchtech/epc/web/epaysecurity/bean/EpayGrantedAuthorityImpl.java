package com.clickntouchtech.epc.web.epaysecurity.bean;

import org.springframework.security.core.GrantedAuthority;

public class EpayGrantedAuthorityImpl implements GrantedAuthority {

	private static final long serialVersionUID = 1L;

	private String role;

	public EpayGrantedAuthorityImpl(String role) {
		this.role = role;
	}

	public String getAuthority() {
		return role;
	}
}