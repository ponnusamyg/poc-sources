package com.clickntouchtech.epc.web.epayment.payment.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.ui.ModelMap;

import com.clickntouchtech.epc.web.epayment.history.model.EpaymentHistoryParams;
import com.clickntouchtech.epc.web.epaysecurity.bean.EpayUsersProfile;
import com.clickntouchtech.epc.web.framework.exception.EpayDaoException;
import com.clickntouchtech.epc.web.framework.util.EpaySQLConstants;

@Repository
public class EpayUserDashBoardDaoImpl implements EpayUserDashBoardDao {

	private static final Logger logger = LoggerFactory.getLogger(EpayUserDashBoardDaoImpl.class);

	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.setJdbcTemplate(new JdbcTemplate(dataSource));
	}

	public int getEpayUserLoginHistoryCount(String userId) {
		logger.info("getEpayUserLoginHistoryCount  ", userId);
		int loginCount = 0;
		try {
			Object[] queryParams = { userId };
			logger.info("queryParams :: {}", queryParams);
			loginCount = (Integer) getJdbcTemplate().queryForObject(EpaySQLConstants.EPAY_USER_LOGIN_COUNT, queryParams,Integer.class);
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception has occured" + dataAccessException);
		}
		return loginCount;
	}

	public int getEpayUserOverAllTxnCounts(String userId) {
		logger.info("getEpayUserOverAllTxnCounts  ", userId);
		int txncounts = 0;
		try {
			Object[] queryParams = { userId };
			logger.info("queryParams :: {}", queryParams);
			String txnCountQry = EpaySQLConstants.EPAY_USER_TRANSACTION_COUNT.replaceAll("#tobereplaced#", " ");
			txncounts = (Integer) getJdbcTemplate().queryForObject(txnCountQry, queryParams,Integer.class);
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception has occured" + dataAccessException);
		}
		return txncounts;

	}

	public int getEpayUserOverAllSuccessTxnCounts(String userId) {
		logger.info("getEpayUserOverAllSuccessTxnCounts  ", userId);
		int txncounts = 0;
		try {
			Object[] queryParams = { userId };
			logger.info("queryParams :: {}", queryParams);
			String txnCountQry = EpaySQLConstants.EPAY_USER_TRANSACTION_COUNT.replaceAll("#tobereplaced#",
					" and A.paymentstatus='success' ");
			logger.info("txnCountQry#######", txnCountQry);
			txncounts = (Integer) getJdbcTemplate().queryForObject(txnCountQry, queryParams,Integer.class);
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception has occured" + dataAccessException);
		}
		return txncounts;

	}

	public List getTopTransactions(String userId) {
		logger.debug("getTopTransactions(String userId) begins");

		List topTransactions = new ArrayList();
		Object[] queryParams = { userId };
		logger.info("Params:::{}", queryParams);
		try {
			String txnQry = EpaySQLConstants.EPAY_USER_TOP_TRANSACTIONS.replaceAll("#tobereplaced#",
					"  order by a.updationtime desc limit 5 ");
			topTransactions = (List) getJdbcTemplate().query(txnQry, queryParams, new TopTransactionsRowMapper());
			logger.info("Size#########:{}", topTransactions.size());
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception occured :{}", dataAccessException);
			EpayDaoException.throwException("SUV001");
		} catch (EpayDaoException incorrectResultSizeDataAccessException) {
			logger.error("Exception occured :{}", incorrectResultSizeDataAccessException);
			EpayDaoException.throwException("SUV001");
		}
		logger.debug("topTransactions(String corpId) begins");
		return topTransactions;
	}

	public List getFailureTransactions(String userId) {
		logger.debug("getTopTransactions(String userId) begins");

		List topTransactions = new ArrayList();
		Object[] queryParams = { userId };
		logger.info("FailureTransactions Params:::{}", queryParams);
		try {
			String txnQry = EpaySQLConstants.EPAY_USER_TOP_TRANSACTIONS.replaceAll("#tobereplaced#",
					" and a.paymentstatus!='success' order by a.updationtime desc limit 10 ");
			topTransactions = (List) getJdbcTemplate().query(txnQry, queryParams, new TopTransactionsRowMapper());
			logger.info("FailureTransactions Size#########:{}", topTransactions.size());
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception occured :{}", dataAccessException);
			EpayDaoException.throwException("SUV001");
		} catch (EpayDaoException incorrectResultSizeDataAccessException) {
			logger.error("Exception occured :{}", incorrectResultSizeDataAccessException);
			EpayDaoException.throwException("SUV001");
		}
		logger.debug("topTransactions(String corpId) begins");
		return topTransactions;
	}

	public List getSuccessTransactions(String userId) {
		logger.debug("getTopTransactions(String userId) begins");

		List topTransactions = new ArrayList();
		Object[] queryParams = { userId };
		logger.info("SuccessTransactions:::{}", queryParams);
		try {
			String txnQry = EpaySQLConstants.EPAY_USER_TOP_TRANSACTIONS.replaceAll("#tobereplaced#",
					" and a.paymentstatus='success' order by a.updationtime desc limit 10 ");
			topTransactions = (List) getJdbcTemplate().query(txnQry, queryParams, new TopTransactionsRowMapper());
			logger.info("SuccessTransactions Size#########:{}", topTransactions.size());
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception occured :{}", dataAccessException);
			EpayDaoException.throwException("SUV001");
		} catch (EpayDaoException incorrectResultSizeDataAccessException) {
			logger.error("Exception occured :{}", incorrectResultSizeDataAccessException);
			EpayDaoException.throwException("SUV001");
		}
		logger.debug("topTransactions(String corpId) begins");
		return topTransactions;
	}

	private class TopTransactionsRowMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int arg1) throws SQLException {
			EpaymentHistoryParams histParams = new EpaymentHistoryParams();
			histParams.setRefenceNo(rs.getString("epayrefno"));
			histParams.setTotalAmount(Double.valueOf((rs.getString("totalamount"))));
			histParams.setOnlineDebitStatus(rs.getString("paymentstatus"));
			histParams.setStatus_description(rs.getString("paymentdesc"));
			histParams.setClassification(rs.getString("classificationname"));
			histParams.setOrganizationName(rs.getString("organizationname"));
			histParams.setOrganizationType(rs.getString("orgtype"));
			return histParams;
		}
	}

	public List getEpayUserLoginDetails(String userId) {
		logger.debug("getEpayUserLoginDetails(String userId) begins");

		List topTransactions = new ArrayList();
		Object[] queryParams = { userId };
		logger.info("SuccessTransactions:::{}", queryParams);
		try {
			 
			topTransactions = (List) getJdbcTemplate().query(EpaySQLConstants.EPAY_USER_LOGIN_HISTORY, new Object[] { userId, userId, userId }
			, new UserLoggedInHistory());
			logger.info("getEpayUserLoginDetails Size#########:{}", topTransactions.size());
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception occured :{}", dataAccessException);
			EpayDaoException.throwException("SUV001");
		} catch (EpayDaoException incorrectResultSizeDataAccessException) {
			logger.error("Exception occured :{}", incorrectResultSizeDataAccessException);
			EpayDaoException.throwException("SUV001");
		}
		logger.debug("getEpayUserLoginDetails(String corpId) begins");
		return topTransactions;
	}
	
	
	private class UserLoggedInHistory implements RowMapper {
		public Object mapRow(ResultSet rs, int arg1) throws SQLException {
			EpayUsersProfile histParams = new EpayUsersProfile();
			histParams.setLoginid(rs.getString("user_id"));
			histParams.setIpaddress ((rs.getString("ip_address")));
			histParams.setMacAddress(rs.getString("phycical_address"));
			histParams.setSessionid(rs.getString("session_id"));
			histParams.setEngineid(rs.getString("engine_id"));
			histParams.setChannelType(rs.getString("channel_type"));
			histParams.setSessionIntime(rs.getString("session_in_time"));
			histParams.setSessionOutTime(rs.getString("session_out_time"));
			histParams.setUserAgent(rs.getString("user_agent"));
			return histParams;
		}
	}

	
	@Override
	public EpayUsersProfile getEpayUserProfileDetails(ModelMap inParams) {
		EpayUsersProfile usersProfilethis = null;
		String userId = (String) inParams.get("userId");
		try {
			String sql = "select * from epay_users_profile where loginid=? " + " or mailid=? or phoneno=?";
			usersProfilethis = this.jdbcTemplate.queryForObject(sql, new Object[] { userId, userId, userId },
					new BeanPropertyRowMapper<EpayUsersProfile>(EpayUsersProfile.class));
		} catch (DataAccessException dataAccessException) {
			logger.error("Exception occured :{}", dataAccessException);
			EpayDaoException.throwException("SUV001");
		} catch (EpayDaoException incorrectResultSizeDataAccessException) {
			logger.error("Exception occured :{}", incorrectResultSizeDataAccessException);
			EpayDaoException.throwException("SUV001");
		}

		// TODO Auto-generated method stub
		return usersProfilethis;
	}

}