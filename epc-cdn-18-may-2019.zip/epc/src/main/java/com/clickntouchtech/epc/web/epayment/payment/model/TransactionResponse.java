/**
 * @(#) TransactionResponse.java
 */
 
package com.clickntouchtech.epc.web.epayment.payment.model;

import java.sql.Timestamp;

public class TransactionResponse implements EpayBaseModel
{
        private String responseReference;
        
        private String statusCode;
        
        private String statusDescription;
        
        private Timestamp responseDate;
        
        private String transactionReferenceNo;
        
        private String errorCode;
         
        public void setResponseReference( String responseReference )
        {
                this.responseReference=responseReference;
        }
        
        public String getResponseReference( )
        {
                return responseReference;
        }
        
        public void setStatusCode( String statusCode )
        {
                this.statusCode=statusCode;
        }
        
        public String getStatusCode( )
        {
                return statusCode;
        }
        
        public void setStatusDescription( String statusDescription )
        {
                this.statusDescription=statusDescription;
        }
        
        public String getStatusDescription( )
        {
                return statusDescription;
        }
        
        public void setResponseDate( Timestamp responseDate )
        {
                this.responseDate=responseDate;
        }
        
        public Timestamp getResponseDate( )
        {
                return responseDate;
        }
        
        public String toString()
        
        {
        	StringBuffer tempStringBuf= new StringBuffer();
        	
        	tempStringBuf.append(responseReference);
        	tempStringBuf.append("|");
        	tempStringBuf.append(statusCode);
        	tempStringBuf.append("|");
        	tempStringBuf.append(statusDescription);
        	tempStringBuf.append("|");
        	tempStringBuf.append(responseDate);
        	tempStringBuf.append("|");
        	
        	return tempStringBuf.toString();
        	
        }

        public void setTransactionReferenceNo(String transactionReferenceNo) {
            this.transactionReferenceNo = transactionReferenceNo;
        }

        public String getTransactionReferenceNo() {
            return transactionReferenceNo;
        }

		public String getErrorCode() {
			return errorCode;
		}

		public void setErrorCode(String errorCode) {
			this.errorCode = errorCode;
		}
        
        
}
