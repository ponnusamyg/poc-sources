package com.clickntouchtech.epc.web.epayreg.service;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.clickntouchtech.epc.web.epayreg.dao.EpayRegistrationDao;
import com.clickntouchtech.epc.web.framework.exception.EpayApplicationException;
import com.clickntouchtech.epc.web.framework.exception.EpayBaseResponse;
import com.clickntouchtech.epc.web.framework.exception.EpayDaoException;
import com.clickntouchtech.epc.web.framework.service.EpayBaseAbsService;
import com.clickntouchtech.epc.web.framework.service.ServiceErrorConstants;
import com.clickntouchtech.epc.web.framework.util.EmailUtils;

@Service
public class EpayPasswordGenService extends EpayBaseAbsService {

	private static final Logger logger = LoggerFactory.getLogger(EpayPasswordGenService.class);

	@Autowired
	private EpayRegistrationDao epayRegistrationDao;

	public ModelMap execute(Map inputParams) {

		logger.info("EpayPasswordGenService execute method begins{}");
		logger.debug("inputparams Map: {}", inputParams);

		ModelMap outParams = new ModelMap();
		Map responseParams = new HashMap();
		Map mailParams = new HashMap();
		EpayBaseResponse response = new EpayBaseResponse();
		response.setErrorStatus(ServiceErrorConstants.FAILURE);
		if (inputParams != null) {
			try {

				int pwdCount = 0;
				String name = (String) inputParams.get("name");
				String emailid = (String) inputParams.get("emailid");
				String mobileno = (String) inputParams.get("mobileno");
				String loginId = (String) inputParams.get("loginId");

				mailParams.put("name", name);
				mailParams.put("emailid", emailid);
				mailParams.put("mobileno", mobileno);
				mailParams.put("loginId", loginId);
				if (pwdCount > 0) {
					String domainUrl=(String) inputParams.get("domainUrl");
					EmailUtils.sendPasswordRestConfirmMail(mailParams,domainUrl);
					response.setErrorStatus(ServiceErrorConstants.SUCCESS);

				} else {
					response.setErrorStatus(ServiceErrorConstants.FAILURE);
					response.setErrorMessage("New Organazation Registration Failed!");
				}
			} catch (EpayApplicationException cmsexp) {
				cmsexp.printStackTrace();
				response.setErrorCode("V101");
			} catch (EpayDaoException daoexp) {
				daoexp.printStackTrace();
				response.setErrorCode("V101");
			}

		}

		outParams.addAttribute(ServiceErrorConstants.APPLICATION_RESPONSE, response);
		logger.debug("outParams Map contains: {}", outParams);
		logger.info("EpayPasswordGenService execute method end{}");
		return outParams;

	}
}