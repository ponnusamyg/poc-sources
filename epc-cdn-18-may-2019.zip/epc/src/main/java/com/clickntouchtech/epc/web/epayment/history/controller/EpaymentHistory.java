package com.clickntouchtech.epc.web.epayment.history.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.clickntouchtech.epc.web.epayment.history.service.EpaymentHistoryService;
import com.clickntouchtech.epc.web.epayment.payment.model.EpayBaseModel;
import com.clickntouchtech.epc.web.epaysecurity.service.EpayUserProfileService;
import com.clickntouchtech.epc.web.framework.util.EpayPageConstants;


@Controller
public class EpaymentHistory implements EpayBaseModel{
	
	private static final Logger logger = LoggerFactory.getLogger(EpaymentHistory.class);
	
	
	@Autowired
	private EpaymentHistoryService epaymentHistoryService;
	
	@Autowired
	private EpayUserProfileService epayUserProfileService;
	
	
    
    @RequestMapping(value = "/epcu/epayuhsitory",method = RequestMethod.GET)
 	public String epayusrdashboard(@RequestHeader(value="User-Agent",required = false) String userAgent,
 			HttpServletRequest request,ModelMap modelMap) {
 		logger.info("epayusrdashboard method begins");
 		ModelMap inParams = new ModelMap();             
     	ModelMap outParams = new ModelMap();
     	String view ="";
//     	HttpSession sessionext = request.getSession(false);
    	inParams.put("userId", getLoggedUser());
    	outParams=epaymentHistoryService.execute(inParams);
    	logger.info("outParams  result :::::::::{}",outParams);
    	modelMap.addAllAttributes(outParams);
    	 
     	view = EpayPageConstants.EPAY_OVER_ALL_PAYMENT_HISTORY_VIEW;
     	/*modelMap.addAttribute("paymentfrom", "ownsite");
     	logger.info("displayHomePage userAgent :::::::::::::::::: {}",userAgent);
     	Device device = DeviceUtils.getCurrentDevice(request);
     	if(device!=null){
     		// to check Device Type .....
        	 String deviceType = EpayPageConstants.EPAY_DEVICETYPE_UNKNOWN;
             if (device.isNormal()) {
                 deviceType = EpayPageConstants.EPAY_DEVICETYPE_DESKTOP;
             } else if (device.isMobile()) {
             	Pattern pattern = Pattern.compile("(wv)");
                 Matcher matcher = pattern.matcher(userAgent);
                 if (matcher.find())
                 deviceType = EpayPageConstants.EPAY_DEVICETYPE_MOBILE+"-"+matcher.group(1);
                 else
                 deviceType = EpayPageConstants.EPAY_DEVICETYPE_MOBILE;

             } else if (device.isTablet()) {
                 deviceType = EpayPageConstants.EPAY_DEVICETYPE_TABLET;
             }
             logger.info("Device Type ::::::{}",deviceType);
             //session.setAttribute("deviceType",deviceType);
     	}*/
 		logger.info("epayusrdashboard method ends");
 		return view;
 	}
    
    public String getLoggedUser() {
    	Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return (!(authentication instanceof AnonymousAuthenticationToken)) ? authentication.getName() : null;
    }
    
}

