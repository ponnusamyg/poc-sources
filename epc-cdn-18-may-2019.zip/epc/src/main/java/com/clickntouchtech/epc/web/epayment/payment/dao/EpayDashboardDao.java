package com.clickntouchtech.epc.web.epayment.payment.dao;

public interface EpayDashboardDao {

	
}