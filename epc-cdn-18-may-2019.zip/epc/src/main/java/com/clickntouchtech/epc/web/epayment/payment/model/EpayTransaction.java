/**
 * @(#) EpayTransaction.java
 */

package com.clickntouchtech.epc.web.epayment.payment.model;

public class EpayTransaction extends Transaction
{
     
    
    
    
}
