package com.clickntouchtech.epc.web.epayment.payment.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.clickntouchtech.epc.web.epayment.payment.model.EpayFormValues;
import com.clickntouchtech.epc.web.epayment.payment.model.EpayModelClassificationData;
import com.clickntouchtech.epc.web.epayment.payment.model.EpayModelOrgData;
import com.clickntouchtech.epc.web.framework.exception.EpayDaoException;
import com.clickntouchtech.epc.web.framework.util.EpaySQLConstants;


@Repository
public class EpayOrgDaoImpl implements EpayOrgDao{

	private static final Logger logger = LoggerFactory.getLogger(EpayOrgDaoImpl.class);
	
    private JdbcTemplate jdbcTemplate;
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.setJdbcTemplate(new JdbcTemplate(dataSource));
	}

	
	private String AMOUNT_VALIDATION="(^(\\d{1,20})(\\.[0-9][0-9])?$)";
	private String TEXT_VALIDATION="(^[0-9a-zA-Z&_. /@-]{1,76}$)";
			
	private String DATE_VALIDATION_DDMMYYY="^([1-9]|[12][0-9]|3[01])[- /.]([1-9]|1[012])[- /.](19|20)\\d\\d$";
	private String DATE_VALIDATION_MMDDYYY="^([1-9]|1[012])[- /.]([1-9]|[12][0-9]|3[01])[- /.](19|20)\\d\\d$";
	
		
	public List getEpayOrgList() throws EpayDaoException {
		logger.debug("getInstitutionsList () begins");
		List orglist = new ArrayList();
		try {
			System.out.println("dbconnection:::::::::::"+getJdbcTemplate().getFetchSize());
			orglist = (List) getJdbcTemplate().queryForList(EpaySQLConstants.ORGLIST);
			logger.info("orglist: {}", orglist.size());
			if (logger.isDebugEnabled())
				logger.debug("orglist: {}", orglist);

		} catch (DataAccessException dataAccessException) {
			dataAccessException.printStackTrace();
			logger.error("Exception occured :{}", dataAccessException);
			EpayDaoException.throwException("SUV001", dataAccessException);
		}
		logger.debug("orglist ends");
		return orglist;
	}
	
	
	
	public List getEpayOrgDetails(String instID) throws EpayDaoException {
		logger.info("retrieveFeePaymentDetails (String instID,String userRole) begins");
		
		List institutionsList= new ArrayList();
		Object[] inparam={instID};
		
		try {
				institutionsList = (List)getJdbcTemplate().query(EpaySQLConstants.SELECT_FEE_PAYMENT_DETAILS,inparam, new OrgDetailsRowMapper());
				
				logger.info("Fee Payment Details List size for the selected category:{}",institutionsList.size());
				
				if(logger.isDebugEnabled())
					logger.debug("Fee Payment Details List for the selected category:{}",institutionsList);
			
		}catch(DataAccessException dataAccessException) {
			logger.error("Exception occured :{}",dataAccessException);
			EpayDaoException.throwException("SUV001", dataAccessException);
		}
		
			logger.info("retrieveFeePaymentDetails (String instID,String userRole) ends");
		
		return institutionsList;	
	}
	
	public List getEpayClassification(String orgid,String orgstate,String orgclassification) throws EpayDaoException {
		logger.info("getEpayClassification begins");
		List orgclassificationList= new ArrayList();
		Object[] inparam={orgid,orgstate};
		try 
		{
			String sql = EpaySQLConstants.ORG_CLASSIFICATION;
			if (orgclassification != null && !orgclassification.isEmpty()) {
				sql = sql.replaceAll("#tobereplaced#", " AND A.classificationId='" + orgclassification + "'");
			} else {
				sql = sql.replaceAll("#tobereplaced#", "");
			}
			orgclassificationList = (List) getJdbcTemplate().query(sql, inparam, new ClassificationRowMapper());

			logger.info("orgclassificationList{}", orgclassificationList.size());

		}catch(DataAccessException dataAccessException) {
				logger.error("Exception occured : {}",dataAccessException);
				EpayDaoException.throwException("SUV001", dataAccessException);
			}
		
			logger.info("retrieveCategories (String instID,String userRole) ends");
			
		return orgclassificationList;
	}
	
	
	private class OrgDetailsRowMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int arg1) throws SQLException {
			EpayModelOrgData organization = new EpayModelOrgData();
			organization.setOrgrootId (rs.getString("orgrootId"));
			organization.setOrganizationname(rs.getString("organizationname"));
			organization.setOrganizationId(rs.getString("organizationId"));		
			organization.setOrganizationrootname(rs.getString("organizationname"));
			organization.setOrgaddress(rs.getString("address"));
			organization.setStatus(rs.getString("approvedstatus"));
			return organization;
		}
	}
	

	private class ClassificationRowMapper implements RowMapper {
		public Object mapRow(ResultSet rs, int arg1) throws SQLException {
			EpayModelClassificationData classification = new EpayModelClassificationData();
			classification.setClassificationId(rs.getString("classificationId"));
			classification.setClassificationName(rs.getString("classificationname"));
			classification.setOrganizationId(rs.getString("organizationId"));
			classification.setClassificationkey(rs.getString("classificationkey"));
			classification.setClassificationmode(rs.getString("classificationmode"));
			classification.setOrgstate(rs.getString("STATE"));
			classification.setClassificKeyValue(rs.getString("classificKeyValue"));
			classification.setOrgName(rs.getString("organizationname"));
			return classification;
		}
	}
	
	
	/**
	 * 
	 * payment details
	 * 
	*/
	
	public Map getClassficationEndDate(String classificationId, String todayDate) {
		if(logger.isDebugEnabled())
			logger.debug("getCatgCutoffTime(String classificationId, String registerNo) begins");
			Map catgLastDateDetails = new HashMap();			
			Map descDetails =  new HashMap();
			
			//Object[] inparam={classificationId,todayDate};   // Lastdate and time issue modification on 22092015 
			
			Object[] inparam={classificationId};
			
				try {
					
					catgLastDateDetails=(Map)getJdbcTemplate().query("select livedate,enddate from epayorgclassification  where classificationId=?",inparam,new iCollectLastDayDetailsExtractor());
					
					//catgLastDateDetails=(Map)getJdbcTemplate().query("select START_DATE,LAST_DATE,CATEGORY_END_TIME from epayorgclassification  where category_id=? and to_char(last_date,'dd-mm-yyyy')=?",inparam,new iCollectLastDayDetailsExtractor());
					
					logger.info("iCollect Last day and cutoff time details :{}", catgLastDateDetails);				
				}
				catch(DataAccessException dataAccessException) {
					logger.error("Exception occured :{}",dataAccessException);
					EpayDaoException.throwException("SUV001");
					//EpayDaoException.throwException("SUV010", dataAccessException);
				}catch(EpayDaoException incorrectResultSizeDataAccessException) {
					logger.error("Exception occured :{}",incorrectResultSizeDataAccessException);
					 //EpayDaoException.throwException("SUV010", incorrectResultSizeDataAccessException);
				}
				if(logger.isDebugEnabled()){
					logger.debug("getCatgCutoffTime(String classificationId, String registerNo) ends");
				}
			
			return catgLastDateDetails;
		}
	
	class iCollectLastDayDetailsExtractor implements ResultSetExtractor{

		public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
			Map result=new HashMap();
			while(rs.next()){
			result.put("START_DATE", rs.getString("livedate"));
			result.put("LAST_DATE", rs.getDate("enddate"));
			//result.put("CATEGORY_END_TIME", rs.getString("CATEGORY_END_TIME"));
			}
			return result;
		}
		
	}
	
	
	public Map getDescriptionData(String classificationId) {
		if(logger.isDebugEnabled())
			logger.debug("getDescriptionDetails(String classificationId, String registerNo) begins");
			Map descDetails =  new HashMap();
			Object[] inparamdesc={classificationId};
			
				try {	
					descDetails = getJdbcTemplate().queryForMap("select ifnull(livedate,SYSDATE()) livedate,classificationname,trim(description1) as description1,trim(description2) as description2,"
							+ "repayment"
							+ " from epayorgclassification WHERE classificationId=?",inparamdesc);
					logger.info("iCollect Description NOTE details :{}", descDetails);				
				}
				catch(DataAccessException dataAccessException) {
					logger.error("Exception occured :{}",dataAccessException);
					EpayDaoException.throwException("SUV001");
					//EpayDaoException.throwException("SUV010", dataAccessException);
				}catch(EpayDaoException incorrectResultSizeDataAccessException) {
					logger.error("Exception occured :{}",incorrectResultSizeDataAccessException);
					 //EpayDaoException.throwException("SUV010", incorrectResultSizeDataAccessException);
				}
				if(logger.isDebugEnabled()){
					logger.debug("getDescriptionDetails(String classificationId, String registerNo) ends");
				}
			
			return descDetails;
		}
	

	
	
	public List getEpayClassificationParams(String classificationId) throws EpayDaoException{
		if(logger.isDebugEnabled())
			logger.debug("retrieveEpaycounterParams(String classificationId) begins");
		List categoryList= new ArrayList();
		Object[] inparam={classificationId};
		
		try {
			
			categoryList = (List)getJdbcTemplate().query(EpaySQLConstants.SELECT_EPC_CATEGORY_PARAMS,inparam, new FieldCtrlTypeRowMapper());
			logger.info("category params(fieldkey values) list size :{}", categoryList.size());
			if(logger.isDebugEnabled())
				logger.debug("category params(fieldkey values) list:{}",categoryList);
			
		}catch(DataAccessException dataAccessException) {
			logger.error("Exception occured :"+dataAccessException);
			EpayDaoException.throwException("SUV001", dataAccessException);
		}
		if(logger.isDebugEnabled())
			logger.debug("retrieveEpaycounterParams(String classificationId) ends");
		
		return categoryList;
	}
	
	class FieldCtrlTypeRowMapper implements RowMapper {
	    public Object mapRow(ResultSet rs, int index) throws SQLException {
	    	
	        EpayFormValues controlType = new EpayFormValues();
	        controlType.setLabel(rs.getString("filedname"));
	        controlType.setControlType(rs.getString("fieldtype"));
	        controlType.setRequestVarname(rs.getString("fieldkey"));
			controlType.setFileMode(rs.getString("classificationmode"));
			controlType.setFieldDesc(rs.getString("fiedldesc"));
	        
	        if("Fixed".equalsIgnoreCase(rs.getString("fieldtype")) || "Variable".equalsIgnoreCase(rs.getString("fieldtype"))|| "Option".equalsIgnoreCase(rs.getString("fieldtype"))){ 
	        	controlType.setFieldSize(new Integer(10));
	        }else{
	        	controlType.setFieldSize(new Integer(30));	
	        }
	        if(rs.getString("MANDATORY")!=null && rs.getString("MANDATORY").equalsIgnoreCase("Y"))        
	        	controlType.setMandatory("0");        
	        else        
	        	controlType.setMandatory("S");
	        
	        String optionValues = rs.getString("OPTION_VALUE");
	        
	        Map controlValues=new LinkedHashMap();
	        if(optionValues!=null){
	            StringTokenizer st = new StringTokenizer(optionValues,",");
	            int i=0;
	            while( st.hasMoreTokens() ) {
	            	controlValues.put("controlValues"+i,st.nextToken());
	            	i++;
	            }
	        }
	        
	        controlType.setControlValues(controlValues);
	        String defaultValue=rs.getString("AMOUNT");
	        String defVal="";
	        if (defaultValue!=null)
	        {    
	            controlType.setDefaultValue(defaultValue);
	        }
	        else
	        {
	            controlType.setDefaultValue(defVal);
	        }
	       
	        if(controlType.getControlType()!=null && 
	        		( controlType.getControlType().equalsIgnoreCase("fixed") || 
	        				controlType.getControlType().equalsIgnoreCase("Variable") ) ) {
	        	
	        	if((controlType.getControlType().equalsIgnoreCase("fixed") && controlType.getMandatory().equalsIgnoreCase("0")) || controlType.getControlType().equalsIgnoreCase("variable"))
	        	{
		        	controlType.setErrorMessage(controlType.getLabel() + " Should be valid amount");
		            controlType.setFormat(AMOUNT_VALIDATION);
	        	}
	        	else if(controlType.getControlType().equalsIgnoreCase("fixed") && !controlType.getMandatory().equalsIgnoreCase("0"))
	        	{
	        		controlType.setErrorMessage(controlType.getLabel() + " should be equal to "+controlType.getDefaultValue()+" or Zero");
	                controlType.setFormat("^(0|"+controlType.getDefaultValue()+")$");
	        	}
	          
	           
	            
	        }else if(controlType.getControlType()!=null && controlType.getControlType().equalsIgnoreCase("text") ) {
	        	
	        	controlType.setErrorMessage(controlType.getLabel() + " Should be valid.");
	            controlType.setFormat(TEXT_VALIDATION);
				controlType.setFieldSize(new Integer(75));
	        }
	        else if(controlType.getControlType()!=null && controlType.getControlType().equalsIgnoreCase("Date")){
	        	if("ddmmyyyy".equalsIgnoreCase(optionValues))
	        	{
	    	    
	        		controlType.setErrorMessage(controlType.getLabel() + " should be a valid date");
	    		 	controlType.setFormat(DATE_VALIDATION_DDMMYYY);
	        	}
	    		else
	    		{
	    			controlType.setErrorMessage(controlType.getLabel() + " should be a valid date");
	        		controlType.setFormat(DATE_VALIDATION_MMDDYYY);
	    		}
	    			
	    		
	    	}
	        /*else if(controlType.getControlType()!=null && controlType.getControlType().equalsIgnoreCase("date"))
	        {
	        	controlType.setErrorMessage(controlType.getLabel() + " should be a valid date");
	    		controlType.setFormat(optionValues);
	        }*/
	        else if(controlType.getControlType()!=null /*&& "S".equals(controlType.getMandatory())*/&& controlType.getControlType().equalsIgnoreCase("natext") ){
	        	logger.info("test natext");
	        		String nonFileModeParamType=rs.getString("DESCRIPTION");
	        		controlType.setFormat(AMOUNT_VALIDATION);
	        		controlType.setErrorMessage(controlType.getLabel() + " Should be valid amount");
	        		if(nonFileModeParamType !=null && "PARAMETER".equals(nonFileModeParamType)){
	        			controlType.setFormat(TEXT_VALIDATION);
	        			controlType.setErrorMessage(controlType.getLabel() + " Should be valid.");
	        		}
	        }
	        return controlType;
	    }
	  }
	
	
	public List getClassificationParams(String categoryID) throws EpayDaoException{
		if(logger.isDebugEnabled())
		logger.debug("retrieveCategoryParams(String categoryID) begins");
		List categoryList= new ArrayList();
		Object[] inparam={categoryID};
		
			try {
			
			categoryList = (List)getJdbcTemplate().query(EpaySQLConstants.SELECT_CATEGORY_PARAMS,inparam, new FieldCtrlTypeRowMapper());
			logger.info("category params(fieldkey values) list size :{}", categoryList.size());
			if(logger.isDebugEnabled())
				logger.debug("category params(fieldkey values) list:{}",categoryList);
			
			}catch(DataAccessException dataAccessException) {
				logger.error("Exception occured :{}",dataAccessException);
				 EpayDaoException.throwException("SUV001", dataAccessException);
			}
			if(logger.isDebugEnabled())
				logger.debug("retrieveCategoryParams(String categoryID) ends");
		
		return categoryList;
	}
	
	
	 public Map  getEpaymentServiceCharge(String orgid)
	 {
		 if(logger.isDebugEnabled())
			 logger.debug("getServiceChargeDetails( String instituteId ) method begin");
		        Map serviceChargeMap=null;
		        
		        if (orgid != null)
		        {                
		            try
		            {	            	
		                Object params[]={orgid};               
		                serviceChargeMap = getJdbcTemplate().queryForMap(EpaySQLConstants.GET_COMM_DETAILS,params);
		                
		                logger.info("serviceChargeMap size:{}",serviceChargeMap.size());
		                
		                if(logger.isDebugEnabled())
		                	logger.debug("serviceChargeMap:{}",serviceChargeMap);
		            
		        	}catch (DataAccessException dataAccessException) {
					logger.error("Exception occured :{}", dataAccessException);
					EpayDaoException.throwException("SUV001");
		        	}      
		        }
		        else
					EpayDaoException.throwException("SUV002");
		            
		        if(logger.isDebugEnabled())
		        logger.debug("getServiceChargeDetails( String instituteId ) method ends");
		        return serviceChargeMap; 
	 }
	 
	public List fileTxnClassifications(String classificationId) {
		logger.debug("fileTxnClassifications(String categoryID) begins");
		List classificationList = new ArrayList();
		Object[] inparam = { classificationId };

		try {
			classificationList = (List) getJdbcTemplate().query(EpaySQLConstants.GET_FILETXN_CLASSIFICATIONS, inparam,new FieldCtrlTypeRowMapper());
			logger.info("classificationList size :{}", classificationList.size());

		} catch (DataAccessException dataAccessException) {
			logger.error("Exception occured :{}", dataAccessException);
			EpayDaoException.throwException("SUV001");
		}

		return classificationList;
	}
	
	public Map fileTxnClassificationFields(String classificationId, String uniqueRefNo) {
		if (logger.isDebugEnabled())
			logger.debug("fileTxnClassificationFields begins");
		String records = "";
		Map dataRrcords = new HashMap();
		Object[] inparam = { classificationId, uniqueRefNo };
		try {
			String sql = "select distinct fieldData from epaydatafieldkey A,epayorgclassification B where A.classificationId=B.classificationId and"
					+ " b.classificationId=?  and fieldkey=?";
			dataRrcords = getJdbcTemplate().queryForMap(sql, inparam);
			logger.info("Records in epaydatafieldkey:{}" + dataRrcords);

		} catch (DataAccessException dataAccessException) {
			logger.error("Exception occured :{}", dataAccessException);
			EpayDaoException.throwException("SUV001");
		}
		return dataRrcords;
	}
	 
}
