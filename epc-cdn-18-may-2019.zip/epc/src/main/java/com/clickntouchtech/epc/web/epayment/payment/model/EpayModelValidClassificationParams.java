package com.clickntouchtech.epc.web.epayment.payment.model;

public class EpayModelValidClassificationParams implements EpayBaseModel{
	private String paramId;
	private String paramName;
	private String Description;
	private String paramType;
	private String optionValue;
	private String amount;
	private String outRef;
	
	public String getParamId() {
		return paramId;
	}
	public void setParamId(String paramId) {
		this.paramId = paramId;
	}
	public String getParamName() {
		return paramName;
	}
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public String getParamType() {
		return paramType;
	}
	public void setParamType(String paramType) {
		this.paramType = paramType;
	}
	public String getOptionValue() {
		return optionValue;
	}
	public void setOptionValue(String optionValue) {
		this.optionValue = optionValue;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getOutRef() {
		return outRef;
	}
	public void setOutRef(String outRef) {
		this.outRef = outRef;
	}
	
	

}
