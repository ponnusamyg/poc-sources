package com.clickntouchtech.epc.web.epayment.payment.service;

import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.clickntouchtech.epc.web.epayment.payment.dao.EPaymentDao;
import com.clickntouchtech.epc.web.epayment.payment.dao.EpayTransactionDAO;
import com.clickntouchtech.epc.web.framework.exception.EpayApplicationException;
import com.clickntouchtech.epc.web.framework.exception.EpayBaseResponse;
import com.clickntouchtech.epc.web.framework.exception.EpayDaoException;
import com.clickntouchtech.epc.web.framework.service.EpayBaseAbsService;
import com.clickntouchtech.epc.web.framework.service.ServiceErrorConstants;

@Service
public class EpayAcknowledgementService extends EpayBaseAbsService {
	
private static final Logger logger = LoggerFactory.getLogger(EpayAcknowledgementService.class);
	
	@Autowired
	private EPaymentDao ePaymentDao;
	
	@Autowired
	private EpayTransactionDAO epayTransactionDAO;
	

	public ModelMap epayServiceBase(Map inputParams) {
		
		logger.info("EpayAcknowledgementService execute method begins");
		if (logger.isDebugEnabled())
			logger.debug("inputparams Map: {}", inputParams);

		EpayBaseResponse response = new EpayBaseResponse();
		response.setErrorStatus(ServiceErrorConstants.FAILURE);

		ModelMap outParams = new ModelMap();
		
		String epayrefno = (String) inputParams.get("epayrefno");
		String gatewayrefno = (String) inputParams.get("gatewayrefno");
		String epaymentstatus  = (String) inputParams.get("epaymentstatus");
		String statusDescription  = (String) inputParams.get("epaymentstatusdesc");
		String sessionId = (String) inputParams.get("resSessionId");
		String serverName = (String) inputParams.get("resServerName");
		String resIPAddress = (String) inputParams.get("resIPAddress");
		String txnrefno  = (String) inputParams.get("txnrefno");
		
		
		try {
		        	if("0".equalsIgnoreCase(epaymentstatus)||"s".equalsIgnoreCase(epaymentstatus)){
		        		epaymentstatus = "Payment Success";
		        		statusDescription = "ePayment Transaction Completed";
					}
		        	epayTransactionDAO.updateEpayTransStatus(epayrefno,gatewayrefno,epaymentstatus,txnrefno,statusDescription);
		        	try
		        	{
		        		ePaymentDao.updateLoginResponseTime(epayrefno, sessionId, serverName,epaymentstatus,statusDescription,resIPAddress);
		        	}catch(Exception e){
		        		logger.info("Exception in :{}",e.getMessage());
		        	}
		        	Map epayPaymentsTransactions = ePaymentDao.getEpayTransData(epayrefno);
		        	Map addParams = ePaymentDao.getEpaymentParams(epayrefno);
		        	String categoryId="";
		            categoryId=(String)addParams.get("fieldkey6");                	
		            String paramString = (String) addParams.get("fieldkey9");
		            String[] params = paramString.split("~");
		            String amtString = (String) addParams.get("fieldkey10");
		            String[] amountParams = amtString.split("~");
		            String classificationName = (String)addParams.get("fieldkey7");
		            
		            Map epayuserpaymentsrefkey = new LinkedHashMap();  // Added on 01-04-14
		            Map classifications	=	new LinkedHashMap();
		            
		            for(int i=1;i<params.length;i+=2){
		            	String paramName = params[i];
		            	epayuserpaymentsrefkey.put(paramName,params[i+1]);
		            }
		           	for(int i=1;i<amountParams.length;i+=2){
		           		String paramName = amountParams[i];
		           		classifications.put(paramName,amountParams[i+1]);
		            }
		           	
		            logger.info("category Param values ::{} , classifications :: {}", epayuserpaymentsrefkey, classifications);
		            logger.info("epayPaymentsTransactions ::{}", epayPaymentsTransactions);
		            outParams.put("epayPaymentsTransactions",epayPaymentsTransactions);
		            outParams.put("txnStatus",epaymentstatus);
		            outParams.put("addParams",addParams);
		            outParams.put("epayuserpaymentsrefkeys",epayuserpaymentsrefkey);
		            outParams.put("classifications",classifications);
		            outParams.put("epayrefno", epayrefno);
		            outParams.put("classificationName", classificationName);
		            response.setErrorStatus(ServiceErrorConstants.SUCCESS);
			
		} catch(EpayApplicationException cmsexp) {
        	cmsexp.printStackTrace();
        	response.setErrorCode("V101");
		} catch (EpayDaoException daoexp) {
			daoexp.printStackTrace();
			response.setErrorCode("V101");
		}
		
		
		
		outParams.addAttribute(ServiceErrorConstants.APPLICATION_RESPONSE, response);
		
		if (logger.isDebugEnabled())
			logger.debug("outParams Map contains: {}",outParams);
		
		logger.info("EpayAcknowledgementService execute method end");
		
		return outParams;
		
	}

}
