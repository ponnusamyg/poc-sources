package com.clickntouchtech.epc.web.framework.interceptor;

import java.io.IOException;
import java.util.Date;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

public class EpayMdcFilter implements Filter{
	private static final Logger logger = LoggerFactory.getLogger(EpayMdcFilter.class);
	
	  @Override
      public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
      try {
    	  HttpServletRequest servletRequest = (HttpServletRequest) request;
    	  HttpSession session = servletRequest.getSession(false);
    	  if(session!=null){
    		  logger.info("doFilter:session id to put MDC");
    		  MDC.put("sessionId", session.getId());
    		  String reqtUserid=(String)session.getAttribute("reqtUserid");
    		  if(reqtUserid!=null){
    			  MDC.put("userid", reqtUserid);
    		  }
    		 
   	  } 
    	  HttpServletResponse resp = (HttpServletResponse) response;
          resp.setHeader("Expires", "Tue, 03 Jul 2001 06:00:00 GMT");
          resp.setHeader("Last-Modified", new Date().toString());
          resp.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0, post-check=0, pre-check=0");
          resp.setHeader("Pragma", "no-cache");
          chain.doFilter(new SecurityHttpRequestWrapper(servletRequest), response);
      } finally {
    	  logger.info("doFilter:session id to remove from  MDC");
          MDC.clear();
      }
  }

	@Override
	public void destroy() {
		  logger.info("destroy:session id to remove from  MDC");
          MDC.clear();
		// TODO Auto-generated method stub
		
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		  logger.info("init:session id to remove from  MDC");
          MDC.clear();
		// TODO Auto-generated method stub
		
	}

}
