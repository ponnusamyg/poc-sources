package com.clickntouchtech.epc.web.epayment.payment.dao;

import java.util.Map;

public interface EpayServiceChargesDAO {

	public  Map  getServiceChargeOrg(String bankCode, String merchantCode,String corpID,double debitAmount) ;
	
}
