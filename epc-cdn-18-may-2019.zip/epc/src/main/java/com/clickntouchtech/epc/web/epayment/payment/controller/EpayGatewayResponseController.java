package com.clickntouchtech.epc.web.epayment.payment.controller;


import java.security.MessageDigest;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.clickntouchtech.epc.web.epayment.payment.service.EpayAcknowledgementService;
import com.clickntouchtech.epc.web.framework.exception.EpayBaseResponse;


@Controller
public class EpayGatewayResponseController {
	
	private static final Logger logger = LoggerFactory.getLogger(EpayGatewayResponseController.class);
	


	
	@Autowired
	private EpayAcknowledgementService epayAcknowledgementService;
	
	@Autowired
	private ServletContext context;
	
	


    
	
    @RequestMapping(value="/gwrpu/epaymentsresponse",method = RequestMethod.POST)
	public String ePaymentGatewayResponse(HttpServletRequest request, HttpServletResponse response,ModelMap modelMap,RedirectAttributes redirectAttrs) {
		
		logger.info("epaymentsresponse method");
		 Enumeration paramNames = request.getParameterNames();
	        Map<String, String> params = new HashMap<String, String>();
	        Map<String, String> urlParams = new HashMap<String, String>();
	        while (paramNames.hasMoreElements()) {
	            String paramName = (String) paramNames.nextElement();
	            String paramValue = request.getParameter(paramName);
	            params.put(paramName, paramValue);
	            logger.info("paramName:::::::::"+paramName);
	            logger.info("paramValue::::::::"+paramValue);
	        }
		
		Map txnParams = new HashMap();
		String epayrefno = "";
		String gatewayrefno="";
		String status = "";
		String statusCodeStr = "";
		String txnrefno="";
		
		Map inParams = new HashMap();
		Map outParams = new HashMap();
		String statusCode = (String)request.getParameter("status");
		gatewayrefno = (String)request.getParameter("payuMoneyId");
		epayrefno = (String)request.getParameter("udf1");
		logger.info("Status Code ::: {}",statusCode);
		status = (String)request.getParameter("status");
		txnrefno = (String)request.getParameter("mihpayid");
		
		String viewName = "";
		
		if(statusCode!=null && statusCode.equals("success")){
        	status = "Payment Success";
        	statusCode = "success";
        	viewName = "epaymentssuccessview";
		}else{
        	status = "Payment Failure";
        	statusCodeStr = "error";
        	viewName = "epaymentsfailureview";
		}
		

        String serverName = (String) context.getAttribute("com.ibm.websphere.servlet.application.host");
        
        String resIPAddress = request.getHeader("ClientIP");
		if(resIPAddress == null){
			resIPAddress = request.getRemoteAddr();
		}
		inParams.put("resSessionId", getSessionId(request));
		inParams.put("resServerName", serverName);
		inParams.put("resIPAddress", resIPAddress);
		String registerNo = (String)request.getParameter("txnid");
        if(epayrefno != null && epayrefno.startsWith("EPC")) {
    		inParams.put("epayrefno",epayrefno);
    		inParams.put("gatewayrefno",gatewayrefno);
    		inParams.put("epaymentstatus",statusCode);
    		inParams.put("epaymentstatusdesc", status);
    		inParams.put("txnrefno", txnrefno);
    		inParams.put("registerNo", registerNo);
        	outParams =  epayAcknowledgementService.epayServiceBase(inParams);
        	outParams.put("viewname", viewName);
        	redirectAttrs.addFlashAttribute("outParams", outParams);
        } else	{
        	EpayBaseResponse errorResponse =  new EpayBaseResponse();
        	errorResponse.setErrorStatus("failure");
    		errorResponse.setErrorCode("SE200");
    		outParams.put("applicationResponse", errorResponse);
        }
        
		logger.info("Payment response gmethod");
		return "redirect:/gwrpu/epaymentstatus";
	}
	
    
    //redirected billdesk handler
    @RequestMapping(value = "/gwrpu/epaymentstatus", method = RequestMethod.GET)
    public String redirectEpaymentResponse(HttpServletRequest request, ModelMap modelMap){
    	 logger.info("redirectEpaymentResponse begin");
    	 Map<String, ?> inputFlashMap = RequestContextUtils.getInputFlashMap(request);
    	 
    	    // A RedirectAttributes model is empty when the method is called and is
    	    // never used unless the method returns a redirect view name or a
    	    // RedirectView.
    	 	String viewname = "sessiontimeout";
    	 	Map outParams = new HashMap();
    	 	
    	    if (inputFlashMap != null) {
    	    	Date date = new Date();
    	    	SimpleDateFormat ts = new SimpleDateFormat("dd/MM/yyyy:hh:mm");
    	        Date sqlToday = null;
    			try {
    				sqlToday = new java.sql.Date(ts.parse(ts.format(date)).getTime());
    			} catch (ParseException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
    			
    	        Timestamp timestamp = new Timestamp(sqlToday.getTime());
    	    	outParams = (Map) inputFlashMap.get("outParams");
    	    	 outParams.put("txntime", timestamp);
    	    	viewname = (String) outParams.get("viewname");
    	    	logger.info("viewname - {}", viewname);
    	    	modelMap.addAllAttributes(outParams);
    			
    	    }else{
    	    	logger.info("viewname - {}", viewname);
    	    	return "redirect:/sessiontimeout";
    	    }
    	    logger.info("redirectEpaymentResponse end");
        return viewname;
    }
    
	
	public double roundTotalAmount(double totalAmount) {
		double roundOff=0.0;
		roundOff=Math.round(totalAmount*100.0)/100.0;
		return roundOff;
	}
	
	public  String checkSumSHA256(String plaintext,String bankCode)  {
		
		
		String commonstr="";
		if("0".equalsIgnoreCase(bankCode))
		{
		commonstr="LHo08QMmHrC0";
		}
		if("1".equalsIgnoreCase(bankCode))
		{
		commonstr="YhGKsbL6Mzky";
		}
		if("2".equalsIgnoreCase(bankCode))
		{
		commonstr="YWAk5pF1dA3U";
		}
		if("4".equalsIgnoreCase(bankCode))
		{
		commonstr="zxZ4erR0uhw3";
		}
		if("5".equalsIgnoreCase(bankCode))
		{
		commonstr="xqUUW6WSuPKA";
		}
		if("7".equalsIgnoreCase(bankCode))
		{
		commonstr="LHo08QMmAuN9";
		}
		plaintext = plaintext +"|"+commonstr;
		
		MessageDigest md = null;
		try {
			md = MessageDigest.getInstance("SHA-256"); //step 2
			md.update(plaintext.getBytes("UTF-8")); //step 3
		} catch (Exception e) {
			md=null;
		}

		StringBuffer ls_sb=new StringBuffer();
		byte raw[] = md.digest(); //step 4
		for(int i=0;i<raw.length;i++)
			ls_sb.append(char2hex(raw[i]));
		return ls_sb.toString(); //step 6
		}
	public  String char2hex(byte x)
	{
		char arr[]={

				'0','1','2','3',
				'4','5','6','7',
				'8','9','A','B',
				'C','D','E','F'
		};

	char c[] = {arr[(x & 0xF0)>>4],arr[x & 0x0F]};
	return (new String(c));
    }
	
	private String getSessionId(HttpServletRequest request)
	{
		HttpSession sesion = request.getSession(false);
		if(sesion!=null){
			return sesion.getId();
		}
		else
			return null;
	}
}
