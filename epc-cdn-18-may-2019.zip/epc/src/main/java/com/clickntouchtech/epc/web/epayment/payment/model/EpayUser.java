/** 
 * @(#) User.java 
 */
  
package com.clickntouchtech.epc.web.epayment.payment.model;

import java.util.List;
import java.util.Map;
import java.io.Serializable;

public class EpayUser implements EpayBaseModel,Serializable
{
	
	private String bankCode;
    private String kioskID; // Added for KiosK - CR 2914 
    private String userAlias;
    private String corporateId;
    private String userIPaddress;
    private String userState;
    private Integer userType;
    private List userRole;
    private Map<String,Object> userCache;
    private String channelType;
    
    public String toString()  {
    	StringBuffer tempStringBuf= new StringBuffer();
    	
    	tempStringBuf.append("|");
    	tempStringBuf.append("userAlias :");
    	tempStringBuf.append(userAlias);
    	tempStringBuf.append("|");
    	tempStringBuf.append("userState :");
    	tempStringBuf.append(userState);
    	tempStringBuf.append("|");
    	tempStringBuf.append("userType :");
        tempStringBuf.append(userType);
        tempStringBuf.append("|");
        tempStringBuf.append("userCache:");
        tempStringBuf.append(userCache);
        tempStringBuf.append("|");
        tempStringBuf.append("channelType:");
        tempStringBuf.append(channelType);
        return tempStringBuf.toString();
    }
    
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public String getKioskID() {
		return kioskID;
	}
	public void setKioskID(String kioskID) {
		this.kioskID = kioskID;
	}
	public String getUserAlias() {
		return userAlias;
	}
	public void setUserAlias(String userAlias) {
		this.userAlias = userAlias;
	}
	public String getCorporateId() {
		return corporateId;
	}
	public void setCorporateId(String corporateId) {
		this.corporateId = corporateId;
	}
	public String getUserIPaddress() {
		return userIPaddress;
	}
	public void setUserIPaddress(String userIPaddress) {
		this.userIPaddress = userIPaddress;
	}
	public String getUserState() {
		return userState;
	}
	public void setUserState(String userState) {
		this.userState = userState;
	}
	public Integer getUserType() {
		return userType;
	}
	public void setUserType(Integer userType) {
		this.userType = userType;
	}
	public List getUserRole() {
		return userRole;
	}
	public void setUserRole(List userroles) {
		this.userRole = userroles;
	}
	public Map<String, Object> getUserCache() {
		return userCache;
	}
	public void setUserCache(Map<String, Object> userCache) {
		this.userCache = userCache;
	}

	public String getChannelType() {
		return channelType;
	}

	public void setChannelType(String channelType) {
		this.channelType = channelType;
	} 
                   
}  
