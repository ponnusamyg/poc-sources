package com.clickntouchtech.epc.web.epaysecurity.bean;

import java.io.Serializable;

public class EpayUsersProfile implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String name;
	private String loginid;
	private String instituteid;
	private String mailid;
	private String phoneNo;
	private String countrycode;
	private String address;
	private String state;
	private String district;
	private String pincode;
	private String aadharcode;
	private String userrole;
	private String userstatus;
	private String dateofbirth;

	private String ipaddress;
	private String macAddress;
	private String sessionid;

	private String engineid;
	private String channelType;
	private String loginTime;

	private String sessionIntime;
	private String sessionOutTime;
	private String userAgent;
	private String pinCode;

	private String organizationId;
	private String organizationname;
	private String orgtype;
	private String orgsubtype;
	private String phoneno;
	private String emailid;
	private String prooftype;
	private String proofvalue;
	private String verificationstatus;
	private String verificationstatusdesc;
	
	private String emailStatus;
	private String mobilNoStatus;
	/**
	 * @return the organizationId
	 */
	public String getOrganizationId() {
		return organizationId;
	}

	/**
	 * @param organizationId the organizationId to set
	 */
	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}

	/**
	 * @return the organizationname
	 */
	public String getOrganizationname() {
		return organizationname;
	}

	/**
	 * @param organizationname the organizationname to set
	 */
	public void setOrganizationname(String organizationname) {
		this.organizationname = organizationname;
	}

	/**
	 * @return the orgtype
	 */
	public String getOrgtype() {
		return orgtype;
	}

	/**
	 * @param orgtype the orgtype to set
	 */
	public void setOrgtype(String orgtype) {
		this.orgtype = orgtype;
	}

	/**
	 * @return the orgsubtype
	 */
	public String getOrgsubtype() {
		return orgsubtype;
	}

	/**
	 * @param orgsubtype the orgsubtype to set
	 */
	public void setOrgsubtype(String orgsubtype) {
		this.orgsubtype = orgsubtype;
	}

	/**
	 * @return the phoneno
	 */
	public String getPhoneno() {
		return phoneno;
	}

	/**
	 * @param phoneno the phoneno to set
	 */
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}

	/**
	 * @return the emailid
	 */
	public String getEmailid() {
		return emailid;
	}

	/**
	 * @param emailid the emailid to set
	 */
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	/**
	 * @return the prooftype
	 */
	public String getProoftype() {
		return prooftype;
	}

	/**
	 * @param prooftype the prooftype to set
	 */
	public void setProoftype(String prooftype) {
		this.prooftype = prooftype;
	}

	/**
	 * @return the proofvalue
	 */
	public String getProofvalue() {
		return proofvalue;
	}

	/**
	 * @param proofvalue the proofvalue to set
	 */
	public void setProofvalue(String proofvalue) {
		this.proofvalue = proofvalue;
	}

	/**
	 * @return the verificationstatus
	 */
	public String getVerificationstatus() {
		return verificationstatus;
	}

	/**
	 * @param verificationstatus the verificationstatus to set
	 */
	public void setVerificationstatus(String verificationstatus) {
		this.verificationstatus = verificationstatus;
	}

	/**
	 * @return the verificationstatusdesc
	 */
	public String getVerificationstatusdesc() {
		return verificationstatusdesc;
	}

	/**
	 * @param verificationstatusdesc the verificationstatusdesc to set
	 */
	public void setVerificationstatusdesc(String verificationstatusdesc) {
		this.verificationstatusdesc = verificationstatusdesc;
	}

	

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the loginid
	 */
	public String getLoginid() {
		return loginid;
	}

	/**
	 * @param loginid
	 *            the loginid to set
	 */
	public void setLoginid(String loginid) {
		this.loginid = loginid;
	}

	/**
	 * @return the instituteid
	 */
	public String getInstituteid() {
		return instituteid;
	}

	/**
	 * @param instituteid
	 *            the instituteid to set
	 */
	public void setInstituteid(String instituteid) {
		this.instituteid = instituteid;
	}

	/**
	 * @return the mailid
	 */
	public String getMailid() {
		return mailid;
	}

	/**
	 * @param mailid
	 *            the mailid to set
	 */
	public void setMailid(String mailid) {
		this.mailid = mailid;
	}

	/**
	 * @return the countrycode
	 */
	public String getCountrycode() {
		return countrycode;
	}

	/**
	 * @param countrycode
	 *            the countrycode to set
	 */
	public void setCountrycode(String countrycode) {
		this.countrycode = countrycode;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address
	 *            the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state
	 *            the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the district
	 */
	public String getDistrict() {
		return district;
	}

	/**
	 * @param district
	 *            the district to set
	 */
	public void setDistrict(String district) {
		this.district = district;
	}

	/**
	 * @return the pincode
	 */
	public String getPincode() {
		return pincode;
	}

	/**
	 * @param pincode
	 *            the pincode to set
	 */
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	/**
	 * @return the aadharcode
	 */
	public String getAadharcode() {
		return aadharcode;
	}

	/**
	 * @param aadharcode
	 *            the aadharcode to set
	 */
	public void setAadharcode(String aadharcode) {
		this.aadharcode = aadharcode;
	}

	/**
	 * @return the userrole
	 */
	public String getUserrole() {
		return userrole;
	}

	/**
	 * @param userrole
	 *            the userrole to set
	 */
	public void setUserrole(String userrole) {
		this.userrole = userrole;
	}

	/**
	 * @return the userstatus
	 */
	public String getUserstatus() {
		return userstatus;
	}

	/**
	 * @param userstatus
	 *            the userstatus to set
	 */
	public void setUserstatus(String userstatus) {
		this.userstatus = userstatus;
	}

	/**
	 * @return the dateofbirth
	 */
	public String getDateofbirth() {
		return dateofbirth;
	}

	/**
	 * @param dateofbirth
	 *            the dateofbirth to set
	 */
	public void setDateofbirth(String dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	/**
	 * @return the ipaddress
	 */
	public String getIpaddress() {
		return ipaddress;
	}

	/**
	 * @param ipaddress
	 *            the ipaddress to set
	 */
	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}

	/**
	 * @return the macAddress
	 */
	public String getMacAddress() {
		return macAddress;
	}

	/**
	 * @return the pinCode
	 */
	public String getPinCode() {
		return pinCode;
	}

	/**
	 * @param pinCode
	 *            the pinCode to set
	 */
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	/**
	 * @param macAddress
	 *            the macAddress to set
	 */
	public void setMacAddress(String macAddress) {
		this.macAddress = macAddress;
	}

	/**
	 * @return the sessionid
	 */
	public String getSessionid() {
		return sessionid;
	}

	/**
	 * @param sessionid
	 *            the sessionid to set
	 */
	public void setSessionid(String sessionid) {
		this.sessionid = sessionid;
	}

	/**
	 * @return the engineid
	 */
	public String getEngineid() {
		return engineid;
	}

	/**
	 * @param engineid
	 *            the engineid to set
	 */
	public void setEngineid(String engineid) {
		this.engineid = engineid;
	}

	/**
	 * @return the channelType
	 */
	public String getChannelType() {
		return channelType;
	}

	/**
	 * @param channelType
	 *            the channelType to set
	 */
	public void setChannelType(String channelType) {
		this.channelType = channelType;
	}

	/**
	 * @return the loginTime
	 */
	public String getLoginTime() {
		return loginTime;
	}

	/**
	 * @param loginTime
	 *            the loginTime to set
	 */
	public void setLoginTime(String loginTime) {
		this.loginTime = loginTime;
	}

	/**
	 * @return the sessionIntime
	 */
	public String getSessionIntime() {
		return sessionIntime;
	}

	/**
	 * @param sessionIntime
	 *            the sessionIntime to set
	 */
	public void setSessionIntime(String sessionIntime) {
		this.sessionIntime = sessionIntime;
	}

	/**
	 * @return the sessionOutTime
	 */
	public String getSessionOutTime() {
		return sessionOutTime;
	}

	/**
	 * @param sessionOutTime
	 *            the sessionOutTime to set
	 */
	public void setSessionOutTime(String sessionOutTime) {
		this.sessionOutTime = sessionOutTime;
	}

	/**
	 * @return the userAgent
	 */
	public String getUserAgent() {
		return userAgent;
	}

	/**
	 * @param userAgent
	 *            the userAgent to set
	 */
	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}

	/**
	 * @return the phoneNo
	 */
	public String getPhoneNo() {
		return phoneNo;
	}

	/**
	 * @param phoneNo
	 *            the phoneNo to set
	 */
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	/**
	 * @return the mobilNoStatus
	 */
	public String getMobilNoStatus() {
		return mobilNoStatus;
	}

	/**
	 * @param mobilNoStatus the mobilNoStatus to set
	 */
	public void setMobilNoStatus(String mobilNoStatus) {
		this.mobilNoStatus = mobilNoStatus;
	}

	/**
	 * @return the emailStatus
	 */
	public String getEmailStatus() {
		return emailStatus;
	}

	/**
	 * @param emailStatus the emailStatus to set
	 */
	public void setEmailStatus(String emailStatus) {
		this.emailStatus = emailStatus;
	}

}
