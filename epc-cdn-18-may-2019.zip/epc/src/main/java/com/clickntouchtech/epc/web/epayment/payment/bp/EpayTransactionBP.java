package com.clickntouchtech.epc.web.epayment.payment.bp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.clickntouchtech.epc.web.epayment.payment.dao.EpayTransactionDAO;
import com.clickntouchtech.epc.web.epayment.payment.model.EpayModelParams;
import com.clickntouchtech.epc.web.epayment.payment.model.Transaction;
import com.clickntouchtech.epc.web.framework.exception.EpayApplicationException;
import com.clickntouchtech.epc.web.framework.exception.EpayDaoException;
import com.clickntouchtech.epc.web.framework.util.ErrorConstants;

@Service
public class EpayTransactionBP {
	
	protected final Logger logger = LoggerFactory.getLogger(EpayTransactionBP.class);
	
	@Autowired
	private EpayTransactionDAO epayTransDAOImpl;
	
	public Transaction postTransaction(Transaction transaction, EpayModelParams epayModelParams) throws EpayApplicationException {
        if (transaction != null){
            logger.info("postTransaction(Transaction transaction) Begin transaction : {}", transaction.toString());
            String userName=transaction.getDebit().getUserName();
            logger.info("userName::{}",userName);
            String branchCode=transaction.getDebit().getBranchCode();
            String bankCode="";
            if(branchCode!=null) {
            	bankCode=branchCode.substring(0,1);
            }
            String referenceNo =  postTransactionToDB(transaction,epayModelParams);
            logger.info("referenceNo : {}", referenceNo);
            transaction.getDebit().setReferenceNo(referenceNo);
            
        } else {
        	EpayApplicationException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
        }
        
        return transaction;
    }
	private String postTransactionToDB(Transaction transaction, EpayModelParams epayModelParams)
    {
        String refNo=null;
        logger.info("postTransactionToDB(Transaction transaction) Begin transaction :{}", transaction);
    	try
        {
            refNo = epayTransDAOImpl.getEpayTransaction(transaction,epayModelParams);
            logger.info("postTransactionToDB(Transaction transaction) Ends -> refNo :{}",refNo);
            
        } catch (EpayDaoException daoException)  {
        	EpayApplicationException.throwException(daoException.getMessage(),daoException);
        }
    	
        return refNo;
    }
	

}
