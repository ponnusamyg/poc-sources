package com.clickntouchtech.epc.web.epayment.history.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.clickntouchtech.epc.web.epayment.history.model.EpaymentHistoryParams;
import com.clickntouchtech.epc.web.framework.exception.EpayDaoException;
import com.clickntouchtech.epc.web.framework.util.EpaySQLConstants;


@Repository
public class EpaymentHistoryDaoImpl implements EpaymentHistoryDao {
    
	private static final Logger logger = LoggerFactory.getLogger(EpaymentHistoryDaoImpl.class);
	
private JdbcTemplate jdbcTemplate;
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}


	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.setJdbcTemplate(new JdbcTemplate(dataSource));
	}
    
    public List getOverAllPaymentHistory(String userId) {
    	logger.debug("getOverAllPaymentHistory(String userId) begins");
    	
		List epayOverallPaymentHistroy = new ArrayList();
		Object[] queryParams={userId};
    	logger.info("Params:::{}",queryParams);
			try {	
//				epayOverallPaymentHistroy = jdbcTemplate.queryForList(EpaySQLConstants.EPAY_OVERALL_PAYMENT_HISTROY, queryParams,new OverAllPaymentHistoryRowMapper());
				
				epayOverallPaymentHistroy = (List)getJdbcTemplate().query(EpaySQLConstants.EPAY_OVERALL_PAYMENT_HISTROY,queryParams, new OverAllPaymentHistoryRowMapper());
				
				logger.info("EPAY_OVERALL_PAYMENT_HISTROY:{}",epayOverallPaymentHistroy);	
			}
			catch(DataAccessException dataAccessException) {
				logger.error("Exception occured :{}",dataAccessException);
				EpayDaoException.throwException("SUV001");
			}catch(EpayDaoException incorrectResultSizeDataAccessException) {
				logger.error("Exception occured :{}",incorrectResultSizeDataAccessException);
				EpayDaoException.throwException("SUV001");
			}
			
			logger.debug("getOverAllPaymentHistory(String corpId) begins");
			
		return epayOverallPaymentHistroy;
    }
 

private class OverAllPaymentHistoryRowMapper implements RowMapper {
		
		
		public Object mapRow(ResultSet rs, int arg1) throws SQLException {
			
			EpaymentHistoryParams histParams = new EpaymentHistoryParams();
			
			histParams.setRefenceNo(rs.getString("epayrefno"));
			histParams.setTotalAmount(Double.valueOf((rs.getString("totalamount"))));
			histParams.setTransactionAmount(Double.valueOf((rs.getString("epayamount"))));
			histParams.setCommissionAmount (Double.valueOf(rs.getString("serviceamount")));
			histParams.setOnlineDebitStatus(rs.getString("paymentstatus"));
			histParams.setStatus_description(rs.getString("paymentdesc"));
			return histParams;
		}
	}
    
}