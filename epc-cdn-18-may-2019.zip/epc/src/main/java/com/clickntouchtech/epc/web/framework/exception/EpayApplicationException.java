package com.clickntouchtech.epc.web.framework.exception;

import org.apache.log4j.Logger;

import com.clickntouchtech.epc.web.framework.util.LoggingConstants;

public class EpayApplicationException extends RuntimeException {
    
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected final static Logger logger = Logger.getLogger(EpayApplicationException.class);   

    public String errorCode;

    public String errorDescription;
    
    private Exception exception;
    
    public EpayApplicationException(String errorCode){
        this.errorCode = errorCode;
    }
    public EpayApplicationException(Exception exception,String errorCode){
        this.errorCode = errorCode;
        this.exception = exception;
    }
    public String getErrorCode() {
        return errorCode;
    }
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }
    public String getErrorDescription() {
        return errorDescription;
    }
    public void setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
    }
    public static void throwException(String errorCode) throws EpayApplicationException{
        EpayApplicationException exception = new EpayApplicationException (errorCode);
        logger.error(LoggingConstants.EXCEPTION + exception.getMessage(),exception);
        throw exception;  
    }
    public static void throwException(String errorCode, Exception exceptionCaught) throws EpayApplicationException{
        EpayApplicationException exception = new EpayApplicationException(errorCode);
        logger.error(LoggingConstants.EXCEPTION + exceptionCaught.getMessage(),exceptionCaught);
        throw exception;
    }
   
    
}
