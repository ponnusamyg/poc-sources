package com.clickntouchtech.epc.web.epayreg.service;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.clickntouchtech.epc.web.epayreg.dao.EpayRegistrationDao;
import com.clickntouchtech.epc.web.framework.exception.EpayApplicationException;
import com.clickntouchtech.epc.web.framework.exception.EpayBaseResponse;
import com.clickntouchtech.epc.web.framework.exception.EpayDaoException;
import com.clickntouchtech.epc.web.framework.service.EpayBaseAbsService;
import com.clickntouchtech.epc.web.framework.service.ServiceErrorConstants;
import com.clickntouchtech.epc.web.framework.util.EmailUtils;

@Service
public class EpayUserRegistrationService extends EpayBaseAbsService {

	private static final Logger logger = LoggerFactory.getLogger(EpayUserRegistrationService.class);

	@Autowired
	private EpayRegistrationDao epayRegistrationDao;
 
 
	public ModelMap execute(Map inputParams) {

		logger.info("EpayOrgRegistrationService execute method begins");
			logger.debug("inputparams Map: {}", inputParams);

		ModelMap outParams = new ModelMap();
		Map responseParams = new HashMap();
		Map mailParams = new HashMap();
		EpayBaseResponse response = new EpayBaseResponse();
		response.setErrorStatus(ServiceErrorConstants.FAILURE);
		if (inputParams != null) {
			try {
				
				int registredCount = 0;
				String actionType = (String)inputParams.get("actionType");
				registredCount = epayRegistrationDao.getUserRegistrationCheck(inputParams);

				if (actionType == "registrationCheck" && actionType.equalsIgnoreCase("registrationCheck")) {

					if (registredCount == 0) {
						logger.error("registredCount ::::{}" + registredCount);
						response.setErrorCode("200");
						response.setErrorStatus("VALID");
						outParams.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
						return outParams;
					} else {
						logger.error("registredCount ::::{}" + registredCount);
						response.setErrorCode("400");
						response.setErrorStatus("INVALID");
						outParams.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
						return outParams;
					}

				} else {
					if (registredCount == 0) {
						responseParams = epayRegistrationDao.epayUserRegistration(inputParams);
						String name = (String) responseParams.get("name");
						String emailid = (String) responseParams.get("emailid");
						String mobileno = (String) responseParams.get("mobileno");
						String registrationid = (String) responseParams.get("registrationid");
						String status = (String) responseParams.get("status");
						mailParams.put("name", name);
						mailParams.put("emailid", emailid);
						mailParams.put("mobileno", mobileno);
						mailParams.put("registrationid", registrationid);
						if (status.equals("success")) {
							String domainUrl=(String) inputParams.get("domainUrl");
							EmailUtils.sendUserAuthMail(mailParams,domainUrl);
							response.setErrorStatus(ServiceErrorConstants.SUCCESS);

						} else {
							response.setErrorStatus(ServiceErrorConstants.FAILURE);
							response.setErrorMessage("New Organazation Registration Failed!");
							logger.debug("New Organazation Registration Failed!{}");
							return outParams;
						}
					} else {
						response.setErrorStatus(ServiceErrorConstants.FAILURE);
						response.setErrorMessage("User Already registred with Same Information!");
						outParams.addAttribute(ServiceErrorConstants.APPLICATION_RESPONSE, response);
						logger.debug("Dublicate Registration::::: {}", outParams);
						return outParams;

					}
				}

			
			} catch (EpayApplicationException cmsexp) {
				cmsexp.printStackTrace();
				response.setErrorCode("V101");
			} catch (EpayDaoException daoexp) {
				daoexp.printStackTrace();
				response.setErrorCode("V101");
			}

		}

		outParams.addAttribute(ServiceErrorConstants.APPLICATION_RESPONSE, response);
		logger.debug("outParams Map contains: {}", outParams);
		logger.info("EpayOrgRegistrationService execute method end{}");
		return outParams;

	}
}