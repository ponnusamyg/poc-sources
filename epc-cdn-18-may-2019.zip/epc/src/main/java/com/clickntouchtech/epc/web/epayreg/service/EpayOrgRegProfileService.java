package com.clickntouchtech.epc.web.epayreg.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.clickntouchtech.epc.web.epayreg.dao.EpayRegistrationDao;
import com.clickntouchtech.epc.web.epaysecurity.bean.EpayUsersProfile;
import com.clickntouchtech.epc.web.framework.exception.EpayApplicationException;
import com.clickntouchtech.epc.web.framework.exception.EpayBaseResponse;
import com.clickntouchtech.epc.web.framework.exception.EpayDaoException;
import com.clickntouchtech.epc.web.framework.service.EpayBaseAbsService;
import com.clickntouchtech.epc.web.framework.service.ServiceErrorConstants;

@Service
public class EpayOrgRegProfileService extends EpayBaseAbsService {

	private static final Logger logger = LoggerFactory.getLogger(EpayOrgRegProfileService.class);

	@Autowired
	private EpayRegistrationDao epayRegistrationDao;

	public ModelMap epayServiceBase(ModelMap inputParams) {
		logger.info("EpayUserProfileService execute method begins");
		logger.info("inputparams Map: {}", inputParams);

		ModelMap outParams = new ModelMap();
		ModelMap inParams = new ModelMap();
		EpayBaseResponse response = new EpayBaseResponse();
		response.setErrorStatus(ServiceErrorConstants.FAILURE);
		try {
			String registrationId = (String) inputParams.get("registrationId");
			String organaizationName = (String) inputParams.get("organaizationName");
			String emailId = (String) inputParams.get("emailId");
			EpayUsersProfile epayOrgREgUsersProfile = null;
			List orgRegStstus = null;
			if (registrationId != null && !registrationId.isEmpty()) {
				inParams.put("registrationId", registrationId);
				inParams.put("organaizationName", organaizationName);
				inParams.put("emailId", emailId);
				
			 
				int authendicationPendingCount = epayRegistrationDao.getAuthPendingList(inParams);
				if (authendicationPendingCount > 0) {
					epayOrgREgUsersProfile = epayRegistrationDao.getOrgRegistrationProfile(inParams);
					logger.info("epayOrgREgUsersProfile object{}", epayOrgREgUsersProfile);
					orgRegStstus = epayRegistrationDao.getOrgRegistrationStatus(registrationId);
					logger.info("orgRegStstusSize{}", orgRegStstus.size());
					outParams.addAttribute("orgRegStstus", orgRegStstus);
					outParams.addAttribute("epayOrgREgUsersProfile", epayOrgREgUsersProfile);
					response.setErrorStatus(ServiceErrorConstants.SUCCESS);
				} else if (authendicationPendingCount == 0) {
					logger.info("Authendication Pending Count is Zero :::::{}");
					response.setErrorStatus(ServiceErrorConstants.EPCERR002);
					outParams.addAttribute(ServiceErrorConstants.APPLICATION_RESPONSE, response);
					return outParams;
				}
			}
		} catch (EpayApplicationException cmsexp) {
			cmsexp.printStackTrace();
			response.setErrorCode("V101");
		} catch (EpayDaoException daoexp) {
			response.setErrorCode(daoexp.getErrorCode());
		}
		outParams.addAttribute(ServiceErrorConstants.APPLICATION_RESPONSE, response);
			logger.debug("outParams Map contains: {}", outParams);
		logger.info("EpayUserProfileService execute method end");
		return outParams;
	}
}
