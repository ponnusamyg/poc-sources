package com.clickntouchtech.epc.web.epayment.payment.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.clickntouchtech.epc.web.epayment.payment.model.EpayModelOrgData;
import com.clickntouchtech.epc.web.epayment.payment.model.EpayModelParams;
import com.clickntouchtech.epc.web.epayment.payment.model.EpayUser;
import com.clickntouchtech.epc.web.epayment.payment.model.Transaction;
import com.clickntouchtech.epc.web.epayment.payment.service.EPayFileTxnDetailsService;
import com.clickntouchtech.epc.web.epayment.payment.service.EPaymentConfirmService;
import com.clickntouchtech.epc.web.epayment.payment.service.EPaymentDetailsService;
import com.clickntouchtech.epc.web.epayment.payment.service.EpayDisplayClassificationService;
import com.clickntouchtech.epc.web.epayment.payment.service.EpayFieldKeyValidateService;
import com.clickntouchtech.epc.web.epayment.payment.service.EpayPreComfirmService;
import com.clickntouchtech.epc.web.epayment.payment.service.EpayValidationService;
import com.clickntouchtech.epc.web.epayment.payment.util.EpayUtilServiceCharge;
import com.clickntouchtech.epc.web.framework.exception.EpayBaseResponse;
import com.clickntouchtech.epc.web.framework.service.ServiceErrorConstants;

@Controller
@Scope("prototype")
public class EpayGatewayRequestController {

	private static final Logger logger = LoggerFactory.getLogger(EpayGatewayRequestController.class);

	@Autowired
	private EpayValidationService epayValidationService;
	@Autowired
	private EpayPreComfirmService epayPreComfirmService;
	@Autowired
	private EpayUtilServiceCharge epayServiceChargeUtils;
	@Autowired
	private EPaymentConfirmService ePaymentConfirmService;

	@Autowired
	private EpayDisplayClassificationService epayDisplayClassificationService;

	@Autowired
	private EPaymentDetailsService ePaymentDetailsService;

	@Autowired
	private ServletContext context;

	@Autowired
	private EPayFileTxnDetailsService epayFileTxnDetailsService;
		
	@Autowired
	private EpayFieldKeyValidateService epayFieldKeyValidateService;
	
	
	@Value("${cdn.url}") 
	private String cndUrl;

	/**
	 * 
	 * @return
	 */
	@RequestMapping(value = "/epcu/epayments", method = RequestMethod.POST)
	public String userEpaymentDetails(@RequestParam("organizationId") String organizationId,
			@RequestParam("classificationid") String classificationid, @RequestParam("orgstate") String orgstate,
			@RequestParam("classificationmode") String classificationmode, @RequestParam("fieldKey") String fieldKey,
			HttpServletRequest request, ModelMap modelMap) {
		logger.info("userEpaymentDetails method begin");

		ModelMap inParams = new ModelMap();
		ModelMap outParams = new ModelMap();

		HttpSession session = request.getSession(false);

		EpayUser user = (EpayUser) session.getAttribute("epayUser");
		HashMap<String, Object> cacheMap = (HashMap) user.getUserCache();
		List classificationOrgList = (List) cacheMap.get("classificationOrgList");
		EpayModelOrgData orgDetails = (EpayModelOrgData) classificationOrgList.get(0);

		Calendar calendar = new GregorianCalendar();
		int hour = calendar.get(Calendar.HOUR);
		int minute = calendar.get(Calendar.MINUTE);
		Date date = new Date();
		DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		String todayDate = formatter.format(date);
		Timestamp today = new Timestamp(new Date().getTime());
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy/HH/mm");
		String strTxnDate = simpleDateFormat.format(today);
		String[] dateArray = strTxnDate.split("/");
		String strDay = null;
		strDay = dateArray[0];
		String sHour = dateArray[3];
		String sMinute = dateArray[4];
		String currentTime = sHour + ":" + sMinute;
		String fileTxnFlag = classificationmode.toString();
		inParams.put("currentTime", currentTime);
		inParams.put("todayDate", todayDate);
		inParams.put("classificationid", classificationid);
		inParams.put("classificationmode", classificationmode);
		// inParams.put("uniqueRefNo", "16X41A0486-R161214");
		inParams.put("uniqueRefNo", fieldKey);
		logger.info("uniqueRefNo::: {}", fieldKey);

		if (fileTxnFlag != null && fileTxnFlag.equalsIgnoreCase("Y")) {
			outParams = epayFileTxnDetailsService.epayServiceBase(inParams);
			logger.info("Epay FileTxn Params:::::: {}", outParams);
			modelMap.addAllAttributes(outParams);
		} else {
			outParams = ePaymentDetailsService.epayServiceBase(inParams);
			modelMap.addAllAttributes(outParams);
		}
		ModelMap catParams = new ModelMap();
		inParams.addAttribute("organizationId", organizationId);
		inParams.addAttribute("orgstate", orgstate);
		inParams.addAttribute("classificationid", null);
		catParams = epayDisplayClassificationService.epayServiceBase(inParams);
		logger.info("Categories Params Recived::: {}", catParams);
		modelMap.addAllAttributes(catParams);

		EpayBaseResponse appResponse = (EpayBaseResponse) outParams.get(ServiceErrorConstants.APPLICATION_RESPONSE);
		logger.info("appResponse::::::::: {}", appResponse);
		if ("success".equals(appResponse.getErrorStatus())) {
			Map categorySessionParams = (Map) outParams.get("categorySessionParams");
			session.setAttribute("categorySessionParams", categorySessionParams);
			modelMap.addAttribute("organizationname", orgDetails.getOrganizationname());
			modelMap.addAttribute("orgaddress", orgDetails.getOrgaddress());
			modelMap.addAttribute("classificationid", classificationid);
		}

		logger.info("userEpaymentDetails method end {}", modelMap);
		logger.info("userEpaymentDetails method size {}", modelMap.size());
		logger.info("userEpaymentDetails method end");
		return "epayments";
	}

	@RequestMapping(value = "/epcu/confepayments", method = RequestMethod.POST)
	public String userEpaymentPreConfirm(@RequestParam Map<String, String> allRequestParams, HttpSession session,
			ModelMap modelMap) {
		logger.info("confirmPayment method begins");
		logger.info("allRequestParams------>>>> :{}", allRequestParams);
		ModelMap inParams = new ModelMap();
		ModelMap outParams = new ModelMap();

		EpayUser user = (EpayUser) session.getAttribute("epayUser");
		logger.info("user------>>>> :{}", user.getUserCache());
		HashMap<String, Object> cacheMap = (HashMap) user.getUserCache();
		logger.info("cacheMap------>>>> :{}", cacheMap);
		List classificationOrgList = (List) cacheMap.get("classificationOrgList");
		EpayModelOrgData orgDetails = (EpayModelOrgData) classificationOrgList.get(0);
		String registerNumber = (String) cacheMap.get("registerNumber");

		Map data = (HashMap) context.getAttribute("EPC_DEFAULT_LIMIT_MAP");
		if (data != null) {
			inParams.addAttribute("EPC_LIMIT", (String) data.get("EPC_LIMIT"));
		}

		boolean errorFlag = false;
		if (allRequestParams != null && allRequestParams.size() > 0) {

			ModelMap tmpParams = new ModelMap();
			tmpParams.addAttribute("cusName", allRequestParams.get("cusName"));
			tmpParams.addAttribute("dateOfBirth", allRequestParams.get("dateOfBirth"));
			tmpParams.addAttribute("mobileNo", allRequestParams.get("mobileNo"));
			for (Map.Entry<String, String> entry : allRequestParams.entrySet()) {
				String fieldName = entry.getKey();
				String value = entry.getValue();
				if (value != null && value.contains(">")) {
					errorFlag = true;
				}
				Map categorySessionParams = (Map) session.getAttribute("categorySessionParams");
				if (categorySessionParams != null && !categorySessionParams.isEmpty()) {
					Iterator itmp = categorySessionParams.entrySet().iterator();
					while (itmp.hasNext()) {
						Map.Entry pairs = (Map.Entry) itmp.next();
						if (pairs.getKey().equals(fieldName)) {
							value = (String) pairs.getValue();
						}
					}
				}
				logger.info("after validating fieldName:: {},    value:: {}", fieldName, value);
				inParams.addAttribute(fieldName, value);
			}
			logger.info("inParams : {}", inParams);
		}
		inParams.addAttribute("organizationid", orgDetails.getOrganizationId());
		inParams.addAttribute("organizationname", orgDetails.getOrganizationname());
		inParams.addAttribute("orgaddress", orgDetails.getOrgaddress());
		inParams.addAttribute("userName", allRequestParams.get("cusName"));
		inParams.addAttribute("profileuserName", user.getUserAlias());
		inParams.addAttribute("registerNumber", registerNumber);

		logger.info("inParams ---->>> : {}", inParams);
		outParams = epayValidationService.epayServiceBase(inParams);

		EpayBaseResponse validationResponse = (EpayBaseResponse) outParams
				.get(ServiceErrorConstants.APPLICATION_RESPONSE);

		if (validationResponse.getErrorStatus().equals((ServiceErrorConstants.FAILURE))) {
			errorFlag = true;
			modelMap.addAllAttributes(outParams);
			return "commonerror";
		}

		if (!errorFlag) {
			outParams = epayPreComfirmService.epayServiceBase(inParams);
			EpayBaseResponse appResponse = (EpayBaseResponse) outParams.get(ServiceErrorConstants.APPLICATION_RESPONSE);
			if ("success".equals(appResponse.getErrorStatus())) {
				Map feePaymentDetails = (Map) outParams.get("feePaymentsCacheDetails");
				logger.info("sesion map size:{}", cacheMap.size());
				cacheMap.put("feePaymentDetails", feePaymentDetails);
				logger.info("FeePaymentDetails put in cacheMap :{}", feePaymentDetails);
				user.setUserCache(cacheMap);
				Transaction transaction = (Transaction) feePaymentDetails.get("transaction");
				logger.info("transaction...{}", transaction);
				Map fieldkeyParamsMap = new HashMap();
				fieldkeyParamsMap = (Map) transaction.getDebit().getAdditionalParams();
				modelMap.addAttribute("orgname", fieldkeyParamsMap.get("fieldkey5"));
				modelMap.addAttribute("classificationid", fieldkeyParamsMap.get("fieldkey6"));
				modelMap.addAttribute("classificationname", fieldkeyParamsMap.get("fieldkey7"));
				modelMap.addAttribute("dynamicFieldkeyParamsMap", fieldkeyParamsMap.get("dynamicFieldkeyValuesMap"));
				modelMap.addAttribute("transactionRemarks", transaction.getDebit().getRemarks());
				modelMap.addAttribute("epayamount", outParams.get("txnamount"));
				modelMap.addAttribute("penaltyAmount", fieldkeyParamsMap.get("penaltyAmount"));
				modelMap.addAttribute("penaltyType", fieldkeyParamsMap.get("penaltyType"));
				modelMap.addAttribute("serviceChargeMap", fieldkeyParamsMap.get("serviceChargeMap"));

			}

			logger.info("showMopspage method begins");
			String errorView = null;
			Map inputParams = new HashMap();
			Map transactionMap = new HashMap();
			HashMap additionalParamsMap = null;
			String gatwayType = "GATEWAY";
			double totalDebitAmount = 0.0;
			inputParams = (Map) cacheMap.get("feePaymentDetails");
			logger.info("FeePaymentDetails get from cacheMap :{}", inputParams);
			String bankCode = "0";
			Transaction transaction = (Transaction) inputParams.get("transaction");
			double debitAmt = transaction.getDebit().getAmount();
			additionalParamsMap = (HashMap) transaction.getDebit().getAdditionalParams();
			Map serviceChargeMap = (Map) additionalParamsMap.get("serviceChargeMap");
			String recoveredFrom = ((String) serviceChargeMap.get("sourceserviceamount"));
			EpayModelParams epayModelParams = (EpayModelParams) inputParams.get("preloginParams");
			String organizationid = (String) epayModelParams.getOrganizationId();
			String mopscategoryid = (String) epayModelParams.getClassificationId();
			String mopsFlag = "PG";
			logger.info("category_id for MOPSFILTER ::{}", mopscategoryid);
			inputParams.put("categoryId", mopscategoryid);
			inputParams.put("mopsFlag", mopsFlag);
			inputParams.put("organizationid", organizationid);
			outParams.addAttribute("epayamount", debitAmt);
			modelMap.addAllAttributes(outParams);

			DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			Date date = new Date();
			System.out.println(dateFormat.format(date));
			session.setAttribute("epaymentDate", dateFormat.format(date));

			if ("YES".equalsIgnoreCase((String) serviceChargeMap.get("serviceamountreqq"))) {
				String orgrootId = (String) serviceChargeMap.get("orgrootId");
				if ("GATEWAY".equalsIgnoreCase(gatwayType)) {
					double otherinbSlabAmount = 0.0;
					double epayservicecharge = 0.0;
					double otherInbCommAmount = 0.0;
					double roundOff = 0.0;
					otherinbSlabAmount = epayServiceChargeUtils.getEpayServiceCharge(debitAmt, "0000", orgrootId,
							"EPAYCHARGE");
					totalDebitAmount = debitAmt;
					totalDebitAmount += otherinbSlabAmount;
					otherInbCommAmount = epayServiceChargeUtils.getEpayServiceCharge(totalDebitAmount, "0000",
							orgrootId, "GATEWAYCHARGE");
					if (recoveredFrom.equals("EPAYUSR")) {
						roundOff = otherinbSlabAmount + otherInbCommAmount;
						roundOff = Math.round(roundOff * 100.0) / 100.0;
						epayservicecharge = roundOff;
					}
					modelMap.addAttribute("epayservicecharge", epayservicecharge);
					session.setAttribute("otherinbSlabAmount", otherinbSlabAmount);
					session.setAttribute("otherInbCommAmount", otherInbCommAmount);
					session.setAttribute("epayservicecharge", epayservicecharge);
				}
				modelMap.addAttribute("orgrootId", orgrootId);
			}
			modelMap.addAttribute("serverHour", getServerTimeMin(new Date()).get(Calendar.HOUR_OF_DAY));
			modelMap.addAttribute("serverMinute", getServerTimeMin(new Date()).get(Calendar.MINUTE));
			logger.info("showMopspage method end");
			modelMap.addAllAttributes(outParams);
			modelMap.addAttribute("organizationid", orgDetails.getOrganizationId());
			modelMap.addAttribute("organizationname", orgDetails.getOrganizationname());
			modelMap.addAttribute("orgaddress", orgDetails.getOrgaddress());
			logger.info("confirmPayment method end");
			return "confirmpayment";
		}
		return "commonerror";
	}

	// HttpSession session,
	@RequestMapping(value = "/epcu/confirmepayment", method = RequestMethod.POST)
	public String userEpaymentGatewayConfirm(@RequestParam("epaytype") String epay, HttpServletRequest request,
			HttpServletResponse response, ModelMap modelMap) {
		logger.info("Epayconter ConfirmPayment method begin");

		ModelMap outParams = new ModelMap();

		Map inputParams = new HashMap();
		HashMap additionalParamsMap = null;

		// String payOption=null;
		String urlOption = null;

		double slabAmount = 0.0;
		double totalAmount = 0.0;
		double txnAmount = 0.0;
		double commAmount = 0.0;
		double roundOff = 0.0;
		String narrativeAmount = "";
		String bankCode = "0";

		HttpSession session = request.getSession(false);
		EpayUser user = (EpayUser) session.getAttribute("epayUser");
		HashMap<String, Object> cacheMap = (HashMap) user.getUserCache();
		inputParams = (Map) cacheMap.get("feePaymentDetails");
		Transaction transaction = (Transaction) inputParams.get("transaction");
		EpayModelParams epayModelParams = (EpayModelParams) inputParams.get("preloginParams");

		// epayModelParams.setTrnFrom("INBWEB");

		additionalParamsMap = (HashMap) transaction.getDebit().getAdditionalParams();
		Map serviceChargeMap = (Map) additionalParamsMap.get("serviceChargeMap");
		String recoveredFrom = ((String) serviceChargeMap.get("sourceserviceamount"));
		String corporateID = ((String) serviceChargeMap.get("orgrootId"));
		String corporateName = ((String) additionalParamsMap.get("fieldkey5"));
		corporateName = corporateName.replaceAll("[^a-zA-Z0-9_,@.-]", " ");
		String categoryName = ((String) additionalParamsMap.get("fieldkey7"));
		categoryName = categoryName.replaceAll("[^a-zA-Z0-9_,@.-]", " ");

		logger.info("corporate Name::: {},Classification Name:::{}", corporateName, categoryName);

		String InstituteGroup = null;

		if ("GATEWAY".equals(epay)) {

			logger.info("epay is:{}", epay);
			epay = "PAYUMONEY";
			double otherinbSlabAmount = 0.0;
			double otherInbConvAmount = 0.0;
			otherinbSlabAmount = (Double) session.getAttribute("otherinbSlabAmount");
			otherInbConvAmount = (Double) session.getAttribute("otherInbCommAmount");
			txnAmount = epayModelParams.getEpayamount();
			totalAmount = txnAmount;
			if (recoveredFrom.equals("EPAYUSR")) {
				slabAmount = otherinbSlabAmount + otherInbConvAmount;
				totalAmount += slabAmount;
			}
			if (recoveredFrom.equals("EPAYORGUSR")) {
				totalAmount += otherInbConvAmount;
			}
			totalAmount = roundTotalAmount(totalAmount);
			narrativeAmount = String.valueOf(otherInbConvAmount);
			epayModelParams.setServiceamount(otherinbSlabAmount);
			epayModelParams.setTotalamount(totalAmount);
			epayModelParams.setConvenienceamount(narrativeAmount);
			epayModelParams.setPaymentstatus("TP");

		}
		epayModelParams.setServiceamounttype(recoveredFrom);
		/* Added for BDRI changes */
		String captchaValue = request.getParameter("captchaValue");
		String captchaImage = (String) session.getAttribute("captchaImage");

		if (user == null) {

			logger.info("user session has expired");
			return "sessionTimeoutPage";

		} else {

			Map transactionMap = new HashMap();
			Map Success_params = new HashMap();
			String errorView = null;
			String categorybankCode = null;

			if (epay == null) {
				EpayBaseResponse errorResponse = new EpayBaseResponse();
				errorResponse.setErrorStatus("failure");
				errorResponse.setErrorCode("REF010");
				outParams.addAttribute("errorResponse", errorResponse);

				return "sessionerror";

			} else {

				outParams.addAttribute("payOption", epay);
				epayModelParams.setModeofpayment(epay);

				logger.info("User in session :{}", user.getUserAlias() + user.getUserType() + user.getCorporateId());

				// String registerNo=
				// (String)session.getAttribute("registerNo");
				String registerNo = (String) cacheMap.get("registerNumber");

				// epayModelParams.setBankCode(bankCode);

				/*
				 * if("BRANCH".equalsIgnoreCase(epay)) {
				 * preloginParams.setPaymentMode("BRANCH"); } else {
				 * 
				 * }
				 */

				String category_id = (String) epayModelParams.getClassificationId();

				if (registerNo == null || registerNo.isEmpty()) {
					registerNo = "0";
				}
				if (registerNo != null) {
					inputParams.put("registerNo", registerNo);
				}

				inputParams.put("payOption", epay);
				inputParams.put("categoryid", category_id);
				session.setAttribute("registerNo", registerNo);
				// epayModelParams.setNarrative3(registerNo);

				inputParams.put("bankCode", bankCode);
				outParams.addAttribute("InstituteGroup", InstituteGroup);

				String sessionId = session.getId();
				String serverName = (String) request.getRemoteHost();

				inputParams.put("reqSessionId", sessionId);
				inputParams.put("reqServerName", serverName);
				inputParams.put("userName", user.getUserAlias());
				inputParams.put("userIpAddress", user.getUserIPaddress());
				inputParams.put("deviceType", user.getChannelType());

				transactionMap = ePaymentConfirmService.execute(inputParams);

				logger.info("pay option in card payment :{}", epay);
				outParams.addAttribute("bankCode", bankCode);

				EpayBaseResponse appResponse = (EpayBaseResponse) transactionMap
						.get(ServiceErrorConstants.APPLICATION_RESPONSE);

				logger.info("Error code ::{}, Error message :: {}", appResponse.getErrorCode(),
						appResponse.getErrorMessage());

				if ("success".equalsIgnoreCase(appResponse.getErrorStatus())) {

					if ("PAYUMONEY".equalsIgnoreCase(epay)) {

						Map inParams = new HashMap();
						logger.info("Redirecting to PayU Desk  site::");
						String referenceNo = transaction.getDebit().getReferenceNo();
						String echequeAmount = "";
						String actionURL = null;
						logger.info("Reference No :{}", referenceNo);

						inParams.put("referenceNo", referenceNo);
						// BigDecimal paise = new
						// BigDecimal(preloginParams.getEchequeAmount());
						String billDeskActionURL = null;
						DecimalFormat df = new DecimalFormat("#.##");
						echequeAmount = df.format(epayModelParams.getTotalamount());

						logger.info("echequeAmount   :::  {}", echequeAmount);

						JavaIntegrationKit integrationKit = new JavaIntegrationKit();
						try {

							Map reqParams = new HashMap();

							reqParams.put("amount", echequeAmount);
							reqParams.put("firstname", corporateID);
							reqParams.put("email", "epaycounter@gmail.com");
							reqParams.put("phone", "9645555155");
							reqParams.put("productinfo", "ePayCounter");
							String servername = request.getServerName();
							String context = request.getContextPath();							
							String scheme = request.getScheme();
					        int portNumber = request.getServerPort();
					        String servletPath = request.getServletPath();
					        logger.info("servername -------------------->>> {}", servername);
							logger.info("context Name -------------------->>> {}", context);
					        logger.info("scheme -------------------->>> {}", scheme);
					    	logger.info("portNumber  -------------------->>> {}", portNumber);
					        logger.info("servletPath -------------------->>> {}", servletPath);						
							
							if ("localhost".equals(servername)) {//LOCAL 
								reqParams.put("surl", ""+scheme+"://"+servername+":"+portNumber+""+context+"/gwrpu/epaymentsresponse");
								reqParams.put("furl", ""+scheme+"://"+servername+":"+portNumber+""+context+"/gwrpu/epaymentsresponse");
							} else {//CLOUD 
								reqParams.put("surl", ""+scheme+"://"+servername+"/gwrpu/epaymentsresponse");
								reqParams.put("furl", ""+scheme+"://"+servername+"/gwrpu/epaymentsresponse");
							}
							reqParams.put("service_provider", "payu_paisa");
							reqParams.put("hash_string", "");
							reqParams.put("hash", "");
							reqParams.put("txnid", "");
							reqParams.put("udf1", referenceNo);

							logger.info("reqParams --->>> {}", reqParams);
							
							
							logger.info("cndUrl====================================== --->>> {}", cndUrl);
							

							Map<String, String> values = integrationKit.hashCalMethod(reqParams, response);
							// build HTML code
							PrintWriter writer = response.getWriter();
							String htmlResponse = "<html> <body> " + "<head>" + values.get("firstname").trim()
									+ " <style type='text/css'> .loader {position: fixed;left: 0px;top: 0px;width: 100%;height: 100%; z-index: 9999;"
									+ " background: url('//d2ivc9zanyedd.cloudfront.net/web/templates/ePayCounter/layouts/images/loader.gif') 50% 50% no-repeat rgb(249,249,249);"
									+ " } </style> <script type='text/javascript'>" + "$(window).load(function() {"
									+ "$('.loader').fadeOut('slow'); }) </script> <div class='loader'></div>"
									+ "</head>" + "<form id=\"payuform\" action=\"" + values.get("action")
									+ "\"  name=\"payuform\" method=POST >"
									+ "<input type=\"hidden\" name=\"key\" value=" + values.get("key").trim() + ">"
									+ "<input type=\"hidden\" name=\"hash\" value=" + values.get("hash").trim() + ">"
									+ "<input type=\"hidden\" name=\"txnid\" value=" + values.get("txnid").trim() + ">"

									+ "<input type=\"hidden\" name=\"amount\" value=" + values.get("amount").trim()
									+ " />" + "<input type=\"hidden\" name=\"firstname\" id=\"firstname\" value="
									+ values.get("firstname").trim() + " />"
									+ "<td><input type=\"hidden\" name=\"email\" id=\"email\" value="
									+ values.get("email").trim() + " /></td>\n"
									+ "<td><input type=\"hidden\" name=\"phone\" value=" + values.get("phone")
									+ " ></td>\n" + "<td><input type=\"hidden\" name=\"productinfo\" value="
									+ values.get("productinfo").trim() + " ></td>\n"
									+ "<td colspan=\"3\"><input type=\"hidden\" name=\"surl\"  size=\"64\" value="
									+ values.get("surl") + "></td>\n"
									+ "<td colspan=\"3\"><input type=\"hidden\" name=\"furl\" value="
									+ values.get("furl") + " size=\"64\" ></td>\n"
									+ "<td colspan=\"3\"><input type=\"hidden\" name=\"service_provider\" value=\"payu_paisa\" /></td>\n"
									+ "<td><input type=\"hidden\" name=\"lastname\" id=\"lastname\" value="
									+ values.get("lastname") + " ></td>\n"
									+ "<td><input type=\"hidden\" name=\"curl\" value=" + values.get("curl")
									+ " ></td>\n" + "<td><input type=\"hidden\" name=\"address1\" value="
									+ values.get("address1") + " ></td>\n"
									+ "<td><input type=\"hidden\" name=\"address2\" value=" + values.get("address2")
									+ " ></td>\n" + "<td><input type=\"hidden\" name=\"city\" value="
									+ values.get("city") + "></td>\n"
									+ "<td><input type=\"hidden\" name=\"state\" value=" + values.get("state")
									+ "></td>\n" + "<td><input type=\"hidden\" name=\"country\" value="
									+ values.get("country") + " ></td>\n"
									+ "<td><input type=\"hidden\" name=\"zipcode\" value=" + values.get("zipcode")
									+ " ></td>\n" + "<td><input type=\"hidden\" name=\"udf1\" value="
									+ values.get("udf1") + "></td>\n"
									+ "<td><input type=\"hidden\" name=\"udf2\" value=" + values.get("udf2")
									+ "></td>\n" + " <td><input type=\"hidden\" name=\"hashString\" value="
									+ values.get("hashString") + "></td>\n"
									+ "<td><input type=\"hidden\" name=\"udf3\" value=" + values.get("udf3")
									+ " ></td>\n" + "<td><input type=\"hidden\" name=\"udf4\" value="
									+ values.get("udf4") + " ></td>\n"
									+ "<td><input type=\"hidden\" name=\"udf5\" value=" + values.get("udf5")
									+ " ></td>\n" + "<td><input type=\"hidden\" name=\"pg\" value=" + values.get("pg")
									+ " ></td>\n"
									+ "        <td colspan=\"4\"><input type=\"hidden\" value=\"Submit\"  /></td>\n"
									+ "    </form>" + " <script> " + " document.getElementById(\"payuform\").submit(); "
									+ " </script> " + "       </div>   " + "  \n" + "  </body>\n" + "</html>";

							writer.println(htmlResponse);

						} catch (ServletException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}

						logger.info("txn Amount   :::  {}", echequeAmount);
						String securityID = null;
						String merchantCode = null;

						return null;

					}

				} else {

					if (appResponse.getErrorCode().equals("SUV013")) {
						appResponse.setErrorCode("SUV013");

					} else {
						appResponse.setErrorStatus("failure");
						appResponse.setErrorCode("SE200");
					}

				}
				transactionMap.put("applicationResponse", appResponse);
			}

			return "errorView";

		}
	}

	// File Txn

	@RequestMapping(value = "/epcu/epaymentss", method = RequestMethod.POST)
	public String userEpaymentDetailsFileTxn(@RequestParam("organizationId") String organizationId,
			@RequestParam("classificationid") String classificationid, @RequestParam("orgstate") String orgstate,
			@RequestParam("fieldKey") String fieldKey, HttpServletRequest request, ModelMap modelMap) {
		logger.info("userEpaymentDetailsFileTxn method begin");

		ModelMap inParams = new ModelMap();
		ModelMap outParams = new ModelMap();

		HttpSession session = request.getSession(false);

		EpayUser user = (EpayUser) session.getAttribute("epayUser");
		HashMap<String, Object> cacheMap = (HashMap) user.getUserCache();
		List classificationOrgList = (List) cacheMap.get("classificationOrgList");
		EpayModelOrgData orgDetails = (EpayModelOrgData) classificationOrgList.get(0);

		Calendar calendar = new GregorianCalendar();
		int hour = calendar.get(Calendar.HOUR);
		int minute = calendar.get(Calendar.MINUTE);
		Date date = new Date();
		DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
		String todayDate = formatter.format(date);
		Timestamp today = new Timestamp(new Date().getTime());
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy/HH/mm");
		String strTxnDate = simpleDateFormat.format(today);
		String[] dateArray = strTxnDate.split("/");
		String strDay = null;
		strDay = dateArray[0];
		String sHour = dateArray[3];
		String sMinute = dateArray[4];
		String currentTime = sHour + ":" + sMinute;
		inParams.put("currentTime", currentTime);
		inParams.put("todayDate", todayDate);
		inParams.put("classificationid", classificationid);
		inParams.put("uniqueRefNo", "16X41A0486-R161214");

		logger.info("categoryId############ : {}", classificationid);
		logger.info("inParams############ : {}", inParams);
		outParams = epayFileTxnDetailsService.epayServiceBase(inParams);
		logger.info("epayFileTxnDetailsService ############ : {}", outParams);
		modelMap.addAllAttributes(outParams);

		ModelMap catParams = new ModelMap();
		inParams.addAttribute("organizationId", organizationId);
		inParams.addAttribute("orgstate", orgstate);
		inParams.addAttribute("classificationid", null);
		logger.info("institutionId############ : {}", organizationId);
		logger.info("state########## {}", orgstate);
		catParams = epayDisplayClassificationService.epayServiceBase(inParams);
		logger.info("catParams############ : {}", catParams);
		modelMap.addAllAttributes(catParams);

		EpayBaseResponse appResponse = (EpayBaseResponse) outParams.get(ServiceErrorConstants.APPLICATION_RESPONSE);
		if ("success".equals(appResponse.getErrorStatus())) {
			Map categorySessionParams = (Map) outParams.get("categorySessionParams");
			session.setAttribute("categorySessionParams", categorySessionParams);
			modelMap.addAttribute("organizationname", orgDetails.getOrganizationname());
			modelMap.addAttribute("orgaddress", orgDetails.getOrgaddress());
			modelMap.addAttribute("classificationid", classificationid);
		}

		logger.info("userEpaymentDetails method end {}", modelMap);
		logger.info("userEpaymentDetails method size {}", modelMap.size());
		logger.info("userEpaymentDetailsFileTxn method end");
		return "epayments";
	}

	public double convertRoundOffAmount(double Amount) {
		BigDecimal comAmount = new BigDecimal(Amount);
		comAmount = comAmount.setScale(2, BigDecimal.ROUND_HALF_EVEN);
		double commAmount = comAmount.doubleValue();
		return commAmount;
	}

	// added for bill desk total amount round off value
	public double roundTotalAmount(double totalAmount) {
		double roundOff = 0.0;
		roundOff = Math.round(totalAmount * 100.0) / 100.0;
		return roundOff;
	}

	private Calendar getServerTimeMin(Date date) {

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		return calendar;
	}
	
	@RequestMapping(value = "/epcu/checkFieldKeyValid", method = { RequestMethod.GET })
	public void checkFieldKeyValid(HttpServletRequest request, HttpServletResponse response,
			@RequestParam("sendField") String sendField) {
		logger.debug("checkFieldKeyValid method begin ");
		String result = "success";
		Map outParams = new HashMap();
		ModelMap inParams = new ModelMap();

		try {
			String[] delimitField = sendField.split("\\~");
			String organizationId = delimitField[0];
			String classificationid = delimitField[1];
			String uniqueRefNo = delimitField[2];
			String classificationmode = delimitField[3];
			logger.info("captchaValueFromJsp : {}", sendField);
			if (sendField != null && !sendField.equals("")) {

				inParams.put("organizationId", organizationId);
				inParams.put("classificationid", classificationid);
				inParams.put("uniqueRefNo", uniqueRefNo);
				inParams.put("classificationmode", classificationmode);
				outParams = epayFieldKeyValidateService.epayServiceBase(inParams);

				EpayBaseResponse validationResponse = (EpayBaseResponse) outParams
						.get(ServiceErrorConstants.APPLICATION_RESPONSE);

				if (validationResponse.getErrorCode() == "200"
						|| validationResponse.getErrorStatus().equalsIgnoreCase("VALID")) {
					result = "success";
				}
				else if (validationResponse.getErrorCode() != "200"
						&& !validationResponse.getErrorStatus().equalsIgnoreCase("VALID")) {
					result = "failure";
				} else {
					result = "failure";
				}
			} else if (sendField == null || sendField.equals("")) {
				result = "failure";
			}

			PrintWriter out = null;
			try {
				out = response.getWriter();
				out.print(result);
			} catch (Exception e) {
				logger.error("Exception in :" + e.getMessage());
			} finally {
				out.close();
			}

		} catch (Exception e) {
			logger.error("Exception has occured in the checkFieldKeyValid method");
		}
		logger.debug("checkFieldKeyValid method ends ");
		// return null;
	}
	
	
	
	

}
