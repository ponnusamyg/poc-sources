/**
 * @(#) Transaction.java
 */
package com.clickntouchtech.epc.web.epayment.payment.model;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Map;


/**
 * TODO Enter the description of the class here 
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
/**
 * TODO Enter the description of the class here 
 * 
 * @version 1.0
 * @author Satyam Computer Services Ltd.,
 */
public abstract class Transaction  implements EpayBaseModel
{
    
        private TransactionLeg debit = null;
        
        private  TransactionLeg[] credit = null;
        //public Timestamp transactionTime = null;
        private  String path =null; 
        private String name =null;
        
        private String friendlyName;
        // added for schedule payment
        private Timestamp scheduledDate=new Timestamp(new Date().getTime());
        private boolean scheduled = false;
        
        private String bankCode=null;
        
        private TransactionLeg addParams = null;
        
        private Map benaddress; 
        
        private String smallFlag ; 
        
      public void setPath(String path)
      {
            this.path = path;  
        
       }
      public void setName(String name)
      {
            this.name = name;  
        
       }

 public String  getPath()
 {
     return path;
 }
 public String getName()
 {
     return name;
 }
public TransactionLeg[] getCredit() {
    return credit;
}
public void setCredit(TransactionLeg[] credit) {
    this.credit = credit;
}
public TransactionLeg getDebit() {
    return debit;
}
public void setDebit(TransactionLeg debit) {
    this.debit = debit;
}
public String getFriendlyName() {
	return friendlyName;
}
public void setFriendlyName(String friendlyName) {
	this.friendlyName = friendlyName;
}
public boolean isScheduled()
{
    return scheduled;
}
public void setScheduled(boolean scheduled)
{
    this.scheduled = scheduled;
}
public Timestamp getScheduledDate()
{
    return scheduledDate;
}
public void setScheduledDate(Timestamp scheduledDate)
{
    this.scheduledDate = scheduledDate;
}
public String getBankCode() {
	return bankCode;
}
public void setBankCode(String bankCode) {
	this.bankCode = bankCode;
}
public Map getBenaddress() {
	return benaddress;
}
public void setBenaddress(Map benaddress) {
	this.benaddress = benaddress;
}
public TransactionLeg getAddParams() {
	return addParams;
}
public void setAddParams(TransactionLeg addParams) {
	this.addParams = addParams;
}
public String getSmallFlag() {
	return smallFlag;
}
public void setSmallFlag(String smallFlag) {
	this.smallFlag = smallFlag;
}

}
