package com.clickntouchtech.epc.web.epayment.payment.service;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.clickntouchtech.epc.web.epayment.payment.dao.EpayOrgDao;
import com.clickntouchtech.epc.web.framework.exception.EpayApplicationException;
import com.clickntouchtech.epc.web.framework.exception.EpayBaseResponse;
import com.clickntouchtech.epc.web.framework.exception.EpayDaoException;
import com.clickntouchtech.epc.web.framework.service.EpayBaseAbsService;
import com.clickntouchtech.epc.web.framework.service.ServiceErrorConstants;
import com.clickntouchtech.epc.web.framework.util.LoggingConstants;

@Service
public class EpayFieldKeyValidateService extends EpayBaseAbsService {

	private static final Logger logger = LoggerFactory.getLogger(EpayFieldKeyValidateService.class);

	@Autowired
	private EpayOrgDao epayOrgDao;

	public ModelMap epayServiceBase(ModelMap inputParams) {
		logger.info("EpayFieldKeyValidateService execute method begins{}");
		logger.debug("inputparams Map:: {}", inputParams);
		EpayBaseResponse response = new EpayBaseResponse();
		response.setErrorStatus(ServiceErrorConstants.FAILURE);
		ModelMap outParams = new ModelMap();
		String classificationid = (String) inputParams.get("classificationid");
		String uniqueRefNo = (String) inputParams.get("uniqueRefNo");
		if (classificationid != null && !classificationid.equalsIgnoreCase("")) {
			try {
				if (uniqueRefNo != null) {
					Map fileModeCategoryMap = epayOrgDao.fileTxnClassificationFields(classificationid, uniqueRefNo);
					if (fileModeCategoryMap != null && fileModeCategoryMap.size() != 0) {
						logger.error("Valid Key ::::{}" + uniqueRefNo);
						response.setErrorCode("200");
						response.setErrorStatus("VALID");
						outParams.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
						return outParams;
					} else {
						logger.error("Record Not Found for Entered ::::{}" + uniqueRefNo);
						response.setErrorCode("400");
						response.setErrorStatus("INVALID");
						outParams.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
						return outParams;
					}
				}
			} catch (EpayApplicationException epcexp) {
				logger.error(LoggingConstants.EXCEPTION, epcexp);
				logger.info("Exception at 115{}");
				response.setErrorStatus(ServiceErrorConstants.FAILURE);
				response.setErrorCode(epcexp.getErrorCode());

			} catch (EpayDaoException dataAccessException) {
				logger.error("Exception occured {}:" + dataAccessException);
				logger.info("Exception at 122");
				response.setErrorStatus(ServiceErrorConstants.FAILURE);
				response.setErrorMessage(ServiceErrorConstants.UNDEFINED);
				response.setErrorCode("SUV010");
			}

			catch (Exception exp) {
				logger.info("Exception at 122");
				logger.error(LoggingConstants.EXCEPTION, exp);
				response.setErrorStatus(ServiceErrorConstants.FAILURE);
				response.setErrorMessage(ServiceErrorConstants.UNDEFINED);
				response.setErrorCode("SUV010");
			}

		}
		outParams.put(ServiceErrorConstants.APPLICATION_RESPONSE, response);
		logger.info("EPayFileTxnDetailsService execute method Ends");
		return outParams;

	}

}