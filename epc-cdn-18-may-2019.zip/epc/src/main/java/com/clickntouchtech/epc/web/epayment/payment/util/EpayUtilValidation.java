package com.clickntouchtech.epc.web.epayment.payment.util;

import java.util.regex.Pattern;

/**
 * @author Tech M
 *This class used for validate the attribute field values.
 *May-20-2016
 */
public class EpayUtilValidation {
	
	/*private static final String NAME_VALIDATION = "^[a-zA-Z]+(([\\'\\,\\.\\ ][a-zA-Z])?[a-zA-Z][.]*)*$";*/
		private static final String NAME_VALIDATION ="^[a-zA-Z\\'\\,\\.\\ \\s+]*$";
	
	public static boolean getValidateDynamicField(String inputValues,String format){

			if(!(inputValues.isEmpty()|| inputValues.equals("null"))){
		
            if(Pattern.matches(format, inputValues))
                  return true;
            else
                  return false;
			}
			
			return true;
	}
	
	public static boolean getValidateName(String inputValues) {

		if (inputValues.trim().matches(NAME_VALIDATION))
			return true;
		else
			return false;
	}
	
	
	public static boolean getValidateRemarks(String inputValues) {

		if(!(inputValues.isEmpty()|| inputValues.equals("null"))){
			
			if (inputValues.trim().matches(NAME_VALIDATION))
				return true;
			else
				return false;
			}
		return true;
	}

}
