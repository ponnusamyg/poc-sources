package com.clickntouchtech.epc.web.epayment.payment.model;

import java.util.Map;

public class EpayFormValues implements EpayBaseModel
{
    private String requestVarname;
    private String label;
    private String controlType;
    private String defaultValue;
    private Map controlValues;
    private String format;
    private String errorMessage;
    private Integer fieldSize;
    private String mandatory;
    private String exceptionCode;
    private String value;
    private String fileMode;
    
    private String fieldDesc;
    
    /**
	 * @return the fieldDesc
	 */
	public String getFieldDesc() {
		return fieldDesc;
	}
	/**
	 * @param fieldDesc the fieldDesc to set
	 */
	public void setFieldDesc(String fieldDesc) {
		this.fieldDesc = fieldDesc;
	}
	public String getFileMode() {
		return fileMode;
	}
	public void setFileMode(String fileMode) {
		this.fileMode = fileMode;
	}
	public String getDefaultValue()
    {
        return defaultValue;
    }
    public void setDefaultValue(String defaultValue)
    {
        this.defaultValue = defaultValue;
    }
    public String getErrorMessage()
    {
        return errorMessage;
    }
    public void setErrorMessage(String errorMessage)
    {
        this.errorMessage = errorMessage;
    }
    public String getFormat()
    {
        return format;
    }
    public void setFormat(String format)
    {
        this.format = format;
    }
    
    public String getControlType()
    {
        return controlType;
    }
    public void setControlType(String controlType)
    {
        this.controlType = controlType;
    }
    
    public Integer getFieldSize()
    {
        return fieldSize;
    }
    public void setFieldSize(Integer fieldSize)
    {
        this.fieldSize = fieldSize;
    }
    public String getLabel()
    {
        return label;
    }
    public void setLabel(String label)
    {
        this.label = label;
    }
   
    public String getMandatory()
    {
        return mandatory;
    }
    public void setMandatory(String mandatory)
    {
        this.mandatory = mandatory;
    }
    public String getRequestVarname()
    {
        return requestVarname;
    }
    public void setRequestVarname(String requestVarname)
    {
        this.requestVarname = requestVarname;
    }
    public Map getControlValues()
    {
        return controlValues;
    }
    public void setControlValues(Map controlValues)
    {
        this.controlValues = controlValues;
    }
    public String getExceptionCode()
    {
        return exceptionCode;
    }
    public void setExceptionCode(String exceptionCode)
    {
        this.exceptionCode = exceptionCode;
    }
    public String getValue()
    {
        return value;
    }
    public void setValue(String value)
    {
        this.value = value;
    }
  
    
}