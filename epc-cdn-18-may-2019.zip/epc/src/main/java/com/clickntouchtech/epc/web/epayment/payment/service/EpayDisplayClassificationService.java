package com.clickntouchtech.epc.web.epayment.payment.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.clickntouchtech.epc.web.epayment.payment.dao.EpayOrgDao;
import com.clickntouchtech.epc.web.epayment.payment.model.EpayModelOrgData;
import com.clickntouchtech.epc.web.framework.exception.EpayApplicationException;
import com.clickntouchtech.epc.web.framework.exception.EpayBaseResponse;
import com.clickntouchtech.epc.web.framework.exception.EpayDaoException;
import com.clickntouchtech.epc.web.framework.service.EpayBaseAbsService;
import com.clickntouchtech.epc.web.framework.service.ServiceErrorConstants;
import com.clickntouchtech.epc.web.framework.util.LoggingConstants;

@Service
public class EpayDisplayClassificationService extends EpayBaseAbsService {

	private static final Logger logger = LoggerFactory.getLogger(EpayDisplayClassificationService.class);

	@Autowired
	private EpayOrgDao epayOrgDao;

	public ModelMap epayServiceBase(ModelMap inputParams) {

		logger.info("EpayDisplayClassificationService execute method begins");
		EpayBaseResponse response = new EpayBaseResponse();
		response.setErrorStatus(ServiceErrorConstants.FAILURE);
		ModelMap outParams = new ModelMap();
		String orgstate = (String) inputParams.get("orgstate");
		String organizationId = (String) inputParams.get("organizationId");
		String classificationID = (String) inputParams.get("classificationid");
		List classificationOrgList = null;
		List classificationList = null;
		if (organizationId != null && !organizationId.equalsIgnoreCase("")) {

			try {
				classificationOrgList = epayOrgDao.getEpayOrgDetails(organizationId);
				classificationList = epayOrgDao.getEpayClassification(organizationId, orgstate, classificationID);
				logger.info("classificationList########## {}", classificationOrgList);
				logger.info("classificationList########## {}", classificationOrgList.size());
				logger.info("organizationId########## {}", organizationId);
				logger.info("state########## {}", orgstate);
				logger.info("categoryId########## {}", classificationID);
				logger.info("categoryList########## {}", classificationList);
				logger.info("categoryList size########## {}", classificationList.size());
				if (classificationOrgList != null && classificationOrgList.size() > 0) {
					EpayModelOrgData classificationOrg = (EpayModelOrgData) classificationOrgList.get(0);
					if (classificationList != null && classificationList.size() > 0) {
						classificationOrg.setClassificationList(classificationList);
						outParams.put("classificationOrgList", classificationOrgList);
						response.setErrorStatus(ServiceErrorConstants.SUCCESS);
					} else {
						logger.info("Classification list is null or empty");
						response.setErrorStatus(ServiceErrorConstants.FAILURE);
						response.setErrorCode("SUV006");
					}
				} else {
					logger.info("classificationOrg is null or empty");
					response.setErrorStatus(ServiceErrorConstants.FAILURE);
					response.setErrorCode("SUV005");
				}

			} catch (EpayApplicationException cmsexp) {
				logger.error(LoggingConstants.EXCEPTION, cmsexp);
				response.setErrorStatus(ServiceErrorConstants.FAILURE);
				response.setErrorCode(cmsexp.getErrorCode());
				cmsexp.printStackTrace();

			} catch (EpayDaoException daoexp) {
				logger.error(LoggingConstants.EXCEPTION, daoexp);
				response.setErrorStatus(ServiceErrorConstants.FAILURE);
				response.setErrorMessage(ServiceErrorConstants.UNDEFINED);
				response.setErrorCode(ServiceErrorConstants.EPCERR002);
				daoexp.printStackTrace();
			}

		} else {
			response.setErrorStatus(ServiceErrorConstants.FAILURE);
			response.setErrorCode("SUV002");
		}

		outParams.addAttribute(ServiceErrorConstants.APPLICATION_RESPONSE, response);
		logger.info("EpayDisplayClassificationService execute method end");

		return outParams;
	}
}
