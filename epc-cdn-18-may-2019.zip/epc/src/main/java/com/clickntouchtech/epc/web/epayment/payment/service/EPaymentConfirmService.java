package com.clickntouchtech.epc.web.epayment.payment.service;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.clickntouchtech.epc.web.epayment.payment.bp.EpayTransactionBP;
import com.clickntouchtech.epc.web.epayment.payment.dao.EPaymentDao;
import com.clickntouchtech.epc.web.epayment.payment.model.EpayModelParams;
import com.clickntouchtech.epc.web.epayment.payment.model.Transaction;
import com.clickntouchtech.epc.web.framework.exception.EpayApplicationException;
import com.clickntouchtech.epc.web.framework.exception.EpayBaseResponse;
import com.clickntouchtech.epc.web.framework.exception.EpayDaoException;
import com.clickntouchtech.epc.web.framework.service.EpayBaseAbsService;
import com.clickntouchtech.epc.web.framework.service.ServiceErrorConstants;

@Service
public class EPaymentConfirmService extends EpayBaseAbsService {

	private static final Logger logger = LoggerFactory.getLogger(EPaymentConfirmService.class);

	@Autowired
	private EPaymentDao ePaymentDao;

	@Autowired
	private EpayTransactionBP epayTransactionBP;

	public ModelMap execute(Map inputParams) {

		logger.info("EPaymentConfirmService execute method begins");
		if (logger.isDebugEnabled())
			logger.debug("inputparams Map: {}", inputParams);

		ModelMap outParams = new ModelMap();

		EpayBaseResponse response = new EpayBaseResponse();
		response.setErrorStatus(ServiceErrorConstants.FAILURE);

		String payOption = null;
		String categoryID = null;
		String bankCode = null;

		int validPayMode = 0;
		Map fieldkeyParamsMap = new HashMap();

		if (inputParams == null) {
			response.setErrorCode(ServiceErrorConstants.EPCERR002);
			response.setErrorStatus(ServiceErrorConstants.FAILURE);

		} else {
			try {
				payOption = (String) inputParams.get("payOption");
				categoryID = (String) inputParams.get("categoryid");
				bankCode = (String) inputParams.get("bankCode");

				String reqSessionId = (String) inputParams.get("reqSessionId");
				String reqServerName = (String) inputParams.get("reqServerName");
				String userName = (String) inputParams.get("userName");
				String ipAddress = (String) inputParams.get("userIpAddress");
				String deviceType = (String) inputParams.get("deviceType");

				if (validPayMode > 0 || payOption.equals("PAYUMONEY")) {

					if (logger.isDebugEnabled()) {
						logger.debug("input Params ::{}", inputParams);
					}

					Transaction transaction = (Transaction) inputParams.get("transaction");
					EpayModelParams epayModelParams = (EpayModelParams) inputParams.get("preloginParams");
					fieldkeyParamsMap = (Map) transaction.getDebit().getAdditionalParams();

					outParams.put("penaltyAmount", fieldkeyParamsMap.get("penaltyAmount"));
					outParams.put("penaltyType", fieldkeyParamsMap.get("penaltyType"));
					outParams.put("categoryName", fieldkeyParamsMap.get("fieldkey7"));
					outParams.put("instituteName", fieldkeyParamsMap.get("fieldkey5"));
					outParams.put("dynamicFieldkeyParamsMap", fieldkeyParamsMap.get("dynamicFieldkeyValuesMap"));

					fieldkeyParamsMap.remove("amountValuesMap");
					fieldkeyParamsMap.remove("dynamicFieldkeyValuesMap");

					transaction.getDebit().setAdditionalParams((HashMap) fieldkeyParamsMap);
					Transaction transactionResult = epayTransactionBP.postTransaction(transaction, epayModelParams);

					String registerNo = "";

					if (transactionResult != null) {
						com.clickntouchtech.epc.web.epayment.payment.model.TransactionLeg tleg = transactionResult.getDebit();
						registerNo = (String) tleg.getReferenceNo();
						outParams.put(ServiceErrorConstants.TRANSACTION, transactionResult);
						response.setErrorStatus(ServiceErrorConstants.SUCCESS);

					} else {
						response.setErrorCode(ServiceErrorConstants.EPCERR002);
					}

					try {
						ePaymentDao.insertLoginRequestTime(registerNo, userName, ipAddress, reqSessionId, reqServerName,
								deviceType);
					} catch (Exception e) {
						logger.info("Exception ::{}", e.getMessage());
					}

				} else {// To Validate Payment Mode
					response.setErrorStatus(ServiceErrorConstants.FAILURE);
					response.setErrorCode("SUV013");
				}

			} catch (EpayApplicationException cmsexp) {
				cmsexp.printStackTrace();
				response.setErrorCode("V101");
			} catch (EpayDaoException daoexp) {
				daoexp.printStackTrace();
				response.setErrorCode("V101");
			}

		}

		outParams.addAttribute(ServiceErrorConstants.APPLICATION_RESPONSE, response);

		if (logger.isDebugEnabled())
			logger.debug("outParams Map contains: {}", outParams);

		logger.info("EPaymentConfirmService execute method end");

		return outParams;

	}
}
