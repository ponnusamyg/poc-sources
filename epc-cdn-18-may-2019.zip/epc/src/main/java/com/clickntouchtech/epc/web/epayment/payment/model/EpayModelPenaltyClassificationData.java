package com.clickntouchtech.epc.web.epayment.payment.model;

import java.util.Date;

public class EpayModelPenaltyClassificationData implements EpayBaseModel {
		
	private static final long serialVersionUID = -3467592779648111979L;
	
	private String categoryId;
	private Integer penaltyOrder;
	private String amountType;
	private Double amount;
	private Date penaltyFromDate;
	private Date penaltyToDate;
	private String penaltyStatus;
	
	public String toString(){
		return new StringBuffer()
		.append(categoryId)
		.append("|")
		.append(penaltyOrder)
		.append("|")
		.append(amountType)
		.append("|")
		.append(amount)
		.append("|")
		.append(penaltyFromDate)
		.append("|")
		.append(penaltyToDate)
		.append("|")
		.append(penaltyStatus)
		.toString();
	}
	
	public String getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	public Integer getPenaltyOrder() {
		return penaltyOrder;
	}
	public void setPenaltyOrder(Integer penaltyOrder) {
		this.penaltyOrder = penaltyOrder;
	}
	public String getAmountType() {
		return amountType;
	}
	public void setAmountType(String amountType) {
		this.amountType = amountType;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public Date getPenaltyFromDate() {
		return penaltyFromDate;
	}
	public void setPenaltyFromDate(Date penaltyFromDate) {
		this.penaltyFromDate = penaltyFromDate;
	}
	public Date getPenaltyToDate() {
		return penaltyToDate;
	}
	public void setPenaltyToDate(Date penaltyToDate) {
		this.penaltyToDate = penaltyToDate;
	}
	public String getPenaltyStatus() {
		return penaltyStatus;
	}
	public void setPenaltyStatus(String penaltyStatus) {
		this.penaltyStatus = penaltyStatus;
	}
}
