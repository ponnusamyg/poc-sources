package com.clickntouchtech.epc.web.epayment.payment.dao;

import java.util.List;
import java.util.Map;

public interface EpayOrgDao {

	public List getEpayOrgList();
	public List getEpayOrgDetails(String institutionId);
	public List getEpayClassification(String orgid,String orgstate,String orgclassification);	
	public Map getClassficationEndDate(String categoryId,String todayDate);
	public Map getDescriptionData(String categoryId);
	public List getEpayClassificationParams(String categoryId);
	public List getClassificationParams(String categoryId);
	public Map getEpaymentServiceCharge(String institutionId);
	public List fileTxnClassifications(String classificationId);
	public Map fileTxnClassificationFields(String classificationId, String uniqueRefNo) ;

	
}
