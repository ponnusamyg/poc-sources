package com.clickntouchtech.epc.web.epayment.payment.service;

import java.util.Map;
import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ui.ModelMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.clickntouchtech.epc.web.epayment.payment.model.EpayModelParams;
import com.clickntouchtech.epc.web.epayment.payment.model.Transaction;
import com.clickntouchtech.epc.web.epayment.payment.util.EpayRequestMapper;
import com.clickntouchtech.epc.web.epayment.payment.util.EpaymentUtils;
import com.clickntouchtech.epc.web.framework.exception.EpayApplicationException;
import com.clickntouchtech.epc.web.framework.exception.EpayBaseResponse;
import com.clickntouchtech.epc.web.framework.exception.EpayDaoException;
import com.clickntouchtech.epc.web.framework.service.EpayBaseAbsService;
import com.clickntouchtech.epc.web.framework.service.ServiceErrorConstants;


@Service
public class EpayPreComfirmService extends EpayBaseAbsService{
	
	private static final Logger logger = LoggerFactory.getLogger(EpayPreComfirmService.class);
	
	@Autowired
	private EpayRequestMapper epayRequestMapper;
	
	@Autowired
	private EpaymentUtils epaymentUtils;
	
	public ModelMap epayServiceBase(ModelMap inputParams) {
		
		logger.info("EpayPreComfirmService execute method begins");
		
		if (logger.isDebugEnabled())
			logger.debug("inputparams Map:{}",inputParams);
		
		ModelMap outParams = new ModelMap();
		
		EpayBaseResponse response = new EpayBaseResponse();
		response.setErrorStatus(ServiceErrorConstants.FAILURE);
		
        String userName = (String) inputParams.get("profileuserName");
        String transactionType = (String)inputParams.get(ServiceErrorConstants.TRANSACTION_NAME);
		
		try{
            	 inputParams.put(ServiceErrorConstants.CREDIT_AMOUNT_TRANSFER,"amountTransfer");
            	 logger.info("credit branch code in txnshrtservice :{}",(String)inputParams.get(ServiceErrorConstants.CREDIT_BRANCH_CODE));
            	 //TODO: Required Transction validation to be done.
            	 //TransactionValidatorBP validator = transactionValidatorFactory.getValidator(transactionType);
            	 //boolean validatorResult = validator.validate(transaction);
                 logger.info("Transaction Type :{}",transactionType );
                 if(transactionType.equalsIgnoreCase("EPAYMENT"))
                 {
                	 Transaction transaction = epayRequestMapper.getTransactionObject(inputParams);
                	 //Added for State Bank Collect Transaction Limit checking
                	 Double txnamount=transaction.getDebit().getAmount();
                	 Double minAmount=1.00;
                	 logger.info("txn amount is :{}",transaction.getDebit().getAmount());
                	if(Double.compare(txnamount, minAmount)<0)
                  	{
                  		response.setErrorCode("SUTL002"); 
                  		response.setErrorStatus(ServiceErrorConstants.FAILURE);
                  		throw new EpayApplicationException("SUTL002");
                     	
                  	}
                	 /*else
                	 {*/
                	 EpayModelParams epayModelParams = epaymentUtils.getPreloginParams(inputParams,transaction);
                  	 Map feePaymentsCache = new HashMap();
                  	 feePaymentsCache.put("transaction",transaction);
                  	 feePaymentsCache.put("preloginParams",epayModelParams);
                  	 // Add commssion amount to total amount.
                  	 //transaction.getDebit().setAmount(transaction.getDebit().getAmount() + transaction.getDebit().getRateOfInterest());
                  	 transaction.getDebit().setAmount(transaction.getDebit().getAmount());
                  	 
                  	
                  	// userSessionCache.setData(userName+"_FeePayments",feePaymentsCache);  
                  	 
                  	outParams.put("feePaymentsCacheDetails", feePaymentsCache);
                  	outParams.put("txnamount",transaction.getDebit().getAmount());
                  	 
                 /*}*/
                 }
                 
                 response.setErrorStatus(ServiceErrorConstants.SUCCESS);
			
		 }catch(EpayApplicationException cmsexp) {
		    response.setErrorStatus(ServiceErrorConstants.FAILURE);
	        response.setErrorCode(cmsexp.getErrorCode());
		}catch (EpayDaoException daoexp) {
			daoexp.printStackTrace();
			response.setErrorStatus(ServiceErrorConstants.FAILURE);
	        response.setErrorCode("EPCERR002");	
		}
		
		logger.info("#######response#########{}",response);
		outParams.addAttribute(ServiceErrorConstants.APPLICATION_RESPONSE, response);
        logger.info("outputParams.ServiceConstant.APPLICATION_RESPONSE VALUE {}",outParams.get(ServiceErrorConstants.APPLICATION_RESPONSE));
		
		logger.info("EpayPreComfirmService execute method end");
		
		return outParams;
		
	}

}
