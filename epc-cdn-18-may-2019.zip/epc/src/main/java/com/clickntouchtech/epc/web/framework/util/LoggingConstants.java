package com.clickntouchtech.epc.web.framework.util;

public interface LoggingConstants
{

    public static final String METHODBEGIN = "method begin";
    
    public static final String METHODEND = "method end";
    
    public static final String EXCEPTION = "Exception Occurred : ";
    
    public static final String SIZE = "size";
    
    public static final String LENGTH = "length";
    
    public static final String SERVICE_INPUT ="Input to service = ";
    
    public static final String SERVICE_OUTPUT ="Output from service = ";
    
    public static final String APPLICATION_RESPONSE ="Application response from service =";
    
    public static final String ERROR_CODE = "Error code =";
    
    public static final String ERROR_STATUS = "Error status =";
    
    public static final String ERROR_MESSAGE = "Error message =";
    
    public static final String HANDLER_OUTPUT ="Output from handler = ";
    
    public static final String INSERTION_FAILURE = "Insertion Failure";

    public static final String NULL_INPUT_PARAMS = "Null input parameter";

    public static final String UPDATE_FAILURE = "Update Failure";
     
    
}
