package com.clickntouchtech.epc.web.epaysecurity.tags;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.clickntouchtech.epc.web.epaysecurity.service.EpayTokenService;
import com.clickntouchtech.epc.web.epaysecurity.service.EpayTokenServiceImpl;

/**
 * EpayJSPTokenTag
 *
 * @author selvaraj palanisamy
 * @since 1.0
 */

public class EpayJSPTokenTag extends TagSupport {
	private static final long serialVersionUID = 745177955805541350L;
	private static final Logger logger = LoggerFactory.getLogger(EpayJSPTokenTag.class);

	@Override
	public int doStartTag() throws JspException {
		final EpayTokenService epayTokenService = new EpayTokenServiceImpl();
		final String token = epayTokenService.getPageTokenSession((HttpServletRequest) super.pageContext.getRequest());
		final String pageParm = epayTokenService.generateParmName((HttpServletRequest) super.pageContext.getRequest());
		if (!StringUtils.isBlank(token) && !StringUtils.isBlank(pageParm))
			try {
				pageContext.getOut().write(String
						.format("<input type=\"hidden\" name=\"%1$s\" id=\"%1$s\" value=\"%2$s\" />", pageParm, token));
				logger.info("-----Param Name:--------------" + pageParm);
				logger.info("-----Page token:--------------" + token);
			} catch (IOException e) {
				e.printStackTrace();
			}
		return SKIP_BODY;
	}

	@Override
	public int doEndTag() throws JspException {
		return EVAL_PAGE;
	}

	public static String getPageTokenParmName() {
		return EpayTokenService.TOKEN_PARAM_NAME;
	}

}
