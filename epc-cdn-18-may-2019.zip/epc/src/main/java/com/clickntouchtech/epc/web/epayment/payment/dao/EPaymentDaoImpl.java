package com.clickntouchtech.epc.web.epayment.payment.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.clickntouchtech.epc.web.framework.exception.EpayDaoException;
import com.clickntouchtech.epc.web.framework.util.EpaySQLConstants;
import com.clickntouchtech.epc.web.framework.util.ErrorConstants;

@Repository
public class EPaymentDaoImpl implements EPaymentDao {

	private static final Logger logger = LoggerFactory.getLogger(EPaymentDaoImpl.class);

	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.setJdbcTemplate(new JdbcTemplate(dataSource));
	}

	

	public void insertLoginRequestTime(String epayrefno, String userid, String reqip, String reqsession,
			String reqjvm, String devicetype) throws EpayDaoException {

		try {

			Object[] parameters = new Object[] { epayrefno, userid, reqip, reqsession, reqjvm,devicetype };
			int[] sqlTypes = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,Types.VARCHAR };

			getJdbcTemplate().update(EpaySQLConstants.EPAY_USERS_PAY_LOGIN_HISTORY, parameters, sqlTypes);

			logger.info("Record inserted to epayUsersPayLoginHistory");
		} catch (DataAccessException daoExp) {
			logger.error("Unable to insert to epayUsersPayLoginHistory for :: {}", userid);
			logger.error("exception is ::{} ", daoExp);
			EpayDaoException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
	}

	public void updateLoginResponseTime(String echequeNo, String sessionId, String serverName, String txnStatus,
			String statusDescription, String resIpAddress) throws EpayDaoException {

		try {
			Object[] parameters = new Object[] { sessionId, serverName, resIpAddress, txnStatus, statusDescription,
					echequeNo };
			int[] sqlTypes = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
					Types.VARCHAR };

			getJdbcTemplate().update(EpaySQLConstants.EPAY_USERS_PAY_LOGIN_HISTORY_UPDATE, parameters, sqlTypes);

			logger.info("Record updated to epayUsersPayLoginHistory");
		} catch (DataAccessException daoExp) {
			logger.error("Unable to update to epayUsersPayLoginHistory for ::{}", echequeNo);
			logger.error("exception is :: {}", daoExp);
			EpayDaoException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		}
	}

	public Map getEpaymentParams(String echequeNo) throws EpayDaoException {
		logger.debug("getSupplierParams(String echequeNo) - begins");

		Map codesMap = null;
		try {
			Object params[] = { echequeNo };
			codesMap = (Map) getJdbcTemplate().query(EpaySQLConstants.EPAY_PAYMENT_PARAMS, params,
					new FindAllCodesExtractor());

		} catch (DataAccessException daoExp) {
			logger.error("exception is ::{}", daoExp);
			EpayDaoException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		} catch (Exception exception) {
			EpayDaoException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, exception);
		}

		logger.debug("getSupplierParams(String echequeNo) - end");
		return codesMap;
	}

	private class FindAllCodesExtractor implements ResultSetExtractor {

		public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
			Map result = new LinkedHashMap();
			while (rs.next()) {
				result.put(rs.getString("userkey"), rs.getString("uservalue"));
			}
			return result;
		}
	}

	public Map getEpayTransData(String echequeNo) throws EpayDaoException {
		Map codesMap = null;
		logger.debug("getEchequeDetails(String echequeNo) - begins");
		try {

			Object params[] = { echequeNo };
			codesMap = (Map) getJdbcTemplate().queryForMap(EpaySQLConstants.EPAY_TRANS_DATA, params);
			logger.info("getEchequeDetails branch_code added for logo display ::{}", codesMap);

		} catch (DataAccessException daoExp) {
			logger.error("exception is ::{}", daoExp);
			EpayDaoException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE);
		} catch (Exception exception) {
			EpayDaoException.throwException(ErrorConstants.FATAL_EXCEPTION_ERRORCODE, exception);
		}

		logger.debug("getEchequeDetails(String echequeNo) - end");
		return codesMap;

	}

}