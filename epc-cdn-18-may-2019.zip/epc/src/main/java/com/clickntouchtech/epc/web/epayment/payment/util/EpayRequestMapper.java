package com.clickntouchtech.epc.web.epayment.payment.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.clickntouchtech.epc.web.epayment.payment.model.EpayTransaction;
import com.clickntouchtech.epc.web.epayment.payment.model.Transaction;
import com.clickntouchtech.epc.web.epayment.payment.model.TransactionLeg;
import com.clickntouchtech.epc.web.framework.exception.EpayApplicationException;
import com.clickntouchtech.epc.web.framework.util.Constants;

@Service
public class EpayRequestMapper{
	
	private static final Logger logger = LoggerFactory.getLogger(EpayRequestMapper.class);
	
	@Autowired
	private EpayUtilsCounter epayUtilsCounter;
	
	public Transaction getTransactionObject(Map input)	{
		
		if(logger.isDebugEnabled())
		{
			logger.debug("getTransactionObject( Map input ) method begin" );
			logger.debug("inParams:{}",input);
		}
		
		Transaction corpTransaction = new EpayTransaction();
		TransactionLeg transactionDebitLeg = new TransactionLeg();
		
		HashMap getAdditionalParamsMap = null;
		Map amountValuesMap = new HashMap();		
		if(input!=null){
			
			 int txnCount =  1;			
			String remarks = (String)input.get(Constants.TRANSACTION_REMARKS);
			if(remarks==null) remarks ="";
			transactionDebitLeg.setRemarks(remarks);
			String userName = (String) input.get(Constants.USER_NAME);
			String txnName =  ((String) (input.get(Constants.TRANSACTION_NAME)));	
			transactionDebitLeg.setMerchantCode("EPAYMENT");
			getAdditionalParamsMap =(HashMap) epayUtilsCounter.getAdditionalParams(input);		  
		    transactionDebitLeg.setAdditionalParams(getAdditionalParamsMap);
		    double amount=0;
		    String value="";
		    String selectedCatName = (String)getAdditionalParamsMap.get("fieldkey7");
		    amountValuesMap =(Map)getAdditionalParamsMap.get("amountValuesMap");		    
		    Set amountValues = new TreeSet();
		    amountValues = amountValuesMap.keySet();
		    Iterator amountValueIterator = amountValues.iterator();
		    while(amountValueIterator.hasNext()){
		    	value = amountValueIterator.next().toString();		    	
		    	if(amountValuesMap.get(value)!= null  && !amountValuesMap.get(value).equals("")) {
		    		amount+=Double.parseDouble((String)amountValuesMap.get(value));	
		    	}
		    }

		    if(getAdditionalParamsMap.get("penaltyAmount")!=null && 
		    		!getAdditionalParamsMap.get("penaltyAmount").equals("")){		    	
		    	amount += (Double.parseDouble(getAdditionalParamsMap.get("penaltyAmount").toString()));
		    }
		   
		    double EPC_LIMIT =100000;
		    if(input.get("EPC_LIMIT") != null) {
		    	logger.info("limit :{}",input.get("EPC_LIMIT"));
		    	EPC_LIMIT = Double.parseDouble((String)input.get("EPC_LIMIT")) ;	
		    }
		    
		    if(amount <= 0)
		    {
		    	EpayApplicationException.throwException("V015");//Invalid amount
		    	
		    }else if(amount > EPC_LIMIT)	{
		    	
		    	EpayApplicationException.throwException("SBCTLE01");//Invalid amount
		    }
		    
		  //Added for Sevice charge
		    Map serviceChargeMap = (Map)getAdditionalParamsMap.get("serviceChargeMap");
		    if ("YES".equalsIgnoreCase((String) serviceChargeMap.get("COMM_REQD"))){
				transactionDebitLeg.setNarrative1((String) serviceChargeMap.get("RECOVERED_FROM"));
				String corpId = (String) serviceChargeMap.get("CORP_ID");
				 
		    }
			//end 
		   
		 transactionDebitLeg.setAmount(new Double(amount));		 
			corpTransaction.setDebit(transactionDebitLeg);
			corpTransaction.setName(txnName.trim());
			corpTransaction.setBankCode((String)input.get("bankCode"));	
			}
		
		if(logger.isDebugEnabled())
			logger.debug("getTransactionObject( Map input )method  end");
		
		return corpTransaction;
	}
	
}