package com.clickntouchtech.epc.web.framework.util;

import java.text.DecimalFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.mobile.device.Device;
import org.springframework.mobile.device.DeviceUtils;


public class StringUtils {
	protected static final Logger logger = Logger.getLogger("StringUtils.java");
	
	
	
    public static String formatAmount(String absoluteAmount){
    	String sign="";
        String formattedAmount=" ";
    	if (absoluteAmount != null && absoluteAmount.length()>0) {
            if(absoluteAmount.substring(0,1).equals("-")){
                sign="-";
                absoluteAmount=absoluteAmount.substring(1,absoluteAmount.length());
            }
        	double doubleAmount=Double.valueOf(absoluteAmount).doubleValue();
            DecimalFormat decimalFormat = new DecimalFormat("#############0.00");
            String amount=decimalFormat.format(doubleAmount);
            int index = amount.indexOf(".");
            String decimalValue="";
            if (index != -1)
                decimalValue = amount.substring(index + 1);
            else
                decimalValue = "00";
            
            amount = amount.substring(0, index);
            int length = amount.length();
            if (length >= 1 && length <= 3)
                formattedAmount = amount;
            else {
                formattedAmount=amount.substring(length-3,length);
                for(int i=length-5;i>=0;i-=2)
                    formattedAmount=amount.substring(i,i+2)+","+formattedAmount;
                if(length%2==0)
                    formattedAmount=amount.substring(0,1)+","+formattedAmount;
            }
            formattedAmount = sign + formattedAmount + "." + decimalValue;
            
        } 
        return formattedAmount;
    }
    
    
    
	
} 
