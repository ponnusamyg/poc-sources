package com.clickntouchtech.epc.web.framework.tags;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Iterator;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import com.clickntouchtech.epc.web.epayment.payment.model.EpayFormValues;
import com.clickntouchtech.epc.web.framework.util.EncryptDecrypt;

public class EpcSecTag extends SimpleTagSupport{
    
    private EpayFormValues epayformval;
    
    public void doTag() throws JspException, IOException{
        JspWriter out=getJspContext().getOut();
        try{
            String mand="";
            String value = "";
            if (epayformval.getValue()==null || epayformval.getValue()=="")
                    value=epayformval.getDefaultValue();
            else
                value=epayformval.getValue();
            if (epayformval.getMandatory().equalsIgnoreCase("0"))
                mand="*";
            
//            
              
            if(epayformval.getControlType().equalsIgnoreCase("ComboBox")|| epayformval.getControlType().equalsIgnoreCase("Options") || epayformval.getControlType().equalsIgnoreCase("naoptions")||epayformval.getControlType().equalsIgnoreCase("Option")){
                out.println("<div class='row_accord'><label>");
                out.println(epayformval.getLabel()+" "+mand);
                out.println("</label>");
                out.println("<span class=\"plain-select-small\">");
                out.println("<select name='" + epayformval.getRequestVarname() + "' id='"+epayformval.getRequestVarname()+"' >");
                out.println("<option value=''>--Select " + epayformval.getLabel() + "--</option>");
                Iterator iterator = epayformval.getControlValues().keySet().iterator();
                while(iterator.hasNext()){
                    String name = (String)iterator.next();
                    if(value.equals(epayformval.getControlValues().get(name)))
                        out.println("<option value='" +  epayformval.getControlValues().get(name) +"' selected>" + epayformval.getControlValues().get(name) + "</option>");
                    else
                        out.println("<option value='" +  epayformval.getControlValues().get(name) +"' >" + epayformval.getControlValues().get(name) + "</option>");
                }
                out.println("</select>");
                out.println("</span>");
                out.println("<span style='color: red' id='"+epayformval.getRequestVarname()+"errorMessage'/>");
                out.println("</div>");
            }
            else if(epayformval.getControlType().equalsIgnoreCase("ComboCheck")){
                out.println("<div class='row_accord'><label>");
                out.println(epayformval.getLabel()+" "+mand);
                out.println("</label>");
                out.println("<span class=\"plain-select-small\">");
                out.println("<select name='" + epayformval.getRequestVarname() + "' id='"+epayformval.getRequestVarname()+"' onchange=funcForComboBox(this.form,this.value)>");
                Iterator iterator = epayformval.getControlValues().keySet().iterator();
                while(iterator.hasNext()){
                    String name = (String)iterator.next();
                    if(value.equals(epayformval.getControlValues().get(name)))
                        out.println("<option value='" +  epayformval.getControlValues().get(name) +"' selected>" + epayformval.getControlValues().get(name) + "</option>");
                    else
                        out.println("<option value='" +  epayformval.getControlValues().get(name) +"' >" + epayformval.getControlValues().get(name) + "</option>");
                }
                out.println("</select>");
                out.println("</span>");
                out.println("</div>");
            }
            else if(epayformval.getControlType().equalsIgnoreCase("CheckBox")){
                out.println("<div class='row_accord'><label>");
                out.println(epayformval.getLabel()+" "+mand);
                out.println("</label>");
                Iterator iterator = epayformval.getControlValues().keySet().iterator();
                while(iterator.hasNext()){
                    String name = (String)iterator.next();
                    if(value.indexOf(""+epayformval.getControlValues().get(name)+"")>=0)
                        out.println( "<input  name='" + epayformval.getRequestVarname() + "' id='"+epayformval.getRequestVarname()+"'type='" + epayformval.getControlType()+"' value='" +  epayformval.getControlValues().get(name) +"' checked />"+epayformval.getControlValues().get(name));
                    else
                        out.println( "<input  name='" + epayformval.getRequestVarname() + "' id='"+epayformval.getRequestVarname()+"'type='" + epayformval.getControlType()+"' value='" +  epayformval.getControlValues().get(name) +"' />"+epayformval.getControlValues().get(name));
                    out.println("<br>");
                }
                out.println("</div>");
            }
            else if( epayformval.getControlType().equalsIgnoreCase("ListBox")){
                out.println("<div class='row_accord'><label>");
                out.println(epayformval.getLabel()+" "+mand);
                out.println("</label>");
                out.println("<span class=\"plain-select-small\">");
                out.println("<select multiple='true' name='" + epayformval.getRequestVarname() + "' id='"+epayformval.getRequestVarname()+"'>");
                Iterator iterator = epayformval.getControlValues().keySet().iterator();
                while(iterator.hasNext()){
                    String name = (String)iterator.next();
                    if(value.indexOf(""+epayformval.getControlValues().get(name)+"")>=0)
                        out.println("<option value='" +  epayformval.getControlValues().get(name) +"' selected>" + epayformval.getControlValues().get(name) + "</option>");
                    else
                        out.println("<option value='" +  epayformval.getControlValues().get(name) +"'>" + epayformval.getControlValues().get(name) + "</option>");
                }
                
                out.println("</select>");
                out.println("</span>");
                out.println("</div>");                
            }
            else if(epayformval.getControlType().equalsIgnoreCase("label")){
                if( epayformval.getFormat() == null){ 
                    out.println("<div class='row_accord'><label>");
                    out.println(epayformval.getLabel()+" "+mand);
                    out.println("</label>");
                    out.println(value);
					out.println("<input type='hidden' name='"+ epayformval.getRequestVarname()+ "' id='" + epayformval.getRequestVarname() + "' value='"+value+"'>");
                    out.println("</div>");
                }else
                    out.println("<input type='hidden' name='"+ epayformval.getRequestVarname()+ "' id='" + epayformval.getRequestVarname() + "'/>");
            }
            else if(epayformval.getControlType().equalsIgnoreCase("Exception")){
                out.println("<div class='row_accord'><label>");
                out.println(epayformval.getLabel()+" "+mand);
                out.println("</label>");
                out.println("<input type='text' name='" + epayformval.getRequestVarname() +  "' maxLength='" + epayformval.getFieldSize()
                        + "' value='"+ value +"' id='"+epayformval.getRequestVarname()+"'/>");
                out.println("</div>");
            }else if(epayformval.getControlType().equalsIgnoreCase("Date")){
            	
            	String pattern = "d/m/yy";
            	Iterator iterator = epayformval.getControlValues().keySet().iterator();
			    while(iterator.hasNext()){
			    	String name = (String)iterator.next();
			    	 if("ddmmyyyy".equals( epayformval.getControlValues().get(name)) )
			    		 pattern = "d/m/yy";
			    	 else if("mmddyyyy".equals( epayformval.getControlValues().get(name)) )
			    		 pattern = "m/d/yy";
                }
            		
                out.println("<script>"); 
                out.println("$(function(){$.datepicker.setDefaults({inline:true,showOn:'button',buttonImageOnly:true,buttonImage:'//d2ivc9zanyedd.cloudfront.net/web/templates/ePayCounter/layouts/images/calendar_icon.png',buttonText:'Calendar'});"
                		+"$(\"#"+epayformval.getRequestVarname()+"\").datepicker({dateFormat:\""+pattern+"\"}).val();"+         
                "var changeMonth = $(\"#"+epayformval.getRequestVarname()+"\" ).datepicker( \"option\", \"changeMonth\");"+ 
                "$(\"#"+epayformval.getRequestVarname()+"\" ).datepicker(\"option\",\"changeMonth\",true);"+ 
                "var changeYear = $(\"#"+epayformval.getRequestVarname()+"\").datepicker(\"option\",\"changeYear\");"+
                "$(\"#"+epayformval.getRequestVarname()+"\").datepicker(\"option\",\"changeYear\", true);});"+
                
                "$(document).ready(function(){$(\"img[class='ui-datepicker-trigger']\").each(function(){$(this).attr('style', 'position:relative; top:-1px; left:7px;');});"+
                "$('.ui-datepicker-trigger').mouseover(function() {$(this).css('cursor', 'pointer');});});"); 
                out.println("</script>");
            	
                out.println("<div class='row_accord'><label>");
                out.println(epayformval.getLabel()+" "+mand);
                out.println("</label>");
                out.println("<input type='text' name='" + epayformval.getRequestVarname() +  "' maxLength='" + epayformval.getFieldSize()
                        + "' value='"+ value +"' id='"+epayformval.getRequestVarname()+"'readonly='readonly'/>");
                out.println("<span style='color: red' id='"+epayformval.getRequestVarname()+"errorMessage'/>");
                out.println("</div>");
                
            }
			else if(epayformval.getControlType().equalsIgnoreCase("Prototype")){
             	
                out.println("<div class='row_accord'><label>");
                out.println(epayformval.getLabel() + " " + mand);
                out.println("</label>");
                String format=epayformval.getFormat();
                String[] values = format.split("\\/");
                Calendar calendar = new GregorianCalendar();
                if(value != null){
                    try{
                        SimpleDateFormat dateFormat = new SimpleDateFormat(format);
                        calendar.setTime(dateFormat.parse(value));
                    }catch (Exception e) {}
                }
                int curDate=calendar.get(Calendar.DATE);
                int curMonth=calendar.get(Calendar.MONTH);
                int curYear=calendar.get(Calendar.YEAR);
				int startYear =0;
         
                	startYear=new GregorianCalendar().get(Calendar.YEAR);
         
                int endYear =0;
                 	endYear=startYear+3;
             
                int dates[]={31,28,31,30,31,30,31,31,30,31,30,31};
                if (curMonth==1 && curYear%4==0)
                    dates[1]=29;
                for(int k=0;k<values.length;k++){
                    if(values[k].equalsIgnoreCase("dd")){
                         out.println("Date <select name='date"+epayformval.getRequestVarname()+"' id='date"+epayformval.getRequestVarname()+"'>");
                         for (int i = 1; i <=dates[curMonth] ; i++){
                              if(i==curDate)
                                  out.println("<option value='"+ i +"' selected>" +  i + "</option>");
                              else 
                                  out.println("<option value='"+ i +"' >" +  i + "</option>");
                         }
                        out.println("</select>");                        
                    }else if(values[k].equalsIgnoreCase("mm")){
                        out.println("Month <select name='month"+epayformval.getRequestVarname()+"' id='month"+epayformval.getRequestVarname()+"' onchange=funcForMonth(this.value,'"+ epayformval.getRequestVarname() + "');>");
                        for (int i = 1; i <= 12; i++){
                            if(i==curMonth+1)
                                out.println("<option value='" + i +"' selected>" +  i + "</option>");
                            else
                                out.println("<option value='" + i +"'> "+ i +" </option>");
                        }
                        out.println("</select>");
                      
                    }else if(values[k].equalsIgnoreCase("yy")){
                        out.println("Year <select name='year"+epayformval.getRequestVarname()+"' id='year"+epayformval.getRequestVarname()+"' onchange=funcForYear(this.value,'"+ epayformval.getRequestVarname() + "');>");
                        for (int i = startYear-15; i <= endYear; i++){
                            if (i == curYear){
                                Integer intYear=new Integer(i);
                                String stringYear=intYear.toString();
                                out.println("<option value='" + stringYear.substring(2) + "'selected>" + stringYear.substring(2) + "</option>");
                                }
                            else{
                                Integer intYear=new Integer(i);
                                String stringYear=intYear.toString();
                                out.println("<option value='" + stringYear.substring(2) + "'>" + stringYear.substring(2) + "</option>");}
                        }
                        out.println("</select>");
                        
                    }else if(values[k].equalsIgnoreCase("yyyy")){
                        out.println("Year <select name='year"+epayformval.getRequestVarname()+"' id='year"+epayformval.getRequestVarname()+"' onchange=funcForYear(this.value,'"+ epayformval.getRequestVarname() + "');>");
                        for (int i = startYear-15; i <= endYear; i++){
                            if (i == curYear)
                                out.println("<option value='" + i + "'selected>" + i + "</option>");
                            else
                                out.println("<option value='" + i + "'>" + i + "</option>");
                        }
                        out.println("</select>");
                        
                    }
                    else if(values[k].equalsIgnoreCase("yy-yy")){
                        out.println("Year <select name='year"+epayformval.getRequestVarname()+"' id='year"+epayformval.getRequestVarname()+"' onchange=funcForYear(this.value,'"+ epayformval.getRequestVarname() + "');>");
                        if(value != null && value != "")
                            curYear = curYear-1;
                        
                        for (int i = startYear-15; i <= endYear; i++){
                            if (i == curYear)
                                out.println("<option value='" + i + "-"+(i+1)+"'selected>" + i + "-"+(i+1)+"</option>");
                            else
                                out.println("<option value='" + i + "-"+(i+1)+"'>" + i + "-"+(i+1)+"</option>");
                        }
                        out.println("</select>");
                        
                    }
                }
                out.println("<input type='hidden' name='"+ epayformval.getRequestVarname()+ "' id='" + epayformval.getRequestVarname() + "'/>");
                out.println("</div>");
             
            }
            else if(epayformval.getControlType().equalsIgnoreCase("hidden"))
            {
                out.println("<input type='" + epayformval.getControlType() + "' name='" + epayformval.getRequestVarname() +  "' maxLength='" + epayformval.getFieldSize()
                        + "' value='"+ value +"' id='"+epayformval.getRequestVarname()+"'/>");
            }
            
            else if(epayformval.getControlType().equalsIgnoreCase("textarea"))
            {
                out.println("<div class='row_accord'><label>");
                out.println(epayformval.getLabel()+" "+mand);
                out.println("</label>");
                out.println("<textarea name='" + epayformval.getRequestVarname()  
                        + "' id='"+epayformval.getRequestVarname()+"' rows='2' cols='20'>" +value);

                out.println("</textarea>");
                out.println("</div>");
            }
            else if(epayformval.getControlType()!=null && 
            		(epayformval.getControlType().equalsIgnoreCase("fixed") || 
            				epayformval.getControlType().equalsIgnoreCase("Variable")||epayformval.getControlType().equalsIgnoreCase("naFixed")  ) ) {
            	
            	System.out.println("Inside Text Control Type");
                out.println("<div class='row_accord'><label>");
                out.println(epayformval.getLabel()+" "+mand);
                out.println("</label>");
                
                if( epayformval.getControlType().equalsIgnoreCase("fixed")||epayformval.getControlType().equalsIgnoreCase("naFixed") ) {
                	System.out.println("Inside Fixed");
                	if(epayformval.getMandatory().equalsIgnoreCase("0"))
                	out.println("<input type='" + epayformval.getControlType() 
                    		+"' name='" + epayformval.getRequestVarname() 
                    		+  "' maxLength='" + epayformval.getFieldSize()
                            + "' value='"+ value +"' id='"+epayformval.getRequestVarname()+"' readOnly='true' />&nbsp <b>Fixed:Rs."+value+"</b>");
                	else
                		out.println("<input type='" + epayformval.getControlType() 
                        		+"' name='" + epayformval.getRequestVarname() 
                        		+  "' maxLength='" + epayformval.getFieldSize()
                                + "' value='0' id='"+epayformval.getRequestVarname()+"'/>&nbsp <b>Fixed:Rs."+value+"</b>");                	
                	
                }else {
                out.println("<input type='" + epayformval.getControlType() 
                		+"' name='" + epayformval.getRequestVarname() 
                		+  "' maxLength='" + epayformval.getFieldSize()
                        + "' value='"+ value +"' id='"+epayformval.getRequestVarname()+"'/>");
                }
                out.println("<span style='color: red' id='"+epayformval.getRequestVarname()+"errorMessage'/>"); 
                out.println("</div>");
                
            	
            }
            else if(epayformval.getControlType().equalsIgnoreCase("natext")){           	
                out.println("<div class='row_accord'><label>");
                out.println(epayformval.getLabel()+" "+mand);
                out.println("</label>");
                out.println("<span>"+value+"</span>");
                out.println("<input type='text'  name ='"+epayformval.getRequestVarname()+"' value='"+value+"' />");                
                out.println("</div>");
            }
            else{
                out.println("<div class='row_accord'><label>");
                out.println(epayformval.getLabel()+" "+mand);
                out.println("</label>");
                out.println("<input type='" + epayformval.getControlType() + "' name='" + epayformval.getRequestVarname() +  "' maxLength='" + epayformval.getFieldSize()
                        + "' value='"+ value +"' id='"+epayformval.getRequestVarname()+"'/>");
                out.println("<span style='color: red' id='"+epayformval.getRequestVarname()+"errorMessage'/>"); 
                out.println("</div>");
                
                
            }
            out.println("<input type='hidden' name='epayc' value='"+ epayformval.getRequestVarname()+"' id='epayids'/>");
            if(epayformval.getMandatory().equals("0")&&!epayformval.getControlType().equalsIgnoreCase("Prototype")){
            	String  originalString =epayformval.getRequestVarname() +"#SPLIT#"+epayformval.getLabel()+"#SPLIT#" + epayformval.getFormat() + "#SPLIT#" + epayformval.getErrorMessage();
            	String paramValue=new EncryptDecrypt().encrypt(originalString);
                out.println("<input type='hidden' name='required' id='required' value='"+originalString+"'/>");
            }
            else if(epayformval.getMandatory()!=null && epayformval.getMandatory().equals("S")&&!epayformval.getControlType().equalsIgnoreCase("Prototype")){
            	String OrgString=epayformval.getRequestVarname() +"#SPLIT#"+epayformval.getLabel()+"#SPLIT#" + epayformval.getFormat() + "#SPLIT#" + epayformval.getErrorMessage();
            	String paramValue=new EncryptDecrypt().encrypt(OrgString);
                out.println("<input type='hidden' name='notrequired' id='notrequired' value='"+ OrgString + "'/>");
            }
            else if(epayformval.getFormat() != null && !epayformval.getControlType().equalsIgnoreCase("Label")&& !epayformval.getControlType().equalsIgnoreCase("Prototype")&&!epayformval.getControlType().equalsIgnoreCase("hidden")){
            	String orgString= epayformval.getRequestVarname() +"#SPLIT#"+ epayformval.getLabel()+"#SPLIT#"+ epayformval.getFormat()+ "#SPLIT#"+ epayformval.getErrorMessage();
            	String paramValue=new EncryptDecrypt().encrypt(orgString);
                out.println("<input type='hidden' name='presentation' id='presentation' value='"+orgString+ "'/>");
            }else if(epayformval.getFormat() != null && epayformval.getControlType().equalsIgnoreCase("Label")){
              	String  originalString = epayformval.getRequestVarname() +"#SPLIT#"+ epayformval.getFormat() + "#SPLIT#" + epayformval.getExceptionCode();
            	String paramValue=new EncryptDecrypt().encrypt(originalString);
                out.println("<input type='hidden' name='evaluatevalue' id='evaluatevalue' value='"+originalString+"'/>");
            }
            else if(epayformval.getControlType().equalsIgnoreCase("Prototype")){
            	String originalString=epayformval.getRequestVarname()+"#SPLIT#"+"date"+epayformval.getRequestVarname()+"#SPLIT#"+"month"+epayformval.getRequestVarname()+"#SPLIT#"+"year"+epayformval.getRequestVarname();
            	String paramValue=new EncryptDecrypt().encrypt(originalString);
                out.println("<input type='hidden' name='evaluatedate' id='evaluatedate' value='"+originalString+"'/>");
              }
            //String encryptedString = AES.encrypt(originalString, secretKey) ;
            
        }catch(Exception exception){
            throw new JspException("out put Error" + exception);
        }
        
    }
    
    public void setControl(EpayFormValues epayformval){
        this.epayformval = epayformval;
    }
    
    public EpayFormValues getControl(){
        return epayformval;
    }
}